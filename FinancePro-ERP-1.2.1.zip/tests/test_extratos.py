"""Importação de extrato por planilha (formatos reais dos bancos) e Open Finance (Pluggy simulada)."""
import io
import json
from datetime import date, datetime
from decimal import Decimal

import httpx
import pytest

from app.bancos import planilha as pl
from app.bancos.pluggy import transacao


# ============================================================================ leitura de planilhas

def test_valores_no_formato_dos_bancos():
    casos = {"1.234,56": ("1234.56", None), "-1.234,56": ("-1234.56", None), "R$ 10,00": ("10.00", None),
             "(10,00)": ("-10.00", None), "1.234,56 D": ("1234.56", "D"), "500,00 C": ("500.00", "C"),
             "1234.56": ("1234.56", None), "1,234.56": ("1234.56", None), "1.234": ("1234.00", None),
             "45,5": ("45.50", None), "10,00-": ("-10.00", None), -12.5: ("-12.50", None), "": (None, None),
             "PIX": (None, None)}
    for txt, (esperado, sentido) in casos.items():
        v, s = pl.para_valor(txt)
        assert (str(v) if v is not None else None, s) == (esperado, sentido), txt


def test_datas():
    assert pl.para_data("05/11/2026") == date(2026, 11, 5)
    assert pl.para_data("05/11/26") == date(2026, 11, 5)
    assert pl.para_data("2026-11-05") == date(2026, 11, 5)
    assert pl.para_data(datetime(2026, 11, 5, 10, 0)) == date(2026, 11, 5)
    assert pl.para_data(46331) == date(2026, 11, 5)          # número de série do Excel
    assert pl.para_data("Saldo") is None


CSV_ITAU = """Extrato Conta Corrente
Agência: 1234  Conta: 56789-0

data;lançamento;ag./origem;valor (R$);saldos (R$)
01/11/2026;SALDO ANTERIOR;;;10.000,00
03/11/2026;PIX TRANSF  CLIENTE ALFA;;1.500,00;
04/11/2026;SISPAG FORNECEDOR XYZ;;-2.300,50;
04/11/2026;TAR PACOTE ITAU;;-89,90;9.109,60
05/11/2026;SALDO DO DIA;;;9.109,60
""".encode("cp1252")


def test_csv_itau_com_cabecalho_no_meio_e_saldos():
    linhas = pl.ler_linhas(CSV_ITAU, "extrato.csv")
    det = pl.detectar(linhas)
    assert det.colunas[det.mapa["data"]] == "data"
    assert det.colunas[det.mapa["descricao"]] == "lançamento"
    assert det.colunas[det.mapa["valor"]] == "valor (R$)"
    assert det.colunas[det.mapa["saldo"]] == "saldos (R$)"
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert [(t.natureza, t.valor) for t in r.transacoes] == [("C", Decimal("1500.00")), ("D", Decimal("2300.50")),
                                                              ("D", Decimal("89.90"))]
    assert r.saldo == Decimal("9109.60") and r.data_saldo == date(2026, 11, 5)
    assert sum(1 for x in r.linhas if x.motivo == "saldo ou total") == 2


def _xlsx(linhas):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    for l in linhas:
        ws.append(l)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_xlsx_com_colunas_de_credito_e_debito():
    conteudo = _xlsx([["Banco Exemplo - Extrato"], [],
                      ["Data Lançamento", "Histórico", "Documento", "Crédito (R$)", "Débito (R$)", "Saldo (R$)"],
                      [datetime(2026, 11, 3), "DEPOSITO", "123", 800, None, 1800],
                      [datetime(2026, 11, 4), "PAGTO BOLETO", "456", None, -300.5, 1499.5],
                      [datetime(2026, 11, 4), "Total", None, 800, -300.5, None]])
    assert pl.tipo_arquivo(conteudo) == "xlsx"
    linhas = pl.ler_linhas(conteudo)
    det = pl.detectar(linhas)
    assert {"data", "descricao", "documento", "credito", "debito", "saldo"} <= det.mapa.keys()
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert [(t.natureza, t.valor, t.documento) for t in r.transacoes] == [("C", Decimal("800.00"), "123"),
                                                                          ("D", Decimal("300.50"), "456")]
    assert r.saldo == Decimal("1499.50")


HTML_BB = """<html><body><table><tr><td colspan=4>Extrato de conta corrente</td></tr></table>
<table>
<tr><th>Data</th><th>Histórico</th><th>Documento</th><th>Valor R$</th><th>Tipo</th></tr>
<tr><td>01/11/2026</td><td>Saldo Anterior</td><td></td><td>5.000,00</td><td>C</td></tr>
<tr><td>03/11/2026</td><td>Pix - Recebido<br>03/11 10:22 Cliente Beta</td><td>1</td><td>700,00</td><td>C</td></tr>
<tr><td>04/11/2026</td><td>Pagamento de Boleto</td><td>2</td><td>250,00</td><td>D</td></tr>
</table></body></html>""".encode("latin-1")


def test_xls_que_e_html_com_coluna_tipo():
    assert pl.tipo_arquivo(HTML_BB, "extrato.xls") == "html"
    linhas = pl.ler_linhas(HTML_BB, "extrato.xls")
    det = pl.detectar(linhas)
    assert det.mapa.get("tipo") is not None
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert [(t.natureza, t.valor) for t in r.transacoes] == [("C", Decimal("700.00")), ("D", Decimal("250.00"))]
    assert "Cliente Beta" in r.transacoes[0].descricao


def test_csv_sem_cabecalho_decide_pelo_conteudo():
    conteudo = b"03/11/2026,Recebimento cliente,150.00\n04/11/2026,Compra material,-80.10\n05/11/2026,Tarifa,-5.00\n"
    linhas = pl.ler_linhas(conteudo, "x.csv")
    det = pl.detectar(linhas)
    assert det.linha_cabecalho is None and det.mapa["data"] == 0 and det.mapa["valor"] == 2 and det.mapa["descricao"] == 1
    r = pl.interpretar(linhas, None, det.mapa)
    assert [t.natureza for t in r.transacoes] == ["C", "D", "D"]


def test_inverter_sinais_e_aviso():
    conteudo = "Data;Descrição;Valor\n" + "".join(f"0{i}/11/2026;Compra {i};{i}0,00\n" for i in range(1, 7))
    linhas = pl.ler_linhas(conteudo.encode(), "c.csv")
    det = pl.detectar(linhas)
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert r.avisos and all(t.natureza == "C" for t in r.transacoes)
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa, inverter=True)
    assert all(t.natureza == "D" for t in r.transacoes)


def test_modelo_xlsx_importa():
    conteudo = pl.modelo_xlsx()
    linhas = pl.ler_linhas(conteudo)
    det = pl.detectar(linhas)
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert len(r.transacoes) == 3 and r.saldo == Decimal("11097.60")


# ============================================================================ serviço: prévia, importação, desfazer

def test_previa_importar_e_desfazer(session, empresa, conta):
    from app.servicos import conciliacao as conc
    p = conc.previa_extrato(session, conta, CSV_ITAU, "extrato.csv")
    assert p["tipo"] == "planilha" and p["resumo"]["novos"] == 3 and p["resumo"]["puladas"] == 2
    assert p["saldo_banco"] == Decimal("9109.60")
    r = conc.importar_arquivo(session, conta, CSV_ITAU, "extrato.csv", None)
    assert r["novos"] == 3
    # reimportar o mesmo arquivo não duplica
    assert conc.importar_arquivo(session, conta, CSV_ITAU, "extrato.csv", None)["novos"] == 0
    hist = conc.importacoes(session, empresa.id, conta.id)
    assert hist[0]["novos"] == 0 and hist[1]["novos"] == 3 and hist[1]["pendentes"] == 3
    from app.models import ImportacaoExtrato
    imp = session.get(ImportacaoExtrato, r["importacao_id"])
    assert conc.desfazer_importacao(session, imp, None) == {"removidos": 3}
    assert conc.previa_extrato(session, conta, CSV_ITAU, "extrato.csv")["resumo"]["novos"] == 3


def test_mesmo_dia_por_ofx_e_por_planilha_nao_duplica(session, empresa, conta):
    from app.bancos import TransacaoBanco
    from app.servicos import conciliacao as conc
    conc.importar(session, conta, [TransacaoBanco(date(2026, 11, 3), Decimal("1500.00"), "C", "PIX RECEBIDO ALFA", "FIT1")],
                  "ofx", None)
    r = conc.importar_arquivo(session, conta, CSV_ITAU, "extrato.csv", None)
    assert r["novos"] == 2 and r["parecidos"] == 1
    # quem quiser pode importar mesmo assim: o que tinha ficado de fora entra agora
    r = conc.importar_arquivo(session, conta, CSV_ITAU, "extrato.csv", None, pular_parecidos=False)
    assert r["novos"] == 1 and r["duplicados"] == 2


def test_desfazer_importacao_bloqueia_conciliado(session, empresa, conta, cat):
    from app.servicos import conciliacao as conc
    from app.servicos.lancamentos import criar
    criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "Fornecedor XYZ", "valor": Decimal("2300.50"),
                                      "vencimento": date(2026, 11, 4), "categoria_id": cat("3.01").id})
    r = conc.importar_arquivo(session, conta, CSV_ITAU, "extrato.csv", None)
    assert r["conciliados_auto"] == 1
    from app.models import ImportacaoExtrato
    from app.servicos import NegocioErro
    with pytest.raises(NegocioErro, match="já foram conciliados"):
        conc.desfazer_importacao(session, session.get(ImportacaoExtrato, r["importacao_id"]), None)


# ============================================================================ Open Finance (Pluggy simulada)

def test_transacao_pluggy():
    t = transacao({"id": "a1", "date": "2026-11-03T00:00:00.000Z", "description": "PIX RECEBIDO", "amount": 150.5,
                   "type": "CREDIT", "status": "POSTED", "paymentData": {"payer": {"name": "Cliente Alfa"}}})
    assert (t.data, t.natureza, t.valor, t.id_externo) == (date(2026, 11, 3), "C", Decimal("150.50"), "pg:a1")
    assert "Cliente Alfa" in t.descricao
    t = transacao({"id": "a2", "date": "2026-11-04T01:30:00.000Z", "description": "Boleto", "amount": -80,
                   "type": "DEBIT", "status": "POSTED"})
    assert (t.data, t.natureza) == (date(2026, 11, 3), "D")          # 01:30 UTC = 22:30 do dia anterior em Brasília
    assert transacao({"id": "a3", "date": "2026-11-04T00:00:00Z", "amount": -5, "type": "DEBIT", "status": "PENDING"}) is None


class PluggyFalsa:
    """Responde como a API da Pluggy, com duas páginas de transações."""
    def __init__(self, status_item="UPDATED"):
        self.chamadas = []
        self.status_item = status_item
        self.excluidos = []

    def __call__(self, req: httpx.Request) -> httpx.Response:
        self.chamadas.append((req.method, req.url.path, dict(req.url.params)))
        p = req.url.path
        if p == "/auth":
            corpo = json.loads(req.content)
            if corpo["clientSecret"] != "segredo":
                return httpx.Response(401, json={"code": 401, "codeDescription": "CLIENT_KEYS_UNAUTHORIZED", "message": "x"})
            return httpx.Response(200, json={"apiKey": "chave"})
        assert req.headers["X-API-KEY"] == "chave"
        if p == "/connect_token":
            return httpx.Response(200, json={"accessToken": "tok"})
        if p == "/items/item1" and req.method == "GET":
            return httpx.Response(200, json={"id": "item1", "status": self.status_item, "lastUpdatedAt": "2099-01-01T00:00:00Z",
                                             "connector": {"name": "Itaú", "imageUrl": "x"}})
        if p == "/items/item1" and req.method == "DELETE":
            self.excluidos.append("item1")
            return httpx.Response(200, json={})
        if p == "/accounts":
            return httpx.Response(200, json={"results": [
                {"id": "acc1", "type": "BANK", "subtype": "CHECKING_ACCOUNT", "name": "Conta Corrente", "number": "12345-6",
                 "balance": 2850.0, "currencyCode": "BRL"}]})
        if p == "/accounts/acc1":
            return httpx.Response(200, json={"id": "acc1", "balance": 2850.0})
        if p == "/v2/transactions":
            if req.url.params.get("after") == "c2":
                return httpx.Response(200, json={"results": [
                    {"id": "t3", "date": "2026-11-05T00:00:00.000Z", "description": "TARIFA", "amount": -9.9, "type": "DEBIT", "status": "POSTED"}],
                    "next": None})
            return httpx.Response(200, json={"results": [
                {"id": "t1", "date": "2026-11-03T00:00:00.000Z", "description": "PIX RECEBIDO ALFA", "amount": 1000, "type": "CREDIT", "status": "POSTED"},
                {"id": "t2", "date": "2026-11-04T00:00:00.000Z", "description": "BOLETO ENERGIA", "amount": -140.1, "type": "DEBIT", "status": "POSTED"}],
                "next": "/v2/transactions?accountId=acc1&after=c2"})
        return httpx.Response(404, json={"message": "não achei " + p})


@pytest.fixture
def pluggy(monkeypatch):
    falsa = PluggyFalsa()
    from app.bancos import pluggy as mod
    original = mod.ClientePluggy.__init__

    def init(self, *a, **kw):
        kw["transport"] = httpx.MockTransport(falsa)
        original(self, *a, **kw)
    monkeypatch.setattr(mod.ClientePluggy, "__init__", init)
    return falsa


def test_open_finance_fluxo_completo(session, empresa, pluggy):
    from app.servicos import NegocioErro
    from app.servicos import openfinance as of
    with pytest.raises(NegocioErro, match="incorretos"):
        of.configurar(session, empresa, None, "cid", "errado")
    of.configurar(session, empresa, None, "cliente-123", "segredo", sandbox=True)
    st = of.situacao(session, empresa)
    assert st["configurado"] and st["sandbox"] and "segredo" not in json.dumps(empresa.integracoes)
    assert of.token(empresa, None)["token"] == "tok"
    info = of.contas_do_item(session, empresa, "item1")
    assert info["banco"] == "Itaú" and info["contas"][0]["numero"] == "12345-6"
    r = of.ligar(session, empresa, None, "item1", [{"account_id": "acc1", "criar": {"nome": "Itaú PJ", "banco_codigo": "341"}}],
                 inicio=date(2026, 11, 1))
    res = r["contas"][0]
    assert res["novos"] == 3 and res["saldo_banco"] == Decimal("2850.00")
    # a paginação usou o cursor
    assert any(c[2].get("after") == "c2" for c in pluggy.chamadas)
    from app.models import ContaBancaria
    conta = session.get(ContaBancaria, res["conta_id"])
    assert conta.integracao == "openfinance" and conta.integracao_config["banco"] == "Itaú"
    # sincronizar de novo não duplica
    assert of.sincronizar(session, conta, None)["novos"] == 0
    # banco pediu nova autorização
    pluggy.status_item = "LOGIN_ERROR"
    with pytest.raises(of.ReconectarErro) as e:
        of.sincronizar(session, conta, None)
    assert e.value.item_id == "item1"
    # desligar revoga a conexão na Pluggy
    of.desligar(session, conta, None)
    assert conta.integracao == "nenhuma" and pluggy.excluidos == ["item1"]


def test_codigo_do_banco_pelo_nome():
    from app.servicos.openfinance import codigo_banco
    assert [codigo_banco(x) for x in ["Itaú", "Banco do Brasil", "Nubank", "Bradesco PJ", "Desconhecido"]] == \
        ["341", "001", "260", "237", None]


def _xlsx_itau(dimensao_errada=True):
    """Mesmo formato do Excel de extrato do Itaú (dados fictícios). O Itaú grava no arquivo um tamanho de
    planilha menor que o real; foi isso que fez a importação trazer só o primeiro movimento."""
    import re
    import zipfile
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Lançamentos"
    for l in [[None], ["Atualização:", "16/11/2026 09:43:43"], ["Nome:", "EMPRESA FICTICIA LTDA"], ["Agência:", "1234"],
              ["Conta:", "0012345-6"], [None], ["Lançamentos"], ["Periodo:", "01/10/2026 até 31/10/2026"], [None],
              ["Data", "Lançamento", "Razão Social", "CPF/CNPJ", "Valor (R$)", "Saldo (R$)"],
              ["30/09/2026", "SALDO ANTERIOR", "", "", None, 641.67],
              ["06/10/2026", "PIX RECEBIDO FULANO06/10", "FULANO DE TAL", "529.982.247-25", 12250.0, None],
              ["06/10/2026", "SALDO TOTAL DISPONÍVEL DIA", "", "", None, 12891.67],
              ["07/10/2026", "PIX RECEBIDO CLIENTE07/10", "CLIENTE EXEMPLO LTDA", "11.222.333/0001-81", 17340.0, None],
              ["07/10/2026", "SALDO TOTAL DISPONÍVEL DIA", "", "", None, 30231.67],
              ["13/10/2026", "PIX ENVIADO", "FORNECEDOR UM", "11.444.777/0001-61", -23231.81, None],
              ["13/10/2026", "BOLETO PAGO", "CONTABILIDADE EXEMPLO", "", -608.0, None],
              ["13/10/2026", "RENDIMENTOS REND PAGO APLIC AUT MAIS", "", "", 0.24, None],
              ["13/10/2026", "SALDO TOTAL DISPONÍVEL DIA", "", "", None, 6392.10],
              ["30/10/2026", "PIX RECEBIDO FULANO30/10", "FULANO DE TAL", "529.982.247-25", 3394.90, None],
              ["30/10/2026", "SALDO TOTAL DISPONÍVEL DIA", "", "", None, 9787.00]]:
        ws.append(l)
    buf = io.BytesIO()
    wb.save(buf)
    if not dimensao_errada:
        return buf.getvalue()
    entrada, saida = zipfile.ZipFile(io.BytesIO(buf.getvalue())), io.BytesIO()
    with zipfile.ZipFile(saida, "w", zipfile.ZIP_DEFLATED) as z:
        for item in entrada.infolist():
            dado = entrada.read(item.filename)
            if item.filename == "xl/worksheets/sheet1.xml":
                dado = re.sub(rb'<dimension ref="[^"]+"', b'<dimension ref="A1:F13"', dado)
            z.writestr(item, dado)
    return saida.getvalue()


def test_extrato_itau_excel_le_todas_as_linhas():
    conteudo = _xlsx_itau()
    linhas = pl.ler_linhas(conteudo, "Extrato itaú outubro.xlsx")
    assert len(linhas) == 18                                   # todas as linhas preenchidas, não só até a 13
    det = pl.detectar(linhas)
    assert {"data", "descricao", "complemento", "cpf_cnpj", "valor", "saldo"} <= det.mapa.keys()
    r = pl.interpretar(linhas, det.linha_cabecalho, det.mapa)
    assert len(r.transacoes) == 6
    assert r.saldo == Decimal("9787.00") and r.data_saldo == date(2026, 10, 30)
    ent = sum(t.valor for t in r.transacoes if t.natureza == "C")
    sai = sum(t.valor for t in r.transacoes if t.natureza == "D")
    assert Decimal("641.67") + ent - sai == r.saldo           # o extrato fecha com o saldo do banco
    t = r.transacoes[0]
    assert t.descricao == "PIX RECEBIDO FULANO06/10 - FULANO DE TAL"
    assert t.dados_brutos["cpf_cnpj"] == "52998224725" and t.dados_brutos["favorecido"] == "FULANO DE TAL"


def test_reimportar_depois_de_importacao_incompleta_nao_duplica(session, empresa, conta):
    from app.servicos import conciliacao as conc
    from app.bancos import TransacaoBanco
    # a importação antiga trouxe só o primeiro PIX, com a descrição curta
    conc.importar(session, conta, [TransacaoBanco(date(2026, 10, 6), Decimal("12250.00"), "C", "PIX RECEBIDO FULANO06/10")],
                  "planilha", None)
    p = conc.previa_extrato(session, conta, _xlsx_itau(), "itau.xlsx")
    assert p["resumo"]["movimentos"] == 6 and p["resumo"]["novos"] == 5 and p["resumo"]["parecidos"] == 1
    r = conc.importar_arquivo(session, conta, _xlsx_itau(), "itau.xlsx", None)
    assert r["novos"] == 5 and r["parecidos"] == 1
    assert conc.importar_arquivo(session, conta, _xlsx_itau(), "itau.xlsx", None)["novos"] == 0


def test_sugestao_pelo_cpf_cnpj_do_extrato(session, empresa, conta, cat):
    from sqlalchemy import select
    from app.models import Contato, Movimento
    from app.servicos import conciliacao as conc
    c = Contato(empresa_id=empresa.id, nome="Cliente Exemplo (cadastro)", tipo="cliente", documento="11222333000181",
                categoria_padrao_id=cat("1.02").id)
    session.add(c)
    session.flush()
    conc.importar_arquivo(session, conta, _xlsx_itau(), "itau.xlsx", None)
    m = session.scalar(select(Movimento).where(Movimento.valor == Decimal("17340.00")))
    sug = conc.sugestao(session, m)
    assert sug["contato_id"] == c.id and sug["categoria_id"] == cat("1.02").id


def test_planilha_de_outra_conta_avisa(session, empresa, conta):
    from app.servicos import NegocioErro
    from app.servicos import conciliacao as conc
    conta.numero = "99999-9"
    p = conc.previa_extrato(session, conta, _xlsx_itau(), "itau.xlsx")
    assert p["conta_no_arquivo"] == "0012345-6" and "não da conta 99999-9" in p["alerta_conta"]
    with pytest.raises(NegocioErro, match="não da conta"):
        conc.importar_arquivo(session, conta, _xlsx_itau(), "itau.xlsx", None)
    assert conc.importar_arquivo(session, conta, _xlsx_itau(), "itau.xlsx", None, forcar=True)["novos"] == 6
    conta.numero = "12345-6"
    assert conc.previa_extrato(session, conta, _xlsx_itau(), "itau.xlsx")["alerta_conta"] is None
