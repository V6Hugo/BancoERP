"""Segurança: proteções web, política de senha, bloqueio por tentativas, sessões no servidor,
verificação em duas etapas, confirmação de senha em ações sensíveis e cifra de segredos."""
import time
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

SENHA = "Cofre-forte-2026"


@pytest.fixture(scope="module")
def app_(engine):
    with engine.begin() as c:
        c.exec_driver_sql("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    from app.main import app
    with TestClient(app, headers={"X-FP": "1"}) as c:
        r = c.post("/api/setup", json={"nome": "Ana Admin", "email": "ana@exemplo.com", "senha": SENHA, "empresa": "Empresa Segura"})
        assert r.status_code == 200, r.text
        c.cookies.clear()
        yield app
    with engine.begin() as c:
        c.exec_driver_sql("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    from app import db
    db.configurar(str(engine.url.render_as_string(hide_password=False)))
    db.Base.metadata.create_all(db.engine())


def cliente(app_, **kw):
    return TestClient(app_, headers={"X-FP": "1", **kw.pop("headers", {})}, **kw)


def entrar(app_, email="ana@exemplo.com", senha=SENHA):
    c = cliente(app_)
    r = c.post("/api/login", json={"email": email, "senha": senha})
    assert r.status_code == 200, r.text
    return c


def sql(q, **p):
    from sqlalchemy import text
    from app import db
    with db.engine().begin() as c:
        return c.execute(text(q), p)


# ---------------------------------------------------------------- proteções web

def test_cabecalhos_csrf_hosts_e_docs(app_):
    c = entrar(app_)
    r = c.get("/api/eu")
    h = r.headers
    assert "frame-ancestors 'none'" in h["content-security-policy"] and "script-src 'self' https://cdn.pluggy.ai" in h["content-security-policy"]
    assert h["x-frame-options"] == "DENY" and h["x-content-type-options"] == "nosniff" and h["cache-control"] == "no-store"
    assert h["referrer-policy"] == "no-referrer"
    # requisição forjada por outro site: sem o cabeçalho da tela, ou com outra origem
    assert TestClient(app_).post("/api/login", json={"email": "x", "senha": "y"}).status_code == 403
    assert c.post("/api/logout", headers={"Origin": "https://site-malicioso.com"}).status_code == 403
    # endereço não permitido (DNS rebinding)
    assert cliente(app_, base_url="http://atacante.com").get("/api/estado").status_code == 400
    # documentação da API desligada
    assert c.get("/docs").status_code == 404 and c.get("/openapi.json").status_code == 404
    assert "?v=" in c.get("/").text and "<script>" not in c.get("/").text      # nenhum script embutido na página


def test_politica_de_senha():
    from app.seguranca import senha_fraca
    assert senha_fraca("abc12345") and senha_fraca("1234567890") and senha_fraca("senhasenha")
    assert senha_fraca("financepro123") and senha_fraca("aaaa1111aa")
    assert "nome" in senha_fraca("joaosilva2026", "joao.silva@x.com", "João Silva")
    assert senha_fraca("Cavalo-bateria-grampo-7") is None


# ---------------------------------------------------------------- login e sessões

def test_login_bloqueia_apos_tentativas_e_nao_revela_quem_existe(app_):
    c = cliente(app_)
    for _ in range(5):
        r = c.post("/api/login", json={"email": "ana@exemplo.com", "senha": "errada-123456"})
        assert r.status_code == 401 and r.json()["detail"] == "E-mail ou senha incorretos."
    r = c.post("/api/login", json={"email": "ana@exemplo.com", "senha": SENHA})
    assert r.status_code == 429                       # mesmo com a senha certa: espere
    assert c.post("/api/login", json={"email": "ninguem@x.com", "senha": "x"}).json()["detail"] == "E-mail ou senha incorretos."
    sql("DELETE FROM auditoria WHERE acao IN ('login_falhou','login_bloqueado')")


def test_sair_encerra_de_verdade_e_inatividade(app_):
    c = entrar(app_)
    token = c.cookies.get("fp_sessao")
    assert c.post("/api/logout").status_code == 200
    roubado = cliente(app_, cookies={"fp_sessao": token})
    assert roubado.get("/api/eu").status_code == 401          # o cookie copiado não vale mais
    c = entrar(app_)
    sql("UPDATE sessoes SET ultimo_uso = now() - interval '2 hours' WHERE encerrada_em IS NULL")
    assert c.get("/api/eu").status_code == 401
    assert sql("SELECT count(*) FROM sessoes WHERE motivo='inatividade'").scalar() >= 1


def test_trocar_senha_encerra_outras_sessoes(app_):
    a, b = entrar(app_), entrar(app_)
    r = a.post("/api/eu/senha", json={"atual": SENHA, "nova": "Outra-senha-forte-9"})
    assert r.status_code == 200 and r.json()["sessoes_encerradas"] >= 1
    assert b.get("/api/eu").status_code == 401 and a.get("/api/eu").status_code == 200
    assert a.post("/api/eu/senha", json={"atual": "Outra-senha-forte-9", "nova": SENHA}).status_code == 200


# ---------------------------------------------------------------- confirmação de senha

def test_acao_sensivel_pede_senha(app_):
    c = entrar(app_)
    E = f"/api/e/{c.get('/api/eu').json()['empresas'][0]['id']}"
    sql("UPDATE sessoes SET confirmada_em = now() - interval '1 hour'")
    r = c.put(f"{E}/openfinance", json={"client_id": "abc", "client_secret": "def"})
    assert r.status_code == 403 and r.json()["confirmar"] is True
    r = c.post(f"{E}/usuarios", json={"email": "novo@x.com", "nome": "Novo", "senha": "Planilha-2026-z", "papel": "leitura"})
    assert r.status_code == 403
    assert c.post("/api/eu/confirmar", json={"senha": "errada-999999"}).status_code == 422
    assert c.post("/api/eu/confirmar", json={"senha": SENHA}).status_code == 200
    r = c.post(f"{E}/usuarios", json={"email": "novo@x.com", "nome": "Novo", "senha": "Planilha-2026-z", "papel": "leitura"})
    assert r.status_code == 200, r.text
    seg = c.get(f"{E}/seguranca").json()
    acoes = {e["acao"] for e in seg["eventos"]}
    assert {"login", "senha_confirmada", "vincular"} <= acoes and seg["config"]["chave_ok"]


# ---------------------------------------------------------------- verificação em duas etapas

def test_verificacao_em_duas_etapas(app_):
    from app.seguranca import codigo_totp
    c = entrar(app_)
    r = c.post("/api/eu/2fa/iniciar").json()
    segredo = r["segredo"].replace(" ", "")
    assert r["uri"].startswith("otpauth://totp/") and "<svg" in r["qr_svg"]
    assert c.post("/api/eu/2fa/ativar", json={"codigo": "000000"}).status_code == 422
    passo = int(time.time() // 30)
    codigos = c.post("/api/eu/2fa/ativar", json={"codigo": codigo_totp(segredo, passo)}).json()["codigos_recuperacao"]
    assert len(codigos) == 8
    # login agora pede o código
    d = cliente(app_)
    assert d.post("/api/login", json={"email": "ana@exemplo.com", "senha": SENHA}).json() == {"etapa": "2fa"}
    assert d.get("/api/eu").status_code == 401                         # só a senha não basta
    assert d.post("/api/login/2fa", json={"codigo": "123456"}).status_code == 422
    assert d.post("/api/login/2fa", json={"codigo": codigo_totp(segredo, passo)}).status_code == 422   # código já usado
    assert d.post("/api/login/2fa", json={"codigo": codigo_totp(segredo, passo + 1)}).status_code == 200
    assert d.get("/api/eu").json()["totp_ativo"] is True
    # código de recuperação vale uma vez
    e = cliente(app_)
    e.post("/api/login", json={"email": "ana@exemplo.com", "senha": SENHA})
    assert e.post("/api/login/2fa", json={"codigo": codigos[0].lower()}).status_code == 200
    f = cliente(app_)
    f.post("/api/login", json={"email": "ana@exemplo.com", "senha": SENHA})
    assert f.post("/api/login/2fa", json={"codigo": codigos[0]}).status_code == 422
    # sem a etapa da senha, o código sozinho não entra
    assert cliente(app_).post("/api/login/2fa", json={"codigo": codigos[1]}).status_code == 401
    # desligar exige senha + código
    sql("UPDATE sessoes SET confirmada_em = now() - interval '1 hour'")
    r = d.post("/api/eu/2fa/desligar")
    assert r.status_code == 403 and r.json()["pedir_codigo"] is True
    assert d.post("/api/eu/confirmar", json={"senha": SENHA}).status_code == 422
    assert d.post("/api/eu/confirmar", json={"senha": SENHA, "codigo": codigos[1]}).status_code == 200
    assert d.post("/api/eu/2fa/desligar").status_code == 200
    sql("DELETE FROM auditoria WHERE acao IN ('login_falhou','2fa_falhou')")


# ---------------------------------------------------------------- segredos

def test_troca_da_secret_key_recifra_tudo(app_, monkeypatch, tmp_path):
    from app import db
    from app.config import get_settings
    from app.main import recifrar_segredos
    from app.seguranca import cifrar, decifrar
    antiga = get_settings().secret_key
    sql("UPDATE empresas SET integracoes = CAST(:j AS jsonb)", j='{"pluggy": {"client_id": "x", "client_secret": "%s"}}' % cifrar("segredo-pluggy"))
    nova = "nova-chave-aleatoria-0123456789abcdefABCDEF"
    monkeypatch.setenv("SECRET_KEY", nova)
    monkeypatch.setenv("SECRET_KEY_ANTERIOR", antiga)
    get_settings.cache_clear()
    try:
        assert recifrar_segredos(db.engine()) >= 1
        monkeypatch.delenv("SECRET_KEY_ANTERIOR")
        get_settings.cache_clear()
        cif = sql("SELECT integracoes->'pluggy'->>'client_secret' FROM empresas").scalar()
        assert decifrar(cif) == "segredo-pluggy"          # só com a chave nova
    finally:
        monkeypatch.setenv("SECRET_KEY", antiga)
        get_settings.cache_clear()


def test_chave_do_certificado_fica_cifrada(tmp_path):
    import io
    import zipfile
    from app.bancos.inter import InterErro, extrair_certificado
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("cert.crt", "-----BEGIN CERTIFICATE-----\nAAA\n-----END CERTIFICATE-----\n")
        z.writestr("chave.key", "-----BEGIN PRIVATE KEY-----\nBBB\n-----END PRIVATE KEY-----\n")
    crt, key = extrair_certificado(buf.getvalue(), "inter.zip", tmp_path)
    assert key.name.endswith(".cifrada") and b"PRIVATE KEY" not in key.read_bytes()
    bomba = io.BytesIO()
    with zipfile.ZipFile(bomba, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("grande.key", b"0" * (3 * 1024 * 1024))
    with pytest.raises(InterErro):
        extrair_certificado(bomba.getvalue(), "inter.zip", tmp_path / "b")


def test_problema_da_chave():
    from app.seguranca import problema_da_chave
    assert problema_da_chave("troque-esta-chave") and problema_da_chave("curta") and problema_da_chave("a" * 40)
    assert problema_da_chave("9f1c2e7a5b3d4c6e8f0a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6") is None
