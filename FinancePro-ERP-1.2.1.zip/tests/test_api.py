"""Fluxo completo pela API: primeiro acesso, permissões, cadastros, lançamentos, extrato e relatórios."""
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def cli(engine):
    with engine.begin() as c:
        c.exec_driver_sql("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    from app.main import app
    with TestClient(app, headers={"X-FP": "1"}) as c:     # sobe a aplicação: aplica as migrações do zero
        yield c
    with engine.begin() as c:            # devolve o esquema para os outros testes
        c.exec_driver_sql("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    from app import db
    db.configurar(str(engine.url.render_as_string(hide_password=False)))
    db.Base.metadata.create_all(db.engine())


def test_fluxo_completo(cli):
    c = cli
    assert c.get("/api/estado").json() == {"configurado": False, "usuario": None, "etapa_2fa": False}
    assert c.get("/api/eu").status_code == 401
    r = c.post("/api/setup", json={"nome": "Victor", "email": "Victor@FinancePro.com", "senha": "Planilha2026x",
                                   "empresa": "Clínica Exemplo", "cnpj": "11.222.333/0001-81"})
    assert r.status_code == 200, r.text
    eu = r.json()
    assert eu["admin_sistema"] and eu["empresas"][0]["papel"] == "admin"
    E = f"/api/e/{eu['empresas'][0]['id']}"
    assert c.post("/api/setup", json={"nome": "Fulano", "email": "x@x.com", "senha": "Planilha2026x", "empresa": "Empresa X"}).status_code == 409

    # plano de contas padrão e edição
    plano = c.get(f"{E}/categorias").json()
    assert len(plano) == 11 and plano[0]["codigo"] == "1" and plano[9]["codigo"] == "10"
    desp_adm = next(g for g in plano if g["codigo"] == "5")
    nova = c.post(f"{E}/categorias", json={"nome": "Assinaturas", "pai_id": desp_adm["id"]}).json()
    assert nova["codigo"] == "5.12" and nova["natureza"] == "despesa"
    assert c.put(f"{E}/categorias/{nova['id']}", json={"nome": "Assinaturas e apps", "pai_id": desp_adm["id"]}).json()["nome"] == "Assinaturas e apps"
    cc = c.post(f"{E}/centros-custo", json={"nome": "Unidade Centro"}).json()
    assert cc["codigo"] == "05"
    cats = {x["codigo"]: x["id"] for g in c.get(f"{E}/categorias").json() for x in [g, *g["categorias"]]}

    # cadastros
    conta = c.post(f"{E}/contas", json={"nome": "Inter PJ", "banco_codigo": "077", "numero": "1234567-8",
                                        "saldo_inicial": "2000", "data_saldo_inicial": "2026-09-30"}).json()
    caixa = c.post(f"{E}/contas", json={"nome": "Caixa da loja", "tipo": "caixa"}).json()
    forn = c.post(f"{E}/contatos", json={"nome": "Energia SA", "tipo": "fornecedor", "documento": "11.444.777/0001-61",
                                         "categoria_padrao_id": cats["5.02"]}).json()
    assert c.post(f"{E}/contatos", json={"nome": "Outro", "documento": "11444777000161"}).status_code == 422   # repetido
    assert c.post(f"{E}/contatos", json={"nome": "Errado", "documento": "123.456.789-00"}).status_code == 422  # inválido
    cli_ = c.post(f"{E}/contatos", json={"nome": "Paciente Maria", "tipo": "cliente"}).json()

    # recebimentos e pagamentos
    hoje = date.today()
    r = c.post(f"{E}/lancamentos", json={"tipo": "pagar", "descricao": "Conta de luz", "valor": "742.13",
                                         "vencimento": "2026-10-10", "contato_id": forn["id"], "categoria_id": cats["5.02"],
                                         "centro_custo_id": cc["id"]})
    assert r.status_code == 201, r.text
    luz = r.json()[0]
    parc = c.post(f"{E}/lancamentos", json={"tipo": "receber", "descricao": "Tratamento", "valor": 900,
                                            "vencimento": (hoje + timedelta(days=5)).isoformat(), "contato_id": cli_["id"],
                                            "categoria_id": cats["1.02"], "parcelas": 3}).json()
    assert len(parc) == 3 and parc[0]["descricao"] == "Tratamento (1/3)"
    assert c.post(f"{E}/lancamentos", json={"tipo": "receber", "descricao": "x", "valor": 10, "vencimento": "2026-10-10",
                                            "categoria_id": cats["5.02"]}).status_code == 422
    b = c.post(f"{E}/lancamentos/{parc[0]['id']}/baixar", json={"data": hoje.isoformat(), "valor": 100,
                                                                "conta_bancaria_id": caixa["id"]}).json()
    assert b["situacao"] == "parcial" and float(b["restante"]) == 200
    lst = c.get(f"{E}/lancamentos", params={"tipo": "receber", "situacao": "abertos"}).json()
    assert lst["total"] == 3 and float(lst["valor_restante"]) == 800
    assert c.get(f"{E}/lancamentos", params={"tipo": "pagar", "busca": "energia"}).json()["total"] == 1   # busca pelo fornecedor

    # extrato OFX: a conta de luz concilia sozinha; a tarifa vira lançamento por regra
    from pathlib import Path
    ofx = (Path(__file__).parent / "extrato_exemplo.ofx").read_bytes().replace(b"56789-0", b"1234567-8")
    imp = c.post(f"{E}/contas/{conta['id']}/importar", files={"arquivo": ("extrato.ofx", ofx)}).json()
    assert imp["novos"] == 6 and imp["conciliados_auto"] == 1
    assert c.get(f"{E}/lancamentos/{luz['id']}").json()["situacao"] == "pago"
    c.post(f"{E}/regras", json={"texto": "tarifa", "natureza": "D", "categoria_id": cats["8.01"]})
    movs = c.get(f"{E}/movimentos", params={"situacao": "pendente"}).json()
    tarifa = next(m for m in movs["itens"] if "TARIFA" in m["descricao"])
    assert tarifa["sugestao"]["origem"] == "regra" and tarifa["sugestao"]["categoria_id"] == cats["8.01"]
    assert c.post(f"{E}/movimentos/lancar-sugeridos", json={}).json() == {"lancados": 1, "sem_regra": 4}
    iof = next(m for m in movs["itens"] if m["descricao"] == "IOF")
    assert c.post(f"{E}/movimentos/{iof['id']}/lancar", json={"categoria_id": cats["8.03"], "criar_regra": "IOF"}).status_code == 200
    aplic = next(m for m in movs["itens"] if "APLICACAO" in m["descricao"])
    invest = c.post(f"{E}/contas", json={"nome": "CDB", "tipo": "investimento"}).json()
    assert c.post(f"{E}/movimentos/{aplic['id']}/transferencia", json={"outra_conta_id": invest["id"]}).status_code == 200

    # saldos, fluxo e relatórios
    s = c.get(f"{E}/saldos").json()
    inter = next(x for x in s["contas"] if x["conta_id"] == conta["id"])
    assert inter["pendentes_conciliar"] == 2
    f = c.get(f"{E}/fluxo", params={"inicio": "2026-10-01", "fim": "2026-12-31", "agrupamento": "mes"}).json()
    assert f["periodos"][0]["periodo"] == "2026-10-01" and float(f["saldo_inicial"]) == 2000
    d = c.get(f"{E}/relatorios/dre", params={"inicio": "2026-10-01", "fim": "2026-10-31"}).json()
    desp_fin = next(x for x in d["linhas"] if x.get("grupo") == "despesas_financeiras")
    assert float(desp_fin["total"]) == round(89.90 + 1.52, 2)
    comp = c.get(f"{E}/relatorios/comparativo", params={"meses": "2026-09,2026-10", "dimensao": "centro_custo", "tipo": "pagar"}).json()
    assert any(l["nome"].endswith("Unidade Centro") for l in comp["linhas"])
    det = c.get(f"{E}/relatorios/detalhe", params={"inicio": "2026-10-01", "fim": "2026-10-31", "chave": f"c:{cats['5.02']}"}).json()
    assert len(det) == 1 and det[0]["descricao"] == "Conta de luz"
    for url in ("dre.xlsx", "comparativo.xlsx?meses=2026-09,2026-10", "lancamentos.xlsx?tipo=pagar"):
        x = c.get(f"{E}/relatorios/{url}")
        assert x.status_code == 200 and x.content[:2] == b"PK", url
    res = c.get(f"{E}/relatorios/resumo", params={"inicio": "2026-10-01", "fim": "2026-10-31"}).json()
    assert float(res["saidas"]) == round(742.13 + 89.90 + 1.52, 2)

    # permissões: usuário de leitura vê mas não lança; outra empresa não aparece
    c.post(f"{E}/usuarios", json={"nome": "Contador", "email": "contador@x.com", "senha": "Balancete2026", "papel": "leitura"})
    outra = c.post("/api/empresas", json={"nome": "Outra Ltda"}).json()
    c.post("/api/logout")
    assert c.post("/api/login", json={"email": "contador@x.com", "senha": "errada12345"}).status_code == 401
    eu2 = c.post("/api/login", json={"email": "contador@x.com", "senha": "Balancete2026"}).json()
    assert [e["nome"] for e in eu2["empresas"]] == ["Clínica Exemplo"]
    assert c.get(f"{E}/lancamentos").status_code == 200
    assert c.post(f"{E}/lancamentos", json={"tipo": "pagar", "descricao": "x", "valor": 1, "vencimento": "2026-10-10"}).status_code == 403
    assert c.get(f"/api/e/{outra['id']}/lancamentos").status_code == 404
    assert c.get(f"{E}/usuarios").status_code == 403


def test_extrato_por_planilha_pela_api(cli):
    c = cli
    eu = c.post("/api/login", json={"email": "victor@financepro.com", "senha": "Planilha2026x"}).json()
    E = f"/api/e/{eu['empresas'][0]['id']}"
    r = c.post(f"{E}/contas", json={"nome": "Itaú PJ 2", "banco_codigo": "341", "numero": "56789-0"})
    assert r.status_code in (200, 201), r.text
    conta = r.json()
    csv = ("Data;Histórico;Valor;Saldo\n03/11/2026;PIX RECEBIDO CLIENTE;1.000,00;\n"
           "04/11/2026;BOLETO ALUGUEL;-700,00;300,00\n").encode()
    arq = {"arquivo": ("itau.csv", csv, "text/csv")}
    p = c.post(f"{E}/contas/{conta['id']}/extrato/previa", files=arq)
    assert p.status_code == 200, p.text
    p = p.json()
    assert p["resumo"]["movimentos"] == 2 and p["colunas"][p["mapa"]["valor"]] == "Valor"
    # trocar o mapeamento: sem a coluna de saldo
    mapa = {k: v for k, v in p["mapa"].items() if k != "saldo"}
    p2 = c.post(f"{E}/contas/{conta['id']}/extrato/previa", files=arq, data={"mapa": __import__("json").dumps(mapa)}).json()
    assert p2["saldo_banco"] is None
    r = c.post(f"{E}/contas/{conta['id']}/importar", files=arq).json()
    assert r["novos"] == 2 and float(r["saldo_banco"]) == 300.0
    hist = c.get(f"{E}/importacoes?conta_id={conta['id']}").json()
    assert hist[0]["origem"] == "planilha" and hist[0]["pendentes"] == 2
    assert c.delete(f"{E}/importacoes/{hist[0]['id']}").json() == {"removidos": 2}
    m = c.get(f"{E}/modelo-extrato.xlsx")
    assert m.status_code == 200 and m.content[:2] == b"PK"
    assert c.get(f"{E}/openfinance").json()["configurado"] is False
    assert c.post(f"{E}/openfinance/token", json={}).status_code == 422
    vazio = c.post(f"{E}/contas/{conta['id']}/extrato/previa", files={"arquivo": ("x.csv", b"  ", "text/csv")})
    assert vazio.status_code == 422
