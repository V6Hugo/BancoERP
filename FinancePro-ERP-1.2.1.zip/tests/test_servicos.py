from datetime import date
from pathlib import Path
from decimal import Decimal as D

import httpx
import pytest
from sqlalchemy import func, select

from app.bancos import TransacaoBanco
from app.models import Baixa, Categoria, CentroCusto, ContaBancaria, Contato, Lancamento, Movimento, RegraClassificacao
from app.servicos import NegocioErro
from app.servicos import conciliacao as conc
from app.servicos import financeiro as fin
from app.servicos import lancamentos as svc
from app.servicos import relatorios as rel
from app.servicos.empresas import criar_empresa

HOJE = date(2026, 10, 20)


def test_empresa_nasce_com_plano_e_centros(session, empresa):
    n = session.scalar(select(func.count(Categoria.id)).where(Categoria.empresa_id == empresa.id))
    grupos = session.scalar(select(func.count(Categoria.id)).where(Categoria.empresa_id == empresa.id, Categoria.pai_id.is_(None)))
    assert grupos == 11 and n > 50
    assert session.scalar(select(func.count(CentroCusto.id)).where(CentroCusto.empresa_id == empresa.id)) == 4
    with pytest.raises(NegocioErro):
        criar_empresa(session, "Outra", "11.222.333/0001-81")        # CNPJ repetido
    with pytest.raises(NegocioErro):
        criar_empresa(session, "Outra", "11.111.111/1111-11")        # CNPJ inválido


def test_parcelas_somam_o_total_e_vencem_mes_a_mes(session, empresa, cat):
    ls = svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "Notebook", "valor": "1000,00",
                                               "vencimento": date(2026, 1, 31), "categoria_id": cat("10.03").id, "parcelas": 3})
    assert [l.valor for l in ls] == [D("333.33"), D("333.33"), D("333.34")]
    assert [l.vencimento for l in ls] == [date(2026, 1, 31), date(2026, 2, 28), date(2026, 3, 31)]
    assert ls[1].descricao == "Notebook (2/3)" and len({l.grupo_parcelas for l in ls}) == 1
    rec = svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "Aluguel", "valor": 2500,
                                                "vencimento": date(2026, 1, 10), "categoria_id": cat("5.01").id, "repetir_meses": 12})
    assert len(rec) == 12 and all(l.valor == 2500 for l in rec) and rec[-1].competencia == date(2026, 12, 10)


def test_validacoes(session, empresa, cat):
    with pytest.raises(NegocioErro, match="grupo"):
        svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "x", "valor": 10, "vencimento": HOJE, "categoria_id": cat("5").id})
    with pytest.raises(NegocioErro, match="não combina"):
        svc.criar(session, empresa.id, None, {"tipo": "receber", "descricao": "x", "valor": 10, "vencimento": HOJE, "categoria_id": cat("5.01").id})
    with pytest.raises(NegocioErro, match="maior que zero"):
        svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "x", "valor": 0, "vencimento": HOJE})
    outra = criar_empresa(session, "Outra empresa")
    cat_outra = session.scalar(select(Categoria).where(Categoria.empresa_id == outra.id, Categoria.codigo == "5.01"))
    with pytest.raises(NegocioErro, match="nesta empresa"):
        svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "x", "valor": 10, "vencimento": HOJE, "categoria_id": cat_outra.id})


def test_baixa_parcial_estorno_e_cancelamento(session, empresa, cat, conta):
    l = svc.criar(session, empresa.id, None, {"tipo": "receber", "descricao": "Serviço", "valor": 1000, "vencimento": HOJE,
                                              "categoria_id": cat("1.02").id})[0]
    b1 = svc.baixar(session, l, None, HOJE, 400, conta.id)
    assert l.situacao == "parcial" and svc.restante(l) == 600
    with pytest.raises(NegocioErro, match="maior que o que falta"):
        svc.baixar(session, l, None, HOJE, 700, conta.id)
    svc.baixar(session, l, None, HOJE, 600, conta.id, juros=12)
    assert l.situacao == "pago"
    with pytest.raises(NegocioErro, match="baixas"):
        svc.cancelar(session, l, None)
    svc.estornar_baixa(session, b1, None)
    assert l.situacao == "parcial" and svc.restante(l) == 400
    with pytest.raises(NegocioErro, match="não pode ficar menor"):
        svc.atualizar(session, l, None, {"valor": 500})
    assert fin.saldo_conta(session, conta)["saldo"] == D("1612.00")     # 1000 inicial + 600 + 12 de juros


def test_fluxo_realizado_e_previsto(session, empresa, cat, conta):
    l1 = svc.criar(session, empresa.id, None, {"tipo": "receber", "descricao": "Cliente A", "valor": 5000,
                                               "vencimento": date(2026, 10, 5), "categoria_id": cat("1.02").id})[0]
    svc.baixar(session, l1, None, date(2026, 10, 6), 5000, conta.id)
    svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "Fornecedor", "valor": 1500,
                                          "vencimento": date(2026, 10, 15), "categoria_id": cat("3.01").id})   # vencido em 20/10
    svc.criar(session, empresa.id, None, {"tipo": "receber", "descricao": "Cliente B", "valor": 3000,
                                          "vencimento": date(2026, 11, 10), "categoria_id": cat("1.02").id})
    f = fin.fluxo_caixa(session, empresa.id, date(2026, 10, 1), date(2026, 11, 30), "mes", hoje=HOJE)
    out, nov = f["periodos"]
    assert f["saldo_inicial"] == 1000 and out["entradas"] == 5000 and out["saldo"] == 6000
    assert out["saidas_previstas"] == 1500 and f["vencidos"]["pagar"] == 1500       # vencido entra como previsto hoje
    assert nov["entradas_previstas"] == 3000 and nov["saldo_projetado"] == D("7500.00")


def test_ofx_importa_sem_duplicar_e_concilia_sozinho(session, empresa, cat, conta):
    l = svc.criar(session, empresa.id, None, {"tipo": "pagar", "descricao": "Energia", "valor": D("742.13"),
                                              "vencimento": date(2026, 10, 10), "categoria_id": cat("5.02").id})[0]
    ofx = open(Path(__file__).parent / "extrato_exemplo.ofx", "rb").read().replace(b"56789-0", b"1234567-8")
    ofx = ofx.replace(b"-742,13", b"-742,13")
    r = conc.importar_ofx(session, conta, ofx, "extrato.ofx", None)
    assert r["novos"] == 6 and r["duplicados"] == 0
    r2 = conc.importar_ofx(session, conta, ofx, "extrato.ofx", None)
    assert r2["novos"] == 0 and r2["duplicados"] == 6
    with pytest.raises(NegocioErro, match="não da conta"):
        outra = ContaBancaria(empresa_id=empresa.id, nome="Itaú", numero="99999-9")
        session.add(outra)
        session.flush()
        conc.importar_ofx(session, outra, ofx, "extrato.ofx", None)
    movs = session.scalars(select(Movimento).where(Movimento.conta_bancaria_id == conta.id)).all()
    energia = next(m for m in movs if m.valor == D("742.13"))     # boleto de energia de 05/10 = conta de 10/10
    assert energia.situacao == "conciliado" and l.situacao == "pago" and l.baixas[0].data == date(2026, 10, 5)
    assert sum(m.situacao == "pendente" for m in movs) == 5 and "SERVIÇOS" in movs[0].descricao + "".join(m.descricao for m in movs)


def test_regra_lanca_tarifa_e_transferencia(session, empresa, cat, conta):
    session.add(RegraClassificacao(empresa_id=empresa.id, texto="tarifa", natureza="D", categoria_id=cat("8.01").id))
    poup = ContaBancaria(empresa_id=empresa.id, nome="Aplicação", tipo="investimento")
    session.add(poup)
    session.flush()
    conc.importar(session, conta, [
        TransacaoBanco(date(2026, 10, 1), D("89.90"), "D", "TARIFA CESTA PJ", "t1"),
        TransacaoBanco(date(2026, 10, 2), D("5000"), "D", "APLICACAO CDB", "t2"),
        TransacaoBanco(date(2026, 10, 3), D("10"), "C", "PIX RECEBIDO FULANO", "t3"),
    ], "ofx", None)
    r = conc.lancar_sugeridos(session, empresa.id, None)
    assert r == {"lancados": 1, "sem_regra": 2}
    tarifa = session.scalar(select(Lancamento).where(Lancamento.empresa_id == empresa.id, Lancamento.descricao == "TARIFA CESTA PJ"))
    assert tarifa.situacao == "pago" and tarifa.categoria.codigo == "8.01"
    t = fin.transferir(session, empresa.id, None, conta.id, poup.id, date(2026, 10, 2), 5000)
    m = session.scalar(select(Movimento).where(Movimento.id_externo == "t2"))
    assert m.situacao == "conciliado" and m.transferencia_id == t.id
    s = fin.saldos(session, empresa.id)
    inter = next(x for x in s["contas"] if x["conta_id"] == conta.id)
    assert inter["saldo"] == D("1000") - D("89.90") - 5000 and s["total_disponivel"] == D("1000") - D("89.90")
    assert inter["saldo_extrato"] == D("1000") - D("89.90") - 5000 + 10 and inter["diferenca"] == 10   # o Pix ainda não lançado
    conc.desfazer(session, m, None)
    assert m.situacao == "pendente" and session.get(type(t), t.id) is None


def test_dre_e_comparativo(session, empresa, cat, conta):
    cc = session.scalar(select(CentroCusto).where(CentroCusto.empresa_id == empresa.id, CentroCusto.codigo == "02"))
    def pago(tipo, cod, valor, dia, **kw):
        l = svc.criar(session, empresa.id, None, {"tipo": tipo, "descricao": cod, "valor": valor, "vencimento": dia,
                                                  "categoria_id": cat(cod).id, **kw})[0]
        svc.baixar(session, l, None, dia, valor, conta.id)
    pago("receber", "1.02", 10000, date(2026, 9, 10))
    pago("receber", "1.02", 12000, date(2026, 10, 10))
    pago("pagar", "2.01", 600, date(2026, 9, 20))
    pago("pagar", "6.01", 1000, date(2026, 9, 15), centro_custo_id=cc.id)
    pago("pagar", "6.01", 1500, date(2026, 10, 15), centro_custo_id=cc.id)
    pago("pagar", "11.04", 3000, date(2026, 10, 30))                    # distribuição de lucro: fora do resultado
    d = rel.dre(session, empresa.id, date(2026, 9, 1), date(2026, 10, 31))
    sub = {x["nome"]: x for x in d["linhas"] if x["tipo"] == "subtotal"}
    assert sub["Receita líquida"]["valores"] == {"2026-09": D("9400"), "2026-10": D("12000")}
    assert sub["Resultado líquido"]["valores"] == {"2026-09": D("8400"), "2026-10": D("10500")}
    assert d["margem_liquida"]["2026-10"] == D("87.5")
    c = rel.comparativo(session, empresa.id, ["2026-09", "2026-10"], "categoria", "pagar")
    mkt = next(x for x in c["linhas"] if x["nome"].startswith("6.01"))
    assert mkt["valores"] == {"2026-09": D("1000"), "2026-10": D("1500")} and mkt["variacao"]["2026-10"]["pct"] == D("50.0")
    cc_l = rel.comparativo(session, empresa.id, ["2026-09", "2026-10"], "centro_custo", "pagar")
    assert next(x for x in cc_l["linhas"] if x["chave"] == f"cc:{cc.id}")["total"] == 2500
    det = rel.detalhe(session, empresa.id, date(2026, 9, 1), date(2026, 10, 31), chave=f"c:{cat('6.01').id}")
    assert [x["valor"] for x in det] == [D("1000"), D("1500")]
    r = rel.resumo(session, empresa.id, date(2026, 10, 1), date(2026, 10, 31), hoje=HOJE)
    assert r["entradas"] == 12000 and r["saidas"] == 4500


def test_competencia_x_caixa(session, empresa, cat, conta):
    svc.criar(session, empresa.id, None, {"tipo": "receber", "descricao": "Venda a prazo", "valor": 800,
                                          "vencimento": date(2026, 11, 10), "competencia": date(2026, 10, 1),
                                          "categoria_id": cat("1.01").id})
    comp = rel.dre(session, empresa.id, date(2026, 10, 1), date(2026, 10, 31), "competencia")
    caixa = rel.dre(session, empresa.id, date(2026, 10, 1), date(2026, 10, 31), "caixa")
    rb = lambda d: next(x for x in d["linhas"] if x.get("grupo") == "receita_bruta")["total"]
    assert rb(comp) == 800 and rb(caixa) == 0


def test_cliente_inter_com_api_simulada(session, empresa, conta, tmp_path):
    chamadas = []

    def api(req: httpx.Request):
        chamadas.append((req.method, req.url.path, dict(req.url.params)))
        if req.url.path == "/oauth/v2/token":
            assert b"scope=extrato.read" in req.content and b"grant_type=client_credentials" in req.content
            return httpx.Response(200, json={"access_token": "tok", "expires_in": 3600})
        assert req.headers["Authorization"] == "Bearer tok"
        if req.url.path == "/banking/v2/saldo":
            return httpx.Response(200, json={"disponivel": 1234.56})
        pag = int(req.url.params["pagina"])
        trans = [{"idTransacao": f"id{pag}", "dataTransacao": "2026-10-05", "tipoOperacao": "C" if pag == 0 else "D",
                  "valor": "150.00", "titulo": "Pix recebido" if pag == 0 else "Pagamento", "descricao": "CLIENTE X"}]
        return httpx.Response(200, json={"totalPaginas": 2, "transacoes": trans})

    import io
    import zipfile
    z = io.BytesIO()
    with zipfile.ZipFile(z, "w") as f:
        f.writestr("Inter API_Certificado.crt", "-----BEGIN CERTIFICATE-----\nx\n-----END CERTIFICATE-----\n")
        f.writestr("Inter API_Chave.key", "-----BEGIN PRIVATE KEY-----\nx\n-----END PRIVATE KEY-----\n")
    conc.configurar_inter(session, conta, None, "meu-client-id", "meu-segredo", z.getvalue(), "inter.zip")
    assert conta.integracao == "inter" and conta.integracao_config["client_secret"] != "meu-segredo"   # cifrado
    r = conc.sincronizar_inter(session, conta, None, date(2026, 10, 1), date(2026, 10, 31),
                               transport=httpx.MockTransport(api))
    assert r["novos"] == 2 and r["saldo_banco"] == D("1234.56") and conta.ultima_sincronizacao
    m = session.scalar(select(Movimento).where(Movimento.id_externo == "id0"))
    assert m.natureza == "C" and m.descricao == "Pix recebido: CLIENTE X" and m.origem == "api_inter"
    r2 = conc.sincronizar_inter(session, conta, None, date(2026, 10, 1), date(2026, 10, 31), transport=httpx.MockTransport(api))
    assert r2["novos"] == 0 and r2["duplicados"] == 2
