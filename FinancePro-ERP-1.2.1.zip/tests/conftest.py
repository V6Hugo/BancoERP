import os
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

# PostgreSQL de teste (o mesmo motor da produção). Ex.: postgresql+psycopg://postgres@127.0.0.1:5433/financepro_teste
URL = os.environ.get("FP_TESTE_DB", "postgresql+psycopg://postgres@127.0.0.1:5433/financepro_teste")


@pytest.fixture(scope="session")
def engine(tmp_path_factory):
    os.environ.update(DATABASE_URL=URL, SECRET_KEY="chave-de-teste-com-mais-de-32-caracteres-ok", HOSTS_PERMITIDOS="localhost,127.0.0.1,testserver",
                      PASTA_CERTIFICADOS=str(tmp_path_factory.mktemp("certs")))
    from app.config import get_settings
    get_settings.cache_clear()
    from app import db, models  # noqa: F401
    eng = db.configurar(URL)
    with eng.begin() as c:
        c.exec_driver_sql("DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;")
    db.Base.metadata.create_all(eng)
    yield eng
    eng.dispose()


@pytest.fixture
def session(engine):
    """Cada teste roda numa transação que é desfeita no fim (banco limpo entre testes)."""
    from sqlalchemy.orm import Session
    conn = engine.connect()
    trans = conn.begin()
    s = Session(bind=conn, join_transaction_mode="create_savepoint", autoflush=False, expire_on_commit=False)
    yield s
    s.close()
    trans.rollback()
    conn.close()


@pytest.fixture
def empresa(session):
    from app.servicos.empresas import criar_empresa
    return criar_empresa(session, "Empresa Teste", "11.222.333/0001-81")


@pytest.fixture
def cat(session, empresa):
    from sqlalchemy import select
    from app.models import Categoria

    def _c(codigo):
        return session.scalar(select(Categoria).where(Categoria.empresa_id == empresa.id, Categoria.codigo == codigo))
    return _c


@pytest.fixture
def conta(session, empresa):
    from datetime import date
    from decimal import Decimal
    from app.models import ContaBancaria
    c = ContaBancaria(empresa_id=empresa.id, nome="Inter PJ", banco_codigo="077", agencia="0001", numero="1234567-8",
                      saldo_inicial=Decimal("1000.00"), data_saldo_inicial=date(2026, 9, 30))
    session.add(c)
    session.flush()
    return c
