@echo off
chcp 65001 >nul
title FinancePro ERP
cd /d "%~dp0"

rem ---- precisa do Docker Desktop (PostgreSQL e a aplicacao rodam nele)
where docker >nul 2>nul || goto semdocker
docker info >nul 2>nul
if errorlevel 1 (
  echo   Ligando o Docker Desktop. Depois de reiniciar o computador isso leva de 1 a 3 minutos...
  if exist "%ProgramFiles%\Docker\Docker\Docker Desktop.exe" start "" "%ProgramFiles%\Docker\Docker\Docker Desktop.exe"
  call :esperar_docker || exit /b 1
)

rem ---- primeira vez: senhas aleatorias e pastas
if not exist ".env" call :criar_env
if not exist "dados\backups" mkdir "dados\backups"
if not exist "dados\certificados" mkdir "dados\certificados"

echo.
echo   Iniciando o FinancePro ERP (na primeira vez leva alguns minutos)...
docker compose up -d --build
if errorlevel 1 goto erro

set "PORTA=8080"
for /f "tokens=2 delims==" %%P in ('findstr /b "PORTA=" .env') do set "PORTA=%%P"
call :esperar_app
call :atalho
start "" "http://localhost:%PORTA%"
echo.
echo   FinancePro ERP aberto em http://localhost:%PORTA%
echo   Ele continua rodando em segundo plano. Para parar, use "Parar FinancePro.bat".
timeout /t 8 >nul
exit /b 0

rem =====================================================================
:criar_env
for /f %%K in ('powershell -NoProfile -Command "$b=New-Object byte[] 32; (New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($b); -join ($b|%%{'{0:x2}' -f $_})"') do set "CHAVE=%%K"
for /f %%K in ('powershell -NoProfile -Command "$b=New-Object byte[] 24; (New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($b); -join ($b|%%{'{0:x2}' -f $_})"') do set "SENHA=%%K"
(
  echo # Gerado na primeira execucao. Guarde uma copia deste arquivo em lugar seguro.
  echo DB_SENHA=%SENHA%
  echo SECRET_KEY=%CHAVE%
  echo PORTA=8080
  echo # Acesso: 127.0.0.1 = so este computador. Veja SEGURANCA.md antes de liberar na rede.
  echo ENDERECO=127.0.0.1
  echo HOSTS_PERMITIDOS=localhost,127.0.0.1
  echo SESSAO_INATIVIDADE_MIN=60
  echo COOKIE_SEGURO=false
  echo SINCRONIZAR_BANCOS_MIN=0
) > .env
echo   Configuracao criada em .env (senhas aleatorias).
rem so o seu usuario do Windows pode ler o .env (tem as chaves do sistema)
icacls .env /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1
exit /b 0

:esperar_docker
set /a N=0
:ed_loop
docker info >nul 2>nul && (echo. & echo   Docker pronto. & exit /b 0)
set /a N+=1
rem um ponto a cada 3 segundos, para mostrar que esta andando
<nul set /p "=."
if %N% geq 100 (
  echo.
  echo   O Docker Desktop nao respondeu em 5 minutos. Abra o Docker Desktop, espere ele ficar pronto e rode este atalho de novo.
  pause
  exit /b 1
)
timeout /t 3 >nul
goto ed_loop

:esperar_app
echo   Aguardando o sistema responder...
rem consulta 127.0.0.1 (IPv4): o sistema so escuta neste endereco; "localhost" no PowerShell pode tentar IPv6 e demorar
powershell -NoProfile -Command "$u='http://127.0.0.1:%PORTA%/saude'; for($i=0;$i -lt 90;$i++){ try { if((Invoke-WebRequest $u -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200){ exit 0 } } catch {}; Start-Sleep -Seconds 1 }; exit 1"
if errorlevel 1 echo   A aplicacao demorou para responder. Veja o motivo com: docker compose logs app
exit /b 0

:atalho
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop'); $l=Join-Path $d 'FinancePro ERP.lnk'; if(-not (Test-Path $l)){ $s=(New-Object -ComObject WScript.Shell).CreateShortcut($l); $s.TargetPath='%~f0'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0app\web\favicon.ico'; $s.Save(); Write-Host '  Atalho criado na Area de Trabalho.' }" 2>nul
exit /b 0

:semdocker
echo.
echo   O FinancePro ERP usa o Docker Desktop (para o banco PostgreSQL).
echo   Instale em https://www.docker.com/products/docker-desktop/ e rode este arquivo de novo.
echo.
pause
exit /b 1

:erro
echo.
echo   Algo deu errado. Leia a mensagem acima.
echo   Para ver o registro da aplicacao: docker compose logs app
echo.
pause
exit /b 1
