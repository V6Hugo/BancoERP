# Segurança do FinancePro ERP

Um ERP ligado a bancos guarda dois tipos de dado sensível: o **financeiro da empresa** e as **credenciais de acesso aos bancos**. Esta página diz como o sistema protege cada um e o que fica a cargo de quem o usa.

## O que o sistema já faz

### Acesso e senhas
- **Senhas fortes:** pelo menos 10 caracteres, com letras e números. São recusadas as senhas comuns e as que contêm o nome ou o e-mail da pessoa.
- **Senhas guardadas com bcrypt.** Nem o administrador consegue lê-las.
- **Bloqueio por tentativas:** depois de 5 erros de senha em 15 minutos, aquele e-mail fica bloqueado por 15 minutos. Isso vale mesmo que alguém tente depois com a senha certa.
- **Mensagem única para erro de login:** "E-mail ou senha incorretos". A tela não revela se o e-mail existe.
- **Verificação em duas etapas (TOTP)**, ligada em *Minha conta*, funciona com Google Authenticator, Microsoft Authenticator ou Authy:
  - Além da senha, o login pede o código de 6 números do celular. Cada código só vale uma vez.
  - Junto vêm 8 **códigos de recuperação**, para o caso de perder o celular. Cada um também vale uma vez.
  - Se a pessoa perder o celular e os códigos, o administrador do sistema pode redefinir a verificação.

### Sessões
- **A sessão fica no servidor.** O navegador guarda só um código aleatório num cookie protegido (HttpOnly, SameSite=Strict); o banco de dados guarda apenas o hash desse código.
- **"Sair" encerra a sessão de verdade.** Um cookie copiado deixa de valer.
- **Fim por inatividade:** a sessão termina após 60 minutos sem uso (ajustável em `SESSAO_INATIVIDADE_MIN`) e dura no máximo 12 horas.
- **Trocar a senha** ou **ligar a verificação em duas etapas** encerra as outras sessões abertas.
- **Encerrar sessões:** cada usuário vê onde está conectado e pode encerrar as outras sessões. O administrador pode encerrar as sessões de qualquer usuário ou bloqueá-lo, por exemplo um funcionário que saiu.

### Ações sensíveis pedem a senha de novo
Por 10 minutos depois de confirmar a senha, o sistema libera estas ações:
- configurar ou remover as credenciais do **Inter** e do **Open Finance**;
- conectar ou desconectar contas bancárias;
- dar ou tirar acesso de usuários;
- redefinir a verificação em duas etapas, bloquear usuários e encerrar sessões de outros;
- ligar ou desligar a sua própria verificação em duas etapas.

Quem usa a verificação em duas etapas também digita o código.

### Credenciais dos bancos
- **Client Secret do Inter e da Pluggy:** ficam cifrados (Fernet/AES) com a `SECRET_KEY`.
- **Chave privada do certificado do Inter:** fica cifrada no disco. Só é aberta num arquivo temporário no momento da sincronização, que é apagado em seguida.
- **Arquivo .zip do certificado:** o envio é limitado em número e tamanho de arquivos, contra arquivos maliciosos.
- **Open Finance:** o FinancePro só lê extrato e saldo. Não existe no sistema nenhuma função que faça pagamento ou transferência.

### Navegador e rede
- **Acesso só pelo próprio computador:** a porta escuta em `127.0.0.1`. Outros aparelhos da rede (Wi-Fi da empresa, visitantes) não chegam nem à tela de login.
- **Hosts permitidos:** o sistema só responde pelos endereços configurados, o que bloqueia o ataque de "DNS rebinding".
- **Proteção contra requisições forjadas (CSRF):** toda alteração exige um cabeçalho que só a própria tela envia e precisa vir da mesma origem.
- **Política de conteúdo (CSP):** a página só executa scripts do próprio sistema e da janela de conexão da Pluggy. Não há scripts embutidos na página.
- **Outros cabeçalhos:**
  - a página não pode ser aberta dentro de outro site (contra *clickjacking*);
  - `nosniff` e `no-referrer`;
  - câmera, microfone e localização bloqueados;
  - dados financeiros não ficam no cache do navegador.
- A documentação interativa da API (`/docs`) fica desligada.

### Banco de dados e servidor
- O PostgreSQL não tem porta aberta: só a aplicação, dentro do Docker, fala com ele.
- Os containers rodam sem privilégios extras. A aplicação roda com um usuário comum, não como root.
- O sistema não inicia com uma `SECRET_KEY` fraca ou de exemplo.
- O `Iniciar FinancePro.bat` gera as chaves com o gerador criptográfico do Windows e deixa o `.env` legível só pelo seu usuário.
- **Registro de eventos** em *Cadastros › Segurança*:
  - entradas e saídas;
  - erros de senha e bloqueios;
  - mudanças na verificação em duas etapas;
  - mudanças de acesso;
  - mudanças nas credenciais de banco;
  - exportações para Excel.

## O que fica com você

1. **Ligue a verificação em duas etapas** para todos que usam o sistema, a começar pelos administradores.
2. **Guarde uma cópia do `.env` fora do computador**, por exemplo num pendrive guardado ou num cofre de senhas. Sem a `SECRET_KEY` dele, as credenciais de banco cadastradas não podem ser lidas.
3. **Proteja o computador:**
   - Windows atualizado e antivírus ligado (o Microsoft Defender costuma bastar);
   - senha forte no usuário do Windows e bloqueio de tela automático;
   - **BitLocker** ligado no disco (Configurações › Privacidade e segurança › Criptografia do dispositivo), porque os backups em `dados\backups` têm todo o financeiro da empresa.
4. **Leve uma cópia dos backups para fora do computador** com frequência. Um backup que só existe na mesma máquina se perde junto com ela, num roubo, defeito ou ransomware.
5. **Uma pessoa, um usuário.** Não compartilhe login. Dê o papel mínimo necessário: o contador fica com *Só consulta*. Quando alguém sair da empresa, bloqueie o usuário no mesmo dia.
6. **Credenciais dos bancos:**
   - crie as integrações (Inter e Pluggy) só com a permissão de **consultar extrato e saldo**;
   - se suspeitar de vazamento, gere um novo Client Secret no banco e cadastre de novo.
7. **Olhe *Cadastros › Segurança* de vez em quando.** Erros de senha que você não reconhece são um sinal de alerta.
8. **Golpes:** nenhum banco, nem a Pluggy, pede senha por telefone, WhatsApp ou e-mail. A autorização do Open Finance acontece sempre no app ou no site do próprio banco.

## Se precisar abrir na rede da empresa

O padrão é só este computador. Para outros computadores da empresa acessarem:

1. No `.env`, troque `ENDERECO=127.0.0.1` por `ENDERECO=0.0.0.0`.
2. Ponha em `HOSTS_PERMITIDOS` o nome ou IP pelo qual vão acessar, por exemplo `localhost,127.0.0.1,192.168.0.10`.
3. **Use HTTPS.** Coloque um proxy com certificado (por exemplo o Caddy) na frente e defina `COOKIE_SEGURO=true`. Sem HTTPS, as senhas trafegam abertas na rede.
4. No Firewall do Windows, libere a porta só para a rede da empresa, nunca para "Público".
5. **Nunca** exponha a porta 8080 direto na internet (redirecionamento de porta no roteador). Para acesso de fora, use VPN ou um servidor com HTTPS (veja o README).

## Trocar a SECRET_KEY

Faça isso se suspeitar que o `.env` vazou.

1. No `.env`, copie o valor atual de `SECRET_KEY` para uma linha nova `SECRET_KEY_ANTERIOR=...`.
2. Gere uma chave nova em PowerShell e cole em `SECRET_KEY`:
   ```
   $b=New-Object byte[] 32; (New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($b); -join ($b|%{'{0:x2}' -f $_})
   ```
3. Rode o `Iniciar FinancePro.bat`. Ao iniciar, o sistema re-cifra todas as credenciais com a chave nova. Todos precisam entrar de novo.
4. Confira em *Cadastros › Segurança* e depois apague a linha `SECRET_KEY_ANTERIOR` do `.env`.
