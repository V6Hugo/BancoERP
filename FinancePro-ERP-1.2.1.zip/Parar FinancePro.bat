@echo off
chcp 65001 >nul
cd /d "%~dp0"
docker compose stop
echo   FinancePro ERP parado. Os dados continuam guardados.
timeout /t 5 >nul
