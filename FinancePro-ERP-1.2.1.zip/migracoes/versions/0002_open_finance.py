"""open finance (Pluggy) e importação por planilha

Revision ID: 0002
Revises: 0001
Create Date: 2026-11-13 14:30:00
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None

JSONV = sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql')


def upgrade() -> None:
    op.add_column('empresas', sa.Column('integracoes', JSONV, nullable=False, server_default=sa.text("'{}'")))
    op.alter_column('empresas', 'integracoes', server_default=None)
    op.drop_constraint(op.f('ck_contas_bancarias_integracao'), 'contas_bancarias', type_='check')
    op.create_check_constraint(op.f('ck_contas_bancarias_integracao'), 'contas_bancarias',
                               "integracao in ('nenhuma','inter','openfinance')")


def downgrade() -> None:
    op.execute("UPDATE contas_bancarias SET integracao='nenhuma', integracao_config='{}' WHERE integracao='openfinance'")
    op.drop_constraint(op.f('ck_contas_bancarias_integracao'), 'contas_bancarias', type_='check')
    op.create_check_constraint(op.f('ck_contas_bancarias_integracao'), 'contas_bancarias', "integracao in ('nenhuma','inter')")
    op.drop_column('empresas', 'integracoes')
