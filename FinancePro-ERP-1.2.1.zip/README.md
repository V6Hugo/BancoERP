# FinancePro ERP

Gestão financeira multiempresa: recebimentos, pagamentos, fluxo de caixa, bancos (extrato e conciliação) e
relatórios com comparativos entre meses. O visual segue o Banco ERP.

## O que tem

| Área | O que faz |
|---|---|
| **Painel** | Saldo disponível, entradas e saídas do mês, a receber e a pagar (com vencidos), gráfico de 12 meses, próximos vencimentos e pendências. |
| **Recebimentos / Pagamentos** | Contas a receber e a pagar, com parcelas (divide o valor) ou repetição mensal. Baixa total, parcial, com juros e desconto, ou em lote. Estorno, cancelamento e exportação para Excel. |
| **Fluxo de caixa** | Diário, semanal ou mensal. Mostra o realizado (o que entrou e saiu) e o previsto (o que está em aberto), com o saldo projetado. |
| **Bancos e conciliação** | Extrato por arquivo (OFX, Excel .xlsx/.xls ou CSV, de qualquer banco), por Open Finance (Pluggy) ou pela API do Inter. Mostra uma prévia antes de importar, não duplica e permite desfazer uma importação. Concilia sozinho o que é inequívoco e sugere categoria por regras. Lança o movimento, liga ao lançamento certo, registra transferência entre contas ou ignora. Compara o saldo do sistema com o saldo informado pelo banco. |
| **Relatórios** | Comparativo entre meses (por linha do DRE, categoria, centro de custo ou cliente/fornecedor), com variação em R$ e %. DRE gerencial por regime de caixa ou de competência. Gráficos de composição. Clicar em barras, fatias e linhas mostra os lançamentos. Exporta para Excel. |
| **Cadastros** | Plano de contas em dois níveis (grupo e categoria), editável na própria tela. Centros de custo, clientes e fornecedores (CPF/CNPJ validado), contas bancárias, regras do extrato, usuários com papéis e dados da empresa. |

## Banco de dados

O banco é o **PostgreSQL 16**. A estrutura é versionada por migrações (Alembic) e aplicada sozinha quando o sistema inicia.

- **Várias empresas no mesmo banco.** Cada registro pertence a uma empresa, e a aplicação só mostra a cada usuário as empresas a que ele tem acesso.
- **Dinheiro em `NUMERIC(14,2)`**, nunca em ponto flutuante. Os valores são sempre positivos; o sentido vem do tipo (receber/pagar) ou da natureza (C/D).
- **Regras no próprio banco**, para que dado inválido não entre nem por fora da aplicação:
  - chaves estrangeiras;
  - `CHECK` de valor positivo, tipos, situações e parcelas;
  - `UNIQUE` em CNPJ, e-mail, código de categoria e CPF/CNPJ de contato por empresa;
  - identificador de cada transação por conta, para que reimportar um extrato não duplique.
- **O realizado separado do previsto e do extrato:**
  - *lançamentos*: o que se espera receber ou pagar;
  - *baixas*: o que foi pago ou recebido, em uma ou várias vezes;
  - *movimentos*: o que o banco informou;
  - *transferências*: dinheiro entre contas da própria empresa, que não é receita nem despesa.
- **Auditoria:** quem criou, alterou, baixou, estornou ou excluiu, e quando.
- **Segurança:**
  - senhas com bcrypt;
  - sessões no servidor (cookie HttpOnly e SameSite=Strict);
  - Client Secret dos bancos e chave do certificado do Inter cifrados (Fernet).
- **Cópia de segurança** automática todo dia (`pg_dump`). As 30 mais recentes ficam em `dados/backups`.
- **Acesso:** verificação em duas etapas, sessões no servidor com fim por inatividade, bloqueio por tentativas, senha confirmada de novo para mexer em credenciais de banco e usuários, e registro de eventos em *Cadastros › Segurança*. Detalhes e checklist em **[SEGURANCA.md](SEGURANCA.md)**.

Tabelas: `empresas`, `usuarios`, `vinculos`, `categorias`, `centros_custo`, `contatos`, `contas_bancarias`,
`lancamentos`, `baixas`, `transferencias`, `importacoes`, `movimentos`, `regras`, `auditoria`.

## Plano de contas padrão

Cada empresa nova começa com 11 grupos e 53 categorias, organizados pelas linhas do DRE:

| Grupo | Exemplos de categorias | Linha do DRE |
|---|---|---|
| 1 Receitas operacionais | Venda de produtos, Prestação de serviços | Receita bruta |
| 2 Deduções da receita | Simples Nacional/DAS, ISS, ICMS, PIS e COFINS, taxas de cartão | Deduções |
| 3 Custos diretos | Mercadorias e insumos, terceirizados, fretes, comissões | Custos |
| 4 Despesas com pessoal | Salários, pró-labore, INSS e FGTS, férias e 13º, benefícios | Despesas operacionais |
| 5 Despesas administrativas | Aluguel, energia, internet, contabilidade, sistemas | Despesas operacionais |
| 6 Despesas comerciais | Marketing, eventos | Despesas operacionais |
| 7 Receitas financeiras | Rendimentos, juros recebidos, descontos obtidos | Receitas financeiras |
| 8 Despesas financeiras | Tarifas, juros pagos, IOF, juros de empréstimos | Despesas financeiras |
| 9 Impostos sobre o lucro | IRPJ, CSLL | IRPJ e CSLL |
| 10 Investimentos | Máquinas, móveis, computadores, obras | Fora do resultado |
| 11 Movimentações não operacionais | Empréstimos, aportes, distribuição de lucros, aplicações | Fora do resultado |

Os centros de custo padrão são Administrativo, Comercial, Operacional e Financeiro. Tudo pode ser renomeado,
criado, desativado e reorganizado em **Cadastros**.

## Instalar no Windows

1. Instale o **Docker Desktop** (https://www.docker.com/products/docker-desktop/), se ainda não tiver.
2. Dê dois cliques em **`Iniciar FinancePro.bat`**.
   - Na primeira vez ele cria o arquivo `.env` com senhas aleatórias, monta o sistema (leva alguns minutos) e cria o atalho **FinancePro ERP** na Área de Trabalho.
   - O sistema abre em **http://localhost:8080**.
3. No primeiro acesso, crie o administrador e a primeira empresa.

- **Parar:** `Parar FinancePro.bat`. Os dados continuam guardados.
- **Cópia de segurança na hora:** `Backup agora.bat`. As automáticas são diárias.
- **Guarde o `.env` em lugar seguro.** Sem a `SECRET_KEY` dele não é possível ler as credenciais de banco já cadastradas.

O FinancePro usa a porta 8080, então não conflita com o Banco ERP (portas 8000 e 8001). Para trocar a porta, altere `PORTA` no `.env`.
Por padrão só o próprio computador acessa. Para liberar na rede da empresa, siga [SEGURANCA.md](SEGURANCA.md).

### Restaurar uma cópia

```
docker compose exec -T db pg_restore -U financepro -d financepro --clean --if-exists < dados\backups\ARQUIVO.dump
```

## Bancos

Em **Bancos e conciliação** há três jeitos de trazer o extrato. Os três caem no mesmo lugar: o movimento entra uma vez só, fica “a conciliar” e é ligado ao recebimento ou pagamento.

### 1. Importar extrato (arquivo)

Botão **Importar extrato**: escolha a conta e arraste o arquivo.

- **OFX** de qualquer banco (Itaú, Bradesco, Banco do Brasil, Santander, Caixa, Inter, Nubank, Sicoob, Sicredi...). O sistema confere se o arquivo é daquela conta.
- **Excel (.xlsx e .xls) e CSV.** As colunas são reconhecidas sozinhas: data, descrição/histórico, valor com sinal *ou* crédito e débito, tipo C/D, documento e saldo. Linhas de saldo anterior, saldo do dia e totais ficam de fora. Também lê o “.xls” que alguns bancos exportam como página HTML.
- Antes de gravar aparece a **prévia**: movimentos novos, entradas, saídas, período, saldo do banco e cada linha. Se alguma coluna vier trocada, corrija ali mesmo. Também é possível inverter os sinais, para arquivos em que as saídas não têm “−”.
- **Não duplica.** Reimportar o mesmo arquivo não repete nada. Um movimento que já veio por outra fonte, com a mesma data, valor e sentido (ex.: OFX e depois planilha), também não entra de novo.
- **Histórico de importações**: lista tudo o que foi importado. Uma importação pode ser desfeita enquanto nenhum movimento dela foi conciliado.
- Montando o extrato à mão? Baixe a **planilha-modelo** na tela de importação.

### 2. Conectar banco (Open Finance)

O FinancePro usa a **Pluggy**, agregador de Open Finance, para ler extrato e saldo de Itaú, Bradesco, Banco do Brasil, Santander, Caixa, Inter, Nubank, Sicoob, Sicredi, C6 e outros. O acesso é só de leitura: o sistema não faz pagamentos.

1. Crie uma conta em https://dashboard.pluggy.ai e uma *Application*. Copie o **Client ID** e o **Client Secret**.
2. No FinancePro, em **Bancos › Conectar banco**, um administrador cola as duas chaves. O sistema testa antes de salvar, e o segredo fica cifrado.
3. Clique em **Escolher o banco**. A janela da Pluggy abre; você entra no banco e autoriza o compartilhamento.
4. Escolha em qual conta do FinancePro entra cada conta do banco, ou deixe o sistema criar. O extrato dos últimos 90 dias (ou da data escolhida) já vem.
5. Depois disso, o botão **Sincronizar** da conta traz o que é novo. Para sincronizar sozinho, defina `SINCRONIZAR_BANCOS_MIN` no `.env` (ex.: `60`).

Quando o banco pedir nova autorização (senha trocada, consentimento vencido), o sistema avisa e reabre a janela do banco. Em **Conexão** é possível autorizar de novo ou desconectar; desconectar revoga o acesso na Pluggy.

> Com a conta de teste da Pluggy aparecem só os bancos de teste (marque “Mostrar bancos de teste”). Para bancos reais, a aplicação precisa estar em produção na Pluggy. As condições comerciais são combinadas com a Pluggy.

### 3. API do Inter (direta)

No Internet Banking PJ do Inter, vá em *Soluções para sua empresa › Nova integração*, marque a permissão de consultar extrato e saldo, e anote o Client ID e o Client Secret. Baixe também o certificado (.zip).

- No FinancePro, a conta precisa estar cadastrada com o banco **077**. Em Bancos e conciliação, clique em **Ligar API Inter** e informe o Client ID, o Client Secret e o .zip.
- O botão **Sincronizar** busca o extrato e o saldo.

## Publicar num servidor

Para acessar de fora, o mesmo `docker-compose.yml` roda num servidor (VPS, nuvem):

1. Copie a pasta e crie o `.env` com senhas fortes, `COOKIE_SEGURO=true`, `ENDERECO=0.0.0.0` e o domínio em `HOSTS_PERMITIDOS`.
2. Coloque um proxy com HTTPS na frente (Caddy, Nginx ou o balanceador da nuvem), apontando para a porta 8080.
3. Rode `docker compose up -d --build`.

Para levar os dados do computador para o servidor, use uma cópia de `dados/backups` e o comando de restaurar.

## Desenvolvimento

```
pip install -r requirements-dev.txt
# PostgreSQL de teste em FP_TESTE_DB (padrão: postgresql+psycopg://postgres@127.0.0.1:5433/financepro_teste)
pytest
python scripts/dados_exemplo.py http://localhost:8080 seu@email.com suasenha   # empresa de demonstração
```

Documentação da API em `/docs`. Estrutura do código:

- `app/models.py`: tabelas.
- `app/servicos/`: regras de negócio.
- `app/bancos/`: leitores de extrato (OFX e planilhas), API do Inter e Open Finance (Pluggy).
- `app/api/`: rotas.
- `app/web/`: interface.
- `migracoes/`: Alembic.
