@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "dados\backups" mkdir "dados\backups"
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmm"') do set "QUANDO=%%T"
docker compose exec -T db pg_dump -U financepro -d financepro -Fc > "dados\backups\financepro_manual_%QUANDO%.dump"
if errorlevel 1 (
  echo   Nao foi possivel fazer a copia. O FinancePro esta rodando?
) else (
  echo   Copia de seguranca salva em dados\backups\financepro_manual_%QUANDO%.dump
)
pause
