"""Cria uma empresa de demonstração com 7 meses de movimento (para conhecer o sistema ou testar).

Uso: python scripts/dados_exemplo.py http://127.0.0.1:8000 email senha
"""
from __future__ import annotations

import random
import sys
from datetime import date, timedelta

import httpx

URL, EMAIL, SENHA = (sys.argv[1:4] + [None] * 3)[:3]
URL = URL or "http://127.0.0.1:8000"
random.seed(7)


def main() -> None:
    c = httpx.Client(base_url=URL, timeout=60, headers={"X-FP": "1"})
    est = c.get("/api/estado").json()
    if not est["configurado"]:
        eu = c.post("/api/setup", json={"nome": "Administrador", "email": EMAIL or "admin@exemplo.com", "senha": SENHA or "Demonstracao-2026",
                                        "empresa": "Empresa Demonstração", "cnpj": "11.222.333/0001-81"}).json()
    else:
        eu = c.post("/api/login", json={"email": EMAIL, "senha": SENHA}).json()
        e = c.post("/api/empresas", json={"nome": "Empresa Demonstração"}).json()
        eu = c.get("/api/eu").json()
        eu["empresas"] = [x for x in eu["empresas"] if x["id"] == e["id"]]
    E = f"/api/e/{eu['empresas'][0]['id']}"
    cats = {x["codigo"]: x["id"] for g in c.get(f"{E}/categorias").json() for x in g["categorias"]}
    ccs = {x["nome"]: x["id"] for x in c.get(f"{E}/centros-custo").json()}
    hoje = date.today()
    ini = date(hoje.year, hoje.month, 1)
    for _ in range(6):
        ini = (ini - timedelta(days=1)).replace(day=1)
    banco = c.post(f"{E}/contas", json={"nome": "Inter PJ", "banco_codigo": "077", "agencia": "0001", "numero": "1234567-8",
                                        "saldo_inicial": "35000", "data_saldo_inicial": (ini - timedelta(days=1)).isoformat()}).json()
    itau = c.post(f"{E}/contas", json={"nome": "Itaú PJ", "banco_codigo": "341", "numero": "56789-0",
                                       "saldo_inicial": "12000", "data_saldo_inicial": (ini - timedelta(days=1)).isoformat()}).json()
    c.post(f"{E}/contas", json={"nome": "Caixa da loja", "tipo": "caixa", "saldo_inicial": "800"})
    contato = {}
    for nome, tipo, doc, cat in [("Alfa Comércio Ltda", "cliente", "11.444.777/0001-61", "1.02"), ("Beta Serviços", "cliente", None, "1.02"),
                                 ("Gama Indústria", "cliente", None, "1.01"), ("Imobiliária Centro", "fornecedor", None, "5.01"),
                                 ("Cemig", "fornecedor", None, "5.02"), ("Vivo Empresas", "fornecedor", None, "5.03"),
                                 ("Contabilidade Silva", "fornecedor", None, "5.04"), ("Distribuidora Norte", "fornecedor", None, "3.01"),
                                 ("Google Ads", "fornecedor", None, "6.01")]:
        contato[nome] = c.post(f"{E}/contatos", json={"nome": nome, "tipo": tipo, "documento": doc, "categoria_padrao_id": cats[cat]}).json()["id"]

    def lanc(tipo, desc, valor, venc, cat, cc=None, ct=None, pago=True, conta=None, **kw):
        r = c.post(f"{E}/lancamentos", json={"tipo": tipo, "descricao": desc, "valor": f"{valor:.2f}", "vencimento": venc.isoformat(),
                                              "categoria_id": cats[cat], "centro_custo_id": ccs.get(cc), "contato_id": contato.get(ct),
                                              "conta_bancaria_id": (conta or banco)["id"], **kw})
        assert r.status_code == 201, r.text
        l = r.json()[0]
        if pago and venc <= hoje:
            atraso = random.choice([0, 0, 0, 1, 2, 5])
            c.post(f"{E}/lancamentos/{l['id']}/baixar", json={"data": min(hoje, venc + timedelta(days=atraso)).isoformat(),
                                                              "valor": f"{valor:.2f}", "conta_bancaria_id": (conta or banco)["id"]})
        return l

    d = ini
    while d <= hoje.replace(day=1) + timedelta(days=62):
        m = d.month
        fator = 1 + 0.06 * ((m % 6) - 2)
        for cli, base, cat in [("Alfa Comércio Ltda", 31000, "1.02"), ("Beta Serviços", 16500, "1.02"), ("Gama Indústria", 24000, "1.01")]:
            lanc("receber", f"Faturamento {cli.split()[0]} {d:%m/%Y}", base * fator * random.uniform(.9, 1.1), d.replace(day=10), cat,
                 "Comercial", cli, pago=random.random() > .08)
        lanc("pagar", f"Aluguel {d:%m/%Y}", 6500, d.replace(day=5), "5.01", "Administrativo", "Imobiliária Centro")
        lanc("pagar", f"Energia {d:%m/%Y}", random.uniform(780, 1150), d.replace(day=12), "5.02", "Operacional", "Cemig")
        lanc("pagar", f"Telefonia {d:%m/%Y}", 389.9, d.replace(day=15), "5.03", "Administrativo", "Vivo Empresas")
        lanc("pagar", f"Honorários contábeis {d:%m/%Y}", 1800, d.replace(day=10), "5.04", "Administrativo", "Contabilidade Silva")
        lanc("pagar", f"Salários {d:%m/%Y}", 15500, d.replace(day=5), "4.01", "Operacional")
        lanc("pagar", f"INSS e FGTS {d:%m/%Y}", 4300, d.replace(day=20), "4.03", "Operacional")
        lanc("pagar", f"Pró-labore {d:%m/%Y}", 7000, d.replace(day=5), "4.02", "Administrativo")
        lanc("pagar", f"Simples Nacional {d:%m/%Y}", 71500 * fator * .06, d.replace(day=20), "2.01", "Financeiro")
        lanc("pagar", f"Compra de insumos {d:%m/%Y}", random.uniform(5000, 9000), d.replace(day=18), "3.01", "Operacional", "Distribuidora Norte")
        lanc("pagar", f"Campanha Google {d:%m/%Y}", random.uniform(1200, 3200), d.replace(day=25), "6.01", "Comercial", "Google Ads", conta=itau)
        lanc("pagar", f"Tarifas bancárias {d:%m/%Y}", 89.9, d.replace(day=2), "8.01", "Financeiro")
        d = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
    lanc("pagar", "Notebooks equipe", 12600, hoje.replace(day=1) - timedelta(days=40), "10.03", "Administrativo", parcelas=3, pago=False)
    c.post(f"{E}/regras", json={"texto": "TARIFA", "natureza": "D", "categoria_id": cats["8.01"], "centro_custo_id": ccs["Financeiro"]})
    print("Empresa de demonstração criada:", E)


if __name__ == "__main__":
    main()
