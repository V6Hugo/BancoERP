"use strict";
/* Último arquivo: todas as telas já estão registradas. */
iniciar();
