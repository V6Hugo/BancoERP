/* Bancos: contas, importação de extrato (OFX, Excel, CSV), Open Finance (Pluggy), API do Inter,
   conciliação, transferências e histórico de importações. */
"use strict";

const ESTADO_B = {conta: null, situacao: "pendente", busca: ""};
const ORIGEM_MOV = {ofx: "OFX", planilha: "Planilha", api_inter: "API Inter", openfinance: "Open Finance"};
const TIPO_CONTA = {corrente: "Conta corrente", poupanca: "Poupança", investimento: "Investimento", caixa: "Caixa", cartao: "Cartão de crédito"};

TELAS.bancos = async main => {
  const s = await api(E("/saldos"));
  const contas = s.contas.filter(c => c.ativo);
  const comExtrato = contas.filter(c => c.tipo !== "caixa");
  if (ESTADO_B.conta && !contas.some(c => c.conta_id === ESTADO_B.conta)) ESTADO_B.conta = null;
  const pendTotal = contas.reduce((t, c) => t + c.pendentes_conciliar, 0);
  main.innerHTML = `
    <div class="topo-tela"><div><h1>Bancos e conciliação</h1>
      <p class="sub">Traga o extrato do banco e confira cada movimento com os recebimentos e pagamentos.</p></div>
      ${pode() ? `<div class="linha-acoes">
        <button class="btn" id="historico">Histórico de importações</button>
        <button class="btn" id="transf">Transferir entre contas</button>
        <button class="btn" id="conectar">Conectar banco</button>
        <button class="btn primario" id="importar">Importar extrato</button></div>` : ""}</div>
    ${comExtrato.length ? "" : `<div class="entradas-extrato">
      <button type="button" class="entrada-card" data-acao="importar"><b>Importar extrato</b>
        <span>Arquivo OFX, planilha do Excel (.xlsx ou .xls) ou CSV, de qualquer banco.</span></button>
      <button type="button" class="entrada-card" data-acao="conectar"><b>Conectar banco (Open Finance)</b>
        <span>Itaú, Bradesco, Banco do Brasil, Santander, Caixa, Inter, Nubank e outros. O extrato chega sozinho.</span></button>
      <button type="button" class="entrada-card" data-acao="conta"><b>Cadastrar uma conta</b>
        <span>Nome, banco, número e saldo inicial. Depois é só trazer o extrato.</span></button></div>`}
    <div class="contas-grade">${contas.map(cartaoConta).join("")}</div>
    <div class="topo-tela" style="margin-bottom:12px"><div><h2 style="margin:0">Movimentos do extrato${ESTADO_B.conta ? " · " + esc(contas.find(c => c.conta_id === ESTADO_B.conta)?.nome) : ""}</h2>
        ${pendTotal ? `<p class="sub" style="margin:2px 0 0">${pendTotal} movimento(s) esperando conciliação.</p>` : ""}</div>
      <div class="linha-acoes">${ESTADO_B.conta ? `<button class="btn" id="todas">Todas as contas</button>` : ""}
        ${pode() ? `<button class="btn" id="auto" title="Liga ao recebimento ou pagamento quando só existe um com o mesmo valor e data próxima">Conciliar automaticamente</button>
          <button class="btn primario" id="sugeridos" title="Lança os movimentos que têm uma regra do extrato">Lançar os que têm regra</button>` : ""}</div></div>
    <div class="barra-filtros"><div id="m-sit"></div>
      <label class="campo busca">Buscar no extrato<input type="search" id="m-busca" value="${esc(ESTADO_B.busca)}" placeholder="Texto da descrição"></label></div>
    <div class="tabela-wrap" id="movs"><div class="carregando">Carregando…</div></div>`;

  $$("[data-conta]").forEach(el => el.onclick = e => {
    if (e.target.closest("button,a")) return;
    ESTADO_B.conta = +el.dataset.conta === ESTADO_B.conta ? null : +el.dataset.conta; ir("bancos");
  });
  $("#todas") && ($("#todas").onclick = () => { ESTADO_B.conta = null; ir("bancos"); });
  $("#m-sit").append(seg([["pendente", "A conciliar"], ["conciliado", "Conciliados"], ["ignorado", "Ignorados"]], ESTADO_B.situacao,
                         v => { ESTADO_B.situacao = v; carregarMovs(); }));
  let espera;
  $("#m-busca").oninput = e => { clearTimeout(espera); espera = setTimeout(() => { ESTADO_B.busca = e.target.value; carregarMovs(); }, 300); };

  const acoes = {importar: () => assistenteImportacao(ESTADO_B.conta), conectar: () => abrirOpenFinance(),
                 conta: () => location.hash = "#cadastros/contas"};
  $$("[data-acao]").forEach(b => b.onclick = () => pode() ? acoes[b.dataset.acao]() : toast("Seu acesso é só de leitura.", true));
  $("#importar") && ($("#importar").onclick = acoes.importar);
  $("#conectar") && ($("#conectar").onclick = acoes.conectar);
  $("#historico") && ($("#historico").onclick = () => historicoImportacoes());
  $$("[data-imp]").forEach(b => b.onclick = () => assistenteImportacao(+b.dataset.imp));
  $$("[data-sync]").forEach(b => b.onclick = () => sincronizarConta(+b.dataset.sync, b));
  $$("[data-inter]").forEach(b => b.onclick = () => configurarInter(+b.dataset.inter));
  $$("[data-of]").forEach(b => b.onclick = () => conexaoOpenFinance(+b.dataset.of));
  $("#transf") && ($("#transf").onclick = () => novaTransferencia());
  $("#auto") && ($("#auto").onclick = tentar(async () => {
    const r = await api(E("/movimentos/conciliar-auto"), {metodo: "POST"});
    const n = r.conciliados_auto + r.baixas_ligadas;
    toast(n ? `${n} movimento(s) conciliado(s).` : "Nenhum movimento com um único recebimento/pagamento correspondente."); ir("bancos"); }));
  $("#sugeridos") && ($("#sugeridos").onclick = tentar(async () => {
    const r = await api(E("/movimentos/lancar-sugeridos"), {metodo: "POST", corpo: {}});
    toast(`${r.lancados} lançado(s) pelas regras; ${r.sem_regra} continuam a conciliar.`); ir("bancos"); }));
  await contatos();
  await carregarMovs();
};

function cartaoConta(c) {
  const of = c.integracao === "openfinance", inter = c.integracao === "inter";
  // mensagens do cartão: pendências primeiro; sem pendências, compara o saldo do banco com o do sistema no mesmo dia
  let aviso = "";
  if (c.pendentes_conciliar) aviso = "";
  else if (c.saldo_banco !== null && c.saldo_banco !== undefined && c.saldo_sistema_na_data !== null) {
    const d = num(c.saldo_banco) - num(c.saldo_sistema_na_data);
    aviso = Math.abs(d) < 0.01 ? `<div class="dif c">Sistema e banco batem em ${dataBR(c.data_saldo_banco)}</div>`
      : `<div class="dif atrasado">Em ${dataBR(c.data_saldo_banco)} o banco mostra ${brl(Math.abs(d))} a ${d > 0 ? "mais" : "menos"} que o sistema. Confira o saldo inicial da conta ou lançamentos sem extrato.</div>`;
  } else if (c.saldo_extrato !== null && c.diferenca !== null && Math.abs(num(c.diferenca)) < 0.01) aviso = `<div class="dif c">Sistema e extrato batem</div>`;
  return `<div class="conta-card ${ESTADO_B.conta === c.conta_id ? "sel" : ""}" data-conta="${c.conta_id}" title="Clique para ver só os movimentos desta conta">
    <h3><span style="display:flex;gap:10px;align-items:center;min-width:0"><span class="banco-ico">${esc(c.banco_codigo || (c.tipo === "caixa" ? "R$" : "•"))}</span>
      <span style="min-width:0"><span class="nome-conta">${esc(c.nome)}</span>
      <span class="sublinha">${esc([TIPO_CONTA[c.tipo], c.agencia && "ag. " + c.agencia, c.numero].filter(Boolean).join(" · "))}</span></span></span>
      ${inter ? selo("conciliado", "API Inter") : of ? selo("conciliado", "Open Finance") : ""}</h3>
    <div class="saldo ${num(c.saldo) < 0 ? "d" : ""}">${brl(c.saldo)}</div>
    <div class="meta">Saldo pelo sistema${c.saldo_banco !== null && c.saldo_banco !== undefined ? ` · no banco ${brl(c.saldo_banco)} em ${dataBR(c.data_saldo_banco)}` : ""}</div>
    ${aviso}
    <div class="meta">${c.pendentes_conciliar ? `<b class="atrasado">${c.pendentes_conciliar} a conciliar</b>` : c.tipo === "caixa" ? "Dinheiro em espécie" : "Nada a conciliar"}${c.ultima_sincronizacao ? ` · sincronizado ${new Date(c.ultima_sincronizacao).toLocaleString("pt-BR", {dateStyle: "short", timeStyle: "short"})}` : ""}</div>
    ${pode() && c.tipo !== "caixa" ? `<div class="linha-acoes">
      ${inter || of ? `<button class="btn primario" data-sync="${c.conta_id}">Sincronizar</button>` : ""}
      <button class="btn" data-imp="${c.conta_id}">Importar extrato</button>
      ${of ? `<button class="btn" data-of="${c.conta_id}">Conexão</button>` : ""}
      ${c.banco_codigo === "077" && !of && pode("admin") ? `<button class="btn" data-inter="${c.conta_id}">${inter ? "API Inter" : "Ligar API Inter"}</button>` : ""}</div>` : ""}
  </div>`;
}

async function carregarMovs() {
  const r = await api(E("/movimentos?" + qs({conta_id: ESTADO_B.conta, situacao: ESTADO_B.situacao, busca: ESTADO_B.busca, por_pagina: 300})));
  const caixa = $("#movs");
  if (!caixa) return;
  if (!r.itens.length) {
    caixa.innerHTML = `<div class="vazio">${ESTADO_B.busca ? "Nada encontrado com esse texto." : ESTADO_B.situacao === "pendente" ?
      "Nada a conciliar. Importe um extrato ou sincronize um banco conectado." : "Nenhum movimento aqui."}</div>`;
    return;
  }
  const outrasContas = id => CAD.contas.filter(c => c.ativo && c.id !== id);
  caixa.innerHTML = r.itens.map(m => {
    const ent = m.natureza === "C", tipo = ent ? "receber" : "pagar";
    let acoes = "";
    if (m.situacao === "pendente" && pode()) {
      const sug = m.sugestao || {}, ct = sug.contato_id ? (CAD.contatos || []).find(c => c.id === sug.contato_id) : null;
      acoes = `${m.candidatos.map(c => `<div class="cand"><span>${esc(c.contato || c.descricao)}<span class="sublinha">vence ${dataBR(c.vencimento)} · ${brl(c.valor)}</span></span>
          <button class="btn primario" data-conc="${m.id}" data-l="${c.id}">É este</button></div>`).join("")}
        <form class="acoes" data-lancar="${m.id}">
          <select name="categoria_id" aria-label="Categoria">${optCategorias(tipo, sug.categoria_id, {vazio: "Categoria…"})}</select>
          <div class="linha"><select name="centro_custo_id" style="flex:1" aria-label="Centro de custo">${optCentros(sug.centro_custo_id, "Centro de custo…")}</select></div>
          <input type="text" name="contato" list="lista-contatos-b" placeholder="${ent ? "Cliente" : "Fornecedor"} (opcional)" value="${esc(ct?.nome || m.favorecido || "")}" style="padding:6px 8px;font-size:13px">
          <label class="opcao" style="font-size:12px"><input type="checkbox" name="regra"> Criar regra com o texto <input type="text" name="texto_regra" value="${esc(textoRegra(m.descricao))}" style="padding:3px 6px;font-size:12px;flex:1;min-width:0"></label>
          <div class="linha"><button class="btn primario" type="submit">Lançar</button>
            <select data-transf="${m.id}" style="width:auto;flex:1" aria-label="Transferência"><option value="">Transferência…</option>${outrasContas(m.conta_bancaria_id).map(c => `<option value="${c.id}">${ent ? "veio de" : "foi para"} ${esc(c.nome)}</option>`).join("")}</select>
            <button class="btn" type="button" data-ign="${m.id}" title="Não lançar (ex.: estorno que se anula)">Ignorar</button></div>
          ${sug.origem ? `<span class="dica-campo">Sugestão ${sug.origem === "regra" ? `da regra “${esc(sug.regra_texto)}”` : "pelo cadastro do " + (ent ? "cliente" : "fornecedor")}</span>` : ""}
        </form>`;
    } else if (m.situacao !== "pendente") {
      acoes = `<div>${m.lancamento ? `<a href="#${tipo}/${m.lancamento.id}">${esc(m.lancamento.descricao)}</a><span class="sublinha">${esc(m.lancamento.categoria || "")}</span>` :
        m.transferencia_id ? "Transferência entre contas" : "Ignorado"}</div>
        ${pode() ? `<div class="linha" style="margin-top:6px"><button class="btn" data-desf="${m.id}">Desfazer</button></div>` : ""}`;
    }
    return `<div class="mov"><div>${dataBR(m.data)}<span class="sublinha">${esc(m.conta)}</span></div>
      <div class="desc">${esc(m.descricao)}<small>${ORIGEM_MOV[m.origem] || esc(m.origem)}${m.documento ? " · doc " + esc(m.documento) : ""}${m.cpf_cnpj ? " · " + (m.cpf_cnpj.length === 14 ? "CNPJ " : "CPF ") + esc(m.cpf_cnpj) : ""}</small></div>
      <div class="num ${ent ? "c" : "d"}" style="font-weight:600">${ent ? "" : "−"}${brl(m.valor)}</div><div class="acoes">${acoes}</div></div>`;
  }).join("") + `<datalist id="lista-contatos-b">${(CAD.contatos || []).map(c => `<option value="${esc(c.nome)}">`).join("")}</datalist>
    ${r.total > r.itens.length ? `<div class="vazio">Mostrando ${r.itens.length} de ${r.total}. Use a busca ou escolha uma conta.</div>` : ""}`;

  const saiu = el => { const mov = el.closest(".mov"); mov.classList.add("saindo"); setTimeout(() => mov.remove(), 180); };
  $$("[data-conc]", caixa).forEach(b => b.onclick = tentar(async () => {
    await api(E(`/movimentos/${b.dataset.conc}/conciliar`), {metodo: "POST", corpo: {lancamento_id: +b.dataset.l}});
    toast("Conciliado."); saiu(b); }));
  $$("form[data-lancar]", caixa).forEach(f => f.onsubmit = tentar(async ev => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(f)), mid = +f.dataset.lancar;
    if (!d.categoria_id) throw new Error("Escolha a categoria.");
    const m = r.itens.find(x => x.id === mid);
    await api(E(`/movimentos/${mid}/lancar`), {metodo: "POST", corpo: {categoria_id: +d.categoria_id, centro_custo_id: +d.centro_custo_id || null,
      contato_id: await resolverContato(d.contato, m.natureza === "C" ? "cliente" : "fornecedor",
                                        d.contato && d.contato.trim() === (m.favorecido || "").trim() ? m.cpf_cnpj : null),
      criar_regra: d.regra ? d.texto_regra : null, regra_id: m.sugestao?.regra_id || null}});
    toast(d.regra ? "Lançado. Regra criada para os próximos." : "Lançado."); saiu(f);
  }));
  $$("[data-transf]", caixa).forEach(sel => sel.onchange = tentar(async () => {
    if (!sel.value) return;
    await api(E(`/movimentos/${sel.dataset.transf}/transferencia`), {metodo: "POST", corpo: {outra_conta_id: +sel.value}});
    toast("Registrado como transferência entre contas."); saiu(sel); }));
  $$("[data-ign]", caixa).forEach(b => b.onclick = tentar(async () => {
    await api(E(`/movimentos/${b.dataset.ign}/ignorar`), {metodo: "POST"}); toast("Movimento ignorado."); saiu(b); }));
  $$("[data-desf]", caixa).forEach(b => b.onclick = tentar(async () => {
    if (!await confirmar("Desfazer a conciliação? A baixa ligada a este movimento é estornada e o movimento volta para “a conciliar”.", "Desfazer")) return;
    await api(E(`/movimentos/${b.dataset.desf}/desfazer`), {metodo: "POST"}); toast("Conciliação desfeita."); carregarMovs(); }));
}

function textoRegra(desc) {
  // sugere o trecho mais característico: o nome depois do último "-" ou dos dois pontos
  const s = (desc || "").replace(/["“”]/g, " ").trim();
  const p = s.split(/\s-\s|:\s/).pop().trim();
  return (p.length >= 4 ? p : s).slice(0, 40);
}

// ================================================================== importar extrato (OFX, Excel, CSV)

function assistenteImportacao(contaId) {
  const contas = (CAD.contas || []).filter(c => c.ativo && c.tipo !== "caixa");
  const st = {conta: contaId && contas.some(c => c.id === contaId) ? contaId : (contas.length === 1 ? contas[0].id : null),
              arquivo: null, mapa: null, inverter: false, forcar: false, pular: true, previa: null};

  function passo1() {
    modal("Importar extrato", `
      <div class="grade-form">
        <label class="campo largo">Conta do extrato<select name="conta" id="imp-conta" required>
          <option value="">— escolha a conta —</option>${contas.map(c => `<option value="${c.id}" ${c.id === st.conta ? "selected" : ""}>${esc(c.nome)}${c.numero ? " · " + esc(c.numero) : ""}</option>`).join("")}
          ${pode("admin") ? `<option value="nova">+ Cadastrar uma conta nova…</option>` : ""}</select></label>
        <div class="largo" id="imp-nova" hidden><div class="grade-form" style="padding:12px;border:1px solid var(--linha);border-radius:var(--raio-m)">
          <label class="campo">Nome da conta<input type="text" id="nc-nome" placeholder="Ex.: Itaú PJ"></label>
          <label class="campo">Banco<select id="nc-banco"><option value="">Carregando…</option></select></label>
          <label class="campo">Agência<input type="text" id="nc-ag"></label>
          <label class="campo">Número da conta<input type="text" id="nc-num"></label></div></div>
      </div>
      <label class="soltar" id="imp-soltar" style="margin-top:14px">
        <input type="file" id="imp-arq" accept=".ofx,.xlsx,.xls,.csv,.txt" hidden>
        <strong>Arraste o arquivo do extrato aqui</strong><br>ou clique para escolher
        <div class="dica-campo" style="margin-top:8px">OFX de qualquer banco, Excel (.xlsx ou .xls) ou CSV</div>
      </label>
      <div class="ajuda-extrato">
        <details><summary>Onde baixar o extrato no banco</summary>
          <ul>
            <li><b>Itaú:</b> Extrato › Salvar em › OFX (ou Excel).</li>
            <li><b>Bradesco:</b> Saldos e extratos › Extrato › Exportar › OFX.</li>
            <li><b>Banco do Brasil:</b> Conta corrente › Extrato › Salvar/Exportar › OFX ou Excel.</li>
            <li><b>Santander:</b> Conta corrente › Extrato › Exportar › OFX ou Excel.</li>
            <li><b>Caixa:</b> Extrato › Exportar › OFX.</li>
            <li><b>Inter:</b> Extrato › Exportar › OFX, CSV ou Excel.</li>
          </ul>
          <p class="dica-campo">Prefira OFX quando o banco oferecer: ele traz o identificador de cada movimento e o saldo.
            Montou o extrato à mão? <a href="${E("/modelo-extrato.xlsx")}" download>Baixe a planilha-modelo</a>.</p></details>
      </div>`, null, {largo: true});
    const selConta = $("#imp-conta"), nova = $("#imp-nova");
    let bancos = null;
    selConta.onchange = async () => {
      st.conta = selConta.value === "nova" ? null : +selConta.value || null;
      nova.hidden = selConta.value !== "nova";
      if (!nova.hidden && !bancos) {
        bancos = await api(E("/bancos"));
        $("#nc-banco").innerHTML = `<option value="">— escolha —</option>` + bancos.map(b => `<option value="${b.codigo}">${b.codigo} · ${esc(b.nome)}</option>`).join("");
        $("#nc-nome").focus();
      }
    };
    const zona = $("#imp-soltar"), inp = $("#imp-arq");
    ["dragenter", "dragover"].forEach(ev => zona.addEventListener(ev, e => { e.preventDefault(); zona.classList.add("sobre"); }));
    ["dragleave", "drop"].forEach(ev => zona.addEventListener(ev, e => { e.preventDefault(); zona.classList.remove("sobre"); }));
    zona.addEventListener("drop", e => e.dataTransfer.files[0] && escolher(e.dataTransfer.files[0]));
    inp.onchange = () => inp.files[0] && escolher(inp.files[0]);

    async function escolher(arq) {
      try {
        if (selConta.value === "nova") {
          const nome = $("#nc-nome").value.trim();
          if (!nome) { $("#nc-nome").focus(); throw new Error("Dê um nome para a conta nova."); }
          const c = await api(E("/contas"), {metodo: "POST", corpo: {nome, banco_codigo: $("#nc-banco").value || null, tipo: "corrente",
            agencia: $("#nc-ag").value.trim() || null, numero: $("#nc-num").value.trim() || null, saldo_inicial: "0"}});
          CAD.contas = await api(E("/contas"));
          st.conta = c.id;
          toast(`Conta ${c.nome} cadastrada. Ajuste o saldo inicial em Cadastros › Contas bancárias.`);
        }
        if (!st.conta) { selConta.focus(); throw new Error("Escolha a conta do extrato."); }
        st.arquivo = arq; st.mapa = null; st.inverter = false; st.forcar = false; st.pular = true;
        zona.innerHTML = `<strong>Lendo ${esc(arq.name)}…</strong>`;
        await carregarPrevia();
      } catch (e) {
        passo1();
        $("#modal-erro").textContent = e.message;
      }
    }
  }

  async function carregarPrevia() {
    const fd = new FormData();
    fd.append("arquivo", st.arquivo);
    if (st.mapa) fd.append("mapa", JSON.stringify(st.mapa));
    fd.append("inverter", st.inverter);
    st.previa = await api(E(`/contas/${st.conta}/extrato/previa`), {metodo: "POST", form: fd});
    passo2();
  }

  function passo2() {
    const p = st.previa, r = p.resumo, conta = (CAD.contas || []).find(c => c.id === st.conta);
    const planilha = p.tipo === "planilha";
    const colOpt = sel => `<option value="">— não usar —</option>` + p.colunas.map((c, j) =>
      `<option value="${j}" ${sel === j ? "selected" : ""}>${esc(c)}${p.amostra[0]?.[j] ? " · ex.: " + esc(p.amostra[0][j].slice(0, 24)) : ""}</option>`).join("");
    const linhas = p.linhas.slice(0, 150);
    modal(`Conferir antes de importar · ${conta?.nome || ""}`, `
      <div class="imp-cabeca"><div><b>${esc(p.arquivo)}</b><span class="sublinha">${p.tipo === "ofx" ? "Arquivo OFX" : "Planilha " + esc(p.formato.toUpperCase())}${p.conta_no_arquivo ? " · conta " + esc(p.conta_no_arquivo) : ""}</span></div>
        <button type="button" class="btn" id="imp-trocar">Trocar arquivo</button></div>
      <div class="cartoes imp-resumo">
        <div class="cartao ${r.novos ? "ok" : ""}"><span class="rot">Movimentos novos</span><span class="num-g">${r.novos}</span>
          <small>${r.ja_importados ? `${r.ja_importados} já importados antes` : r.movimentos + " no arquivo"}${r.parecidos ? ` · ${r.parecidos} parecidos` : ""}</small></div>
        <div class="cartao"><span class="rot">Entradas</span><span class="num-g c">${brl(r.total_entradas)}</span><small>${r.entradas} movimento(s)</small></div>
        <div class="cartao"><span class="rot">Saídas</span><span class="num-g d">${brl(r.total_saidas)}</span><small>${r.saidas} movimento(s)</small></div>
        <div class="cartao"><span class="rot">Período</span><span class="num-g" style="font-size:18px">${r.inicio ? `${dataBR(r.inicio)} a ${dataBR(r.fim)}` : "—"}</span>
          <small>${p.saldo_banco !== null ? `Saldo no banco: ${brl(p.saldo_banco)}` : "Sem saldo no arquivo"}</small></div>
      </div>
      ${p.alerta_conta ? `<div class="alerta-imp">${esc(p.alerta_conta)}<label class="opcao" style="margin-top:6px"><input type="checkbox" id="imp-forcar" ${st.forcar ? "checked" : ""}> Importar nesta conta mesmo assim</label></div>` : ""}
      ${p.avisos.map(a => `<div class="alerta-imp leve">${esc(a)}</div>`).join("")}
      ${r.parecidos ? `<label class="opcao" style="margin:4px 0 10px"><input type="checkbox" id="imp-pular" ${st.pular ? "checked" : ""}> Não importar os ${r.parecidos} movimento(s) parecidos com os que vieram de outra fonte</label>` : ""}
      ${planilha ? `<details class="mapa-colunas" ${p.avisos.length || !r.movimentos ? "open" : ""}><summary>Colunas da planilha <span class="dica-campo">(reconhecidas sozinhas; corrija se algo estiver trocado)</span></summary>
        <div class="grade-form" style="margin-top:10px">
          ${Object.entries(p.campos).map(([k, rot]) => `<label class="campo">${esc(rot)}<select data-campo="${k}">${colOpt(p.mapa[k])}</select></label>`).join("")}
          <label class="campo">Linha do cabeçalho<select id="imp-cab"><option value="-1">Sem cabeçalho</option>${p.cabecalho_opcoes.map(o =>
            `<option value="${o.indice}" ${o.indice === p.linha_cabecalho ? "selected" : ""}>Linha ${o.indice + 1}: ${esc(o.texto.slice(0, 60))}</option>`).join("")}</select></label>
          <label class="opcao" style="align-self:end"><input type="checkbox" id="imp-inv" ${st.inverter ? "checked" : ""}> Inverter sinais (saídas vêm sem o “−”)</label>
        </div></details>` : ""}
      <div class="tabela-wrap imp-tabela"><table><thead><tr><th>Linha</th><th>Data</th><th>Descrição</th><th class="num">Valor</th><th></th></tr></thead><tbody>
        ${linhas.map(l => `<tr class="${l.motivo ? "pulada" : ""}"><td class="lin">${l.linha}</td><td>${dataBR(l.data) || "—"}</td><td>${esc(l.descricao || "—")}</td>
          <td class="num ${l.natureza === "C" ? "c" : l.natureza === "D" ? "d" : ""}">${l.valor !== null ? (l.natureza === "D" ? "−" : "") + brl(l.valor) : "—"}</td>
          <td>${l.motivo ? `<span class="selo ignorado">fora: ${esc(l.motivo)}</span>` : ""}</td></tr>`).join("")}
      </tbody></table>${p.linhas.length > linhas.length ? `<div class="vazio">Mostrando ${linhas.length} de ${p.linhas.length} linhas.</div>` : ""}</div>`,
      async () => {
        if (p.alerta_conta && !st.forcar) throw new Error("O arquivo parece ser de outra conta. Troque a conta ou marque “importar mesmo assim”.");
        if (!r.novos && !(r.parecidos && !st.pular)) throw new Error("Não há movimentos novos neste arquivo.");
        const fd = new FormData();
        fd.append("arquivo", st.arquivo); fd.append("forcar", st.forcar); fd.append("inverter", st.inverter);
        fd.append("pular_parecidos", st.pular);
        if (st.mapa) fd.append("mapa", JSON.stringify(st.mapa));
        const res = await api(E(`/contas/${st.conta}/importar`), {metodo: "POST", form: fd});
        ESTADO_B.conta = st.conta; ESTADO_B.situacao = "pendente";
        setTimeout(() => resultadoImportacao(res, conta), 0);
      }, {rotulo: r.novos ? `Importar ${r.novos} movimento${r.novos > 1 ? "s" : ""}` : "Importar", largo: true});

    $("#imp-trocar").onclick = () => passo1();
    $("#imp-forcar") && ($("#imp-forcar").onchange = e => st.forcar = e.target.checked);
    $("#imp-pular") && ($("#imp-pular").onchange = e => st.pular = e.target.checked);
    if (planilha) {
      const refazer = tentar(async () => {
        const mapa = {};
        $$("[data-campo]").forEach(s => { if (s.value !== "") mapa[s.dataset.campo] = +s.value; });
        mapa.cabecalho = +$("#imp-cab").value;
        st.mapa = mapa; st.inverter = $("#imp-inv").checked;
        try { await carregarPrevia(); }
        catch (e) { $("#modal-erro").textContent = e.message; }
      });
      $$("[data-campo]").forEach(s => s.onchange = refazer);
      $("#imp-cab").onchange = () => {
        // trocou a linha do cabeçalho: as colunas são reconhecidas de novo
        st.mapa = {cabecalho: +$("#imp-cab").value}; st.inverter = $("#imp-inv").checked;
        carregarPrevia().catch(e => $("#modal-erro").textContent = e.message);
      };
      $("#imp-inv").onchange = refazer;
    }
  }

  if (!contas.length && !pode("admin")) return toast("Nenhuma conta bancária cadastrada. Peça a um administrador para cadastrar.", true);
  passo1();
}

function resultadoImportacao(r, conta) {
  const conc = r.conciliados_auto + r.baixas_ligadas;
  modal("Extrato importado", `<dl class="ficha">
      <dt>Conta</dt><dd>${esc(conta?.nome || "")}</dd>
      <dt>Período</dt><dd>${r.periodo[0] ? `${dataBR(r.periodo[0])} a ${dataBR(r.periodo[1])}` : "—"}</dd>
      <dt>Movimentos novos</dt><dd><b>${r.novos}</b></dd>
      ${r.duplicados ? `<dt>Já importados antes</dt><dd>${r.duplicados}</dd>` : ""}
      ${r.parecidos ? `<dt>Parecidos (não importados)</dt><dd>${r.parecidos}</dd>` : ""}
      <dt>Conciliados sozinhos</dt><dd>${conc}</dd>
      ${r.saldo_banco !== null ? `<dt>Saldo informado pelo banco</dt><dd>${brl(r.saldo_banco)} em ${dataBR(r.data_saldo_banco)}</dd>` : ""}</dl>
    <p class="dica-campo">${r.novos - conc > 0 ? `Os outros ${r.novos - conc} ficam em “A conciliar”: escolha a categoria e clique em Lançar, ou ligue ao recebimento ou pagamento certo.` : "Tudo conciliado."}
      Importou o arquivo errado? Desfaça em <b>Histórico de importações</b>.</p>`, () => ir("bancos"), {rotulo: "Ver movimentos"});
  ir("bancos");
}

async function historicoImportacoes() {
  const lista = await api(E("/importacoes"));
  const corpo = modal("Histórico de importações", lista.length ? `<div class="tabela-wrap"><table><thead><tr>
      <th>Quando</th><th>Conta</th><th>Origem</th><th>Período</th><th class="num">Novos</th><th class="num">Conciliados</th><th></th></tr></thead><tbody>
      ${lista.map(i => `<tr><td>${new Date(i.criado_em).toLocaleString("pt-BR", {dateStyle: "short", timeStyle: "short"})}</td>
        <td>${esc(i.conta || "—")}</td><td>${esc(i.origem_nome)}<span class="sublinha" title="${esc(i.arquivo || "")}">${esc((i.arquivo || "").slice(0, 38))}</span></td>
        <td>${i.inicio ? `${dataBR(i.inicio)} a ${dataBR(i.fim)}` : "—"}</td>
        <td class="num">${i.novos}${i.duplicados ? `<span class="sublinha">${i.duplicados} repetidos</span>` : ""}</td>
        <td class="num">${i.conciliados}${i.pendentes ? `<span class="sublinha">${i.pendentes} a conciliar</span>` : ""}</td>
        <td>${pode() && i.novos && !i.conciliados && (i.pendentes || i.ignorados) ? `<button type="button" class="btn" data-desf-imp="${i.id}">Desfazer</button>` : ""}</td></tr>`).join("")}
    </tbody></table></div>
    <p class="dica-campo">Desfazer apaga os movimentos que a importação trouxe. Só é possível enquanto nenhum deles foi conciliado.</p>` :
    `<div class="vazio">Nenhuma importação ainda.</div>`, null, {largo: true});
  $$("[data-desf-imp]", corpo).forEach(b => b.onclick = tentar(async () => {
    const i = lista.find(x => x.id === +b.dataset.desfImp);
    if (!await confirmar(`Desfazer a importação de ${esc(i.arquivo || i.origem_nome)}? Os ${i.pendentes + i.ignorados} movimento(s) que ela trouxe serão apagados do extrato desta conta.`, "Desfazer importação")) return historicoImportacoes();
    const r = await api(E(`/importacoes/${i.id}`), {metodo: "DELETE"});
    toast(`Importação desfeita: ${r.removidos} movimento(s) removido(s).`);
    await ir("bancos"); historicoImportacoes();
  }));
}

// ================================================================== sincronizar (Inter ou Open Finance)

async function sincronizarConta(contaId, botao) {
  const txt = botao?.textContent;
  if (botao) { botao.disabled = true; botao.textContent = "Sincronizando…"; }
  try {
    const r = await api(E(`/contas/${contaId}/sincronizar`), {metodo: "POST"});
    const conc = r.conciliados_auto + r.baixas_ligadas;
    toast(`${r.novos} movimento(s) novo(s)${conc ? `, ${conc} conciliado(s) sozinhos` : ""}${r.saldo_banco !== null ? `. Saldo no banco: ${brl(r.saldo_banco)}` : ""}.`);
    ir("bancos");
  } catch (e) {
    if (e.dados?.reconectar) {
      if (await confirmar(`${esc(e.message)}<br><br>O banco pede que você autorize de novo. Abrir a conexão agora?`, "Conectar de novo"))
        abrirWidget({itemId: e.dados.reconectar, aoConcluir: () => sincronizarConta(contaId)});
    } else toast(e.message, true);
  } finally { if (botao && document.contains(botao)) { botao.disabled = false; botao.textContent = txt; } }
}

// ================================================================== Open Finance (Pluggy)

async function abrirOpenFinance() {
  const st = await api(E("/openfinance"));
  if (!st.configurado) return configurarOpenFinance(st, true);
  const corpo = modal("Conectar banco · Open Finance", `
    <p style="margin-top:0">Você escolhe o banco, entra com o seu acesso e autoriza o compartilhamento no próprio banco.
      O FinancePro só <b>lê</b> extrato e saldo: não faz pagamentos nem transferências.</p>
    <ul class="lista-of">
      <li>Funciona com Itaú, Bradesco, Banco do Brasil, Santander, Caixa, Inter, Nubank, Sicoob, Sicredi, C6 e outros.</li>
      <li>A autorização vale por até 12 meses e pode ser cancelada a qualquer hora, aqui ou no app do banco.</li>
      <li>Depois de conectar, use <b>Sincronizar</b> na conta${st.contas.length ? "" : " para trazer os movimentos novos"}.</li>
    </ul>
    ${st.contas.length ? `<h3 style="font-size:14px;margin:16px 0 6px">Contas já conectadas</h3>
      <div class="tabela-wrap"><table><tbody>${st.contas.map(c => `<tr><td>${esc(c.nome)}</td><td>${esc(c.banco || "")}</td></tr>`).join("")}</tbody></table></div>` : ""}
    ${pode("admin") ? `<p class="dica-campo" style="margin-top:14px">Credenciais da Pluggy: ${esc(st.client_id)}${st.sandbox ? " · bancos de teste ligados" : ""}.
      <a href="#" id="of-config">Alterar</a></p>` : ""}`,
    async () => { abrirWidget({}); }, {rotulo: "Escolher o banco"});
  $("#of-config", corpo) && ($("#of-config", corpo).onclick = e => { e.preventDefault(); configurarOpenFinance(st, false); });
}

function configurarOpenFinance(st, depoisConectar) {
  if (!pode("admin")) {
    return modal("Open Finance", `<p style="margin:0">O Open Finance ainda não foi configurado nesta empresa. Peça a um
      administrador para abrir <b>Bancos › Conectar banco</b> e informar as credenciais da Pluggy.</p>`, null);
  }
  const corpo = modal("Configurar o Open Finance", `
    <p style="margin-top:0">O FinancePro se conecta aos bancos pelo Open Finance por meio da <b>Pluggy</b>, um agregador
      autorizado. É feito uma vez por empresa:</p>
    <ol class="passos-of">
      <li>Crie uma conta em <a href="https://dashboard.pluggy.ai" target="_blank" rel="noopener">dashboard.pluggy.ai</a>.</li>
      <li>No painel, crie uma <b>Application</b> e copie o <b>Client ID</b> e o <b>Client Secret</b>.</li>
      <li>Cole os dois abaixo. O FinancePro confere se estão certos antes de salvar.</li>
    </ol>
    <div class="grade-form">
      <label class="campo largo">Client ID<input type="text" name="client_id" required autocomplete="off" value="${st.configurado ? "" : ""}" placeholder="${st.configurado ? esc(st.client_id) : ""}"></label>
      <label class="campo largo">Client Secret<input type="password" name="client_secret" ${st.configurado ? `placeholder="(mantido: preencha só para trocar)"` : "required"} autocomplete="new-password"></label>
      <label class="opcao largo"><input type="checkbox" name="sandbox" ${st.sandbox ? "checked" : ""}> Mostrar bancos de teste da Pluggy (para experimentar sem um banco real)</label>
    </div>
    <p class="dica-campo">O Client Secret fica cifrado no banco de dados. Para conectar bancos reais, a aplicação na Pluggy precisa estar
      em produção; com a conta de teste, só os bancos de teste aparecem.</p>
    ${st.configurado ? `<button type="button" class="btn perigo" id="of-remover">Remover as credenciais e desconectar as contas</button>` : ""}`,
    async f => {
      const d = Object.fromEntries(f);
      if (!d.client_id && st.configurado) throw new Error("Informe o Client ID (ele aparece no painel da Pluggy).");
      await api(E("/openfinance"), {metodo: "PUT", corpo: {client_id: d.client_id, client_secret: d.client_secret || null, sandbox: !!d.sandbox}});
      toast("Open Finance configurado.");
      if (depoisConectar) setTimeout(() => abrirOpenFinance(), 0);
    }, {rotulo: "Salvar e testar"});
  $("#of-remover", corpo) && ($("#of-remover", corpo).onclick = tentar(async () => {
    if (!await confirmar("Remover as credenciais da Pluggy? As contas conectadas param de sincronizar (os movimentos já importados continuam).", "Remover")) return;
    await api(E("/openfinance"), {metodo: "DELETE"}); CAD.contas = null; toast("Open Finance removido."); ir("bancos");
  }));
}

let _pluggyJs = null;
function carregarWidget(url) {
  if (window.PluggyConnect) return Promise.resolve();
  _pluggyJs ??= new Promise((ok, falha) => {
    const s = document.createElement("script");
    s.src = url; s.async = true; s.onload = ok;
    s.onerror = () => { _pluggyJs = null; falha(new Error("Não consegui carregar a tela de conexão da Pluggy. Confira a internet.")); };
    document.head.append(s);
  });
  return _pluggyJs;
}

async function abrirWidget({itemId = null, aoConcluir = null}) {
  try {
    const t = await api(E("/openfinance/token"), {metodo: "POST", corpo: {item_id: itemId}});
    await carregarWidget(t.widget);
    fecharModal();
    const w = new window.PluggyConnect({
      connectToken: t.token, includeSandbox: t.sandbox, ...(itemId ? {updateItem: itemId} : {}),
      onSuccess: d => { const id = d?.item?.id; if (!id) return; aoConcluir ? aoConcluir(id) : ligarContas(id); },
      onError: e => toast(e?.message || "O banco não concluiu a conexão.", true),
    });
    w.init();
  } catch (e) { toast(e.message, true); }
}

async function ligarContas(itemId) {
  modal("Conectando…", `<div class="carregando">Buscando as contas no banco…</div>`, null);
  let info;
  try { info = await api(E(`/openfinance/itens/${itemId}/contas`)); }
  catch (e) { fecharModal(); return toast(e.message, true); }
  const minhas = (CAD.contas || []).filter(c => c.ativo && c.tipo !== "caixa");
  const parecida = pc => minhas.find(c => c.numero && pc.numero && c.numero.replace(/\D/g, "").replace(/^0+/, "") === pc.numero.replace(/\D/g, "").replace(/^0+/, ""));
  const noventa = new Date(); noventa.setDate(noventa.getDate() - 90);
  const corpo = modal(`${esc(info.banco || "Banco")} conectado`, `
    <p style="margin-top:0">Escolha em qual conta do FinancePro entra o extrato de cada conta do banco.</p>
    <div class="tabela-wrap"><table><thead><tr><th>Conta no banco</th><th class="num">Saldo</th><th>No FinancePro</th></tr></thead><tbody>
    ${info.contas.map(pc => {
      const atual = pc.conta_id || parecida(pc)?.id;
      return `<tr><td><b>${esc(pc.nome)}</b><span class="sublinha">${esc([TIPO_CONTA[pc.tipo], pc.numero].filter(Boolean).join(" · "))}</span></td>
        <td class="num">${pc.saldo !== null && pc.saldo !== undefined ? brl(pc.saldo) : "—"}</td>
        <td><select data-acc="${esc(pc.id)}" style="min-width:220px">
          <option value="criar" ${atual ? "" : "selected"}>Criar a conta “${esc(`${info.banco || ""} ${pc.tipo === "cartao" ? "Cartão" : "PJ"}`.trim())}”</option>
          ${minhas.map(c => `<option value="${c.id}" ${c.id === atual ? "selected" : ""}>${esc(c.nome)}</option>`).join("")}
          <option value="">Não trazer esta conta</option></select></td></tr>`;
    }).join("")}</tbody></table></div>
    <div class="grade-form" style="margin-top:14px"><label class="campo">Trazer movimentos desde<input type="date" name="inicio" value="${iso(noventa)}"></label></div>
    <p class="dica-campo">Movimentos que já estão no FinancePro (de um OFX ou planilha) não entram de novo.</p>`,
    async f => {
      const vinculos = $$("[data-acc]", corpo).filter(s => s.value).map(s => {
        const pc = info.contas.find(x => x.id === s.dataset.acc);
        return s.value === "criar" ? {account_id: pc.id, criar: {nome: `${info.banco || ""} ${pc.tipo === "cartao" ? "Cartão" : "PJ"}`.trim().slice(0, 80) || pc.nome,
                                                                tipo: pc.tipo, numero: pc.numero || null}}
                                   : {account_id: pc.id, conta_id: +s.value};
      });
      if (!vinculos.length) throw new Error("Escolha ao menos uma conta.");
      $("#modal-ok").textContent = "Trazendo o extrato…";
      const r = await api(E(`/openfinance/itens/${itemId}/ligar`), {metodo: "POST", corpo: {vinculos, inicio: f.get("inicio") || null}});
      CAD.contas = await api(E("/contas"));
      const ok = r.contas.filter(x => !x.erro), erro = r.contas.filter(x => x.erro);
      toast(ok.map(x => `${x.conta}: ${x.novos} movimento(s)`).join(" · ") || "Contas conectadas.");
      erro.forEach(x => toast(`${x.conta}: ${x.erro}`, true));
      ir("bancos");
    }, {rotulo: "Conectar e trazer o extrato", largo: true});
}

function conexaoOpenFinance(contaId) {
  const c = (CAD.contas || []).find(x => x.id === contaId);
  if (!c) return;
  const corpo = modal(`Conexão · ${esc(c.nome)}`, `<dl class="ficha">
      <dt>Banco</dt><dd>${esc(c.integracao_banco || "—")}</dd>
      <dt>Última sincronização</dt><dd>${c.ultima_sincronizacao ? new Date(c.ultima_sincronizacao).toLocaleString("pt-BR") : "—"}</dd></dl>
    <p class="dica-campo">Se o banco pedir nova autorização (senha trocada, consentimento vencido), use <b>Autorizar de novo</b>.</p>
    <div class="linha-acoes" style="margin-top:12px">
      <button type="button" class="btn" id="of-reauto">Autorizar de novo</button>
      <button type="button" class="btn perigo" id="of-desligar">Desconectar esta conta</button></div>`, null);
  $("#of-reauto", corpo).onclick = tentar(async () => {
    const st = await api(E("/openfinance"));
    const item = st.contas.find(x => x.id === contaId)?.item_id;
    abrirWidget({itemId: item, aoConcluir: () => sincronizarConta(contaId)});
  });
  $("#of-desligar", corpo).onclick = tentar(async () => {
    if (!await confirmar(`Desconectar ${esc(c.nome)} do Open Finance? Os movimentos já importados continuam; o acesso ao banco é revogado.`, "Desconectar")) return;
    await api(E(`/openfinance/contas/${contaId}`), {metodo: "DELETE"}); CAD.contas = null; toast("Conta desconectada."); ir("bancos");
  });
}

// ================================================================== Inter (API própria) e transferências

function configurarInter(contaId) {
  const c = CAD.contas.find(x => x.id === contaId);
  modal("Integração com a API do Inter", `
    <p style="margin-top:0">No Internet Banking PJ do Inter: <b>Soluções para sua empresa › Nova integração</b>. Marque a permissão de
      <b>consultar extrato e saldo</b>. O Inter mostra o Client ID e o Client Secret e baixa um arquivo .zip com o certificado.</p>
    <div class="grade-form">
      <label class="campo largo">Client ID<input type="text" name="client_id" required value="${esc(c.integracao_client_id || "")}" autocomplete="off"></label>
      <label class="campo largo">Client Secret<input type="password" name="client_secret" ${c.integracao === "inter" ? `placeholder="(mantido: preencha só para trocar)"` : "required"} autocomplete="new-password"></label>
      <label class="campo largo">Certificado (.zip do Inter, sem descompactar)<input type="file" name="certificado" accept=".zip,.pem,.crt,.key" ${c.integracao === "inter" ? "" : "required"}></label>
      <label class="campo largo">Número da conta no Inter (opcional)<input type="text" name="conta_corrente" value="${esc(c.integracao_conta_corrente || "")}"><span class="dica-campo">Só se a integração tiver acesso a mais de uma conta.</span></label>
    </div>
    <p class="dica-campo">O Client Secret fica cifrado no banco de dados e o certificado numa pasta protegida do servidor.
      Também dá para conectar o Inter pelo Open Finance, em <b>Conectar banco</b>.</p>
    ${c.integracao === "inter" ? `<button type="button" class="btn perigo" id="desligar">Desligar a integração</button>` : ""}`,
    async f => {
      if (!f.get("client_secret")) f.delete("client_secret");
      if (!f.get("certificado")?.size) f.delete("certificado");
      await api(E(`/contas/${contaId}/inter`), {metodo: "POST", form: f});
      CAD.contas = null; toast("Integração salva. Clique em Sincronizar para buscar o extrato."); ir("bancos");
    }, {rotulo: "Salvar integração"});
  $("#desligar") && ($("#desligar").onclick = tentar(async () => {
    if (!await confirmar("Desligar a API do Inter nesta conta? Os movimentos já importados continuam.", "Desligar")) return;
    await api(E(`/contas/${contaId}/inter`), {metodo: "DELETE"}); CAD.contas = null; toast("Integração desligada."); ir("bancos"); }));
}

function novaTransferencia() {
  if ((CAD.contas || []).filter(c => c.ativo).length < 2) return toast("Cadastre ao menos duas contas para transferir entre elas.", true);
  modal("Transferência entre contas", `<div class="grade-form">
      <label class="campo">Saiu de<select name="conta_origem_id" required>${optContas(null)}</select></label>
      <label class="campo">Entrou em<select name="conta_destino_id" required>${optContas(null)}</select></label>
      <label class="campo">Data<input type="date" name="data" value="${hojeISO()}" required></label>
      <label class="campo">Valor (R$)<input type="text" name="valor" inputmode="decimal" required placeholder="0,00"></label>
      <label class="campo largo">Descrição<input type="text" name="descricao" placeholder="Ex.: aplicação no CDB, pagamento da fatura do cartão"></label></div>
    <p class="dica-campo">Transferência não é receita nem despesa. Se o extrato das duas contas já estiver importado, os movimentos ficam conciliados.</p>`,
    async f => {
      const d = Object.fromEntries(f);
      if (!d.conta_origem_id || !d.conta_destino_id) throw new Error("Escolha as duas contas.");
      if (d.conta_origem_id === d.conta_destino_id) throw new Error("Escolha contas diferentes.");
      const valor = valorBR(d.valor);
      if (!(+valor > 0)) throw new Error("Informe um valor maior que zero.");
      await api(E("/transferencias"), {metodo: "POST", corpo: {...d, conta_origem_id: +d.conta_origem_id, conta_destino_id: +d.conta_destino_id, valor}});
      toast("Transferência registrada."); ir("bancos");
    });
}
