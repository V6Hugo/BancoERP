/* Cadastros: plano de contas, centros de custo, clientes e fornecedores, contas bancárias, regras, usuários e empresa. */
"use strict";

const ABAS_CAD = [["plano", "Plano de contas"], ["centros", "Centros de custo"], ["contatos", "Clientes e fornecedores"],
                  ["contas", "Contas bancárias"], ["regras", "Regras do extrato"], ["usuarios", "Usuários"], ["seguranca", "Segurança"], ["empresa", "Empresa"]];
let ABA_CAD = "plano";

TELAS.cadastros = async (main, param) => {
  if (param && ABAS_CAD.some(a => a[0] === param)) ABA_CAD = param;
  const abas = ABAS_CAD.filter(([k]) => !["usuarios", "seguranca", "empresa"].includes(k) || pode("admin"));
  main.innerHTML = `<div class="topo-tela"><div><h1>Cadastros</h1><p class="sub">Tudo o que organiza os lançamentos. Alterações valem na hora para todas as telas.</p></div></div>
    <div class="abas" role="tablist">${abas.map(([k, t]) => `<button role="tab" data-aba="${k}">${t}</button>`).join("")}</div><div id="cad"></div>`;
  const abrir = tentar(async () => {
    $$(".abas button").forEach(b => b.setAttribute("aria-selected", b.dataset.aba === ABA_CAD));
    history.replaceState(null, "", "#cadastros/" + ABA_CAD);
    await carregarCadastros(true);
    await ({plano: cadPlano, centros: cadCentros, contatos: cadContatos, contas: cadContas, regras: cadRegras,
            usuarios: cadUsuarios, seguranca: cadSeguranca, empresa: cadEmpresa})[ABA_CAD]($("#cad"));
  });
  $$(".abas button").forEach(b => b.onclick = () => { ABA_CAD = b.dataset.aba; abrir(); });
  await abrir();
};

// ------------------------------------------------------------------ plano de contas
const NATUREZA = {receita: "Receita", despesa: "Despesa", neutra: "Movimentação"};
async function cadPlano(el) {
  const linhasDre = await api(E("/linhas-dre"));
  const adm = pode("admin");
  el.innerHTML = `<div class="linha-acoes" style="margin-bottom:14px;justify-content:space-between">
      <p class="sub" style="margin:0">Dois níveis: <b>grupos</b> (definem a linha do DRE) e <b>categorias</b> (onde se lança). Clique no nome para renomear. Desative o que não usa; o que tem lançamento não pode ser excluído.</p>
      ${adm ? `<button class="btn primario" id="novo-grupo">+ Novo grupo</button>` : ""}</div>
    <div class="arvore">${CAD.categorias.map(g => `
      <div class="grupo ${g.ativo ? "" : "inativo"}" data-id="${g.id}">
        <header><span class="cod">${esc(g.codigo)}</span><span class="nm" data-edita="${g.id}">${esc(g.nome)}</span>
          ${selo(g.natureza, NATUREZA[g.natureza])}<span class="usos">${esc(g.grupo_dre_nome)}</span>
          ${adm ? `<button class="mini" data-grupo="${g.id}" title="Editar grupo">Editar</button>` : ""}</header>
        ${g.categorias.map(c => `<div class="cat ${c.ativo ? "" : "inativo"}" data-id="${c.id}"><span class="cod">${esc(c.codigo)}</span>
          <span class="nm" data-edita="${c.id}">${esc(c.nome)}</span><span class="usos">${c.usos ? c.usos + " lanç." : ""}</span>
          ${adm ? `<button class="mini" data-ativo="${c.id}">${c.ativo ? "Desativar" : "Ativar"}</button>
          ${c.usos ? "" : `<button class="mini" data-excluir="${c.id}" title="Excluir">Excluir</button>`}` : ""}</div>`).join("")}
        ${adm ? `<div class="nova"><button data-nova="${g.id}">+ Categoria em ${esc(g.nome)}</button></div>` : ""}
      </div>`).join("")}</div>`;
  if (!adm) return;
  const salvarCat = async (c, mud) => api(E(`/categorias/${c.id}`), {metodo: "PUT", corpo: {nome: c.nome, codigo: c.codigo, pai_id: c.pai_id,
    natureza: c.pai_id ? null : c.natureza, grupo_dre: c.pai_id ? null : c.grupo_dre, ativo: c.ativo, ...mud}});
  $$("[data-edita]", el).forEach(sp => sp.ondblclick = sp.onclick = () => {
    const c = catPorId(+sp.dataset.edita);
    sp.outerHTML = `<form class="edita-inline" data-f="${c.id}"><input type="text" value="${esc(c.nome)}" required maxlength="120"><button class="btn primario" style="padding:4px 12px">OK</button></form>`;
    const f = $(`form[data-f="${c.id}"]`, el), inp = $("input", f); inp.focus(); inp.select();
    f.onsubmit = tentar(async ev => { ev.preventDefault(); await salvarCat(c, {nome: inp.value.trim()}); toast("Nome alterado."); cadPlanoRecarregar(el); });
    inp.onkeydown = e => { if (e.key === "Escape") cadPlanoRecarregar(el); };
  });
  $$("[data-ativo]", el).forEach(b => b.onclick = tentar(async () => {
    const c = catPorId(+b.dataset.ativo); await salvarCat(c, {ativo: !c.ativo}); cadPlanoRecarregar(el); }));
  $$("[data-excluir]", el).forEach(b => b.onclick = tentar(async () => {
    const c = catPorId(+b.dataset.excluir);
    if (!await confirmar(`Excluir a categoria “${esc(c.codigo + " " + c.nome)}”?`, "Excluir")) return;
    await api(E(`/categorias/${c.id}`), {metodo: "DELETE"}); toast("Categoria excluída."); cadPlanoRecarregar(el); }));
  $$("[data-nova]", el).forEach(b => b.onclick = () => {
    const g = catPorId(+b.dataset.nova);
    modal(`Nova categoria em ${g.codigo} ${g.nome}`, `<div class="grade-form"><label class="campo largo">Nome<input type="text" name="nome" required maxlength="120"></label>
      <label class="campo">Código<input type="text" name="codigo" placeholder="automático"></label></div>`, async f => {
        await api(E("/categorias"), {metodo: "POST", corpo: {nome: f.get("nome"), codigo: f.get("codigo") || null, pai_id: g.id}});
        toast("Categoria criada."); cadPlanoRecarregar(el); });
  });
  const formGrupo = g => modal(g ? `Editar grupo ${g.codigo}` : "Novo grupo", `<div class="grade-form">
      <label class="campo largo">Nome<input type="text" name="nome" required value="${esc(g?.nome)}"></label>
      <label class="campo">Natureza<select name="natureza">${Object.entries(NATUREZA).map(([k, v]) => `<option value="${k}" ${g?.natureza === k ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="campo">Linha do DRE<select name="grupo_dre">${linhasDre.map(l => `<option value="${l.id}" ${g?.grupo_dre === l.id ? "selected" : ""}>${esc(l.nome)}</option>`).join("")}</select></label>
      <label class="campo">Código<input type="text" name="codigo" value="${esc(g?.codigo || "")}" placeholder="automático"></label>
      ${g ? `<label class="opcao"><input type="checkbox" name="ativo" ${g.ativo ? "checked" : ""}> Ativo</label>` : ""}</div>
      <p class="dica-campo">A natureza e a linha do DRE do grupo valem para todas as categorias dentro dele.</p>`, async f => {
      const corpo = {nome: f.get("nome"), natureza: f.get("natureza"), grupo_dre: f.get("grupo_dre"), codigo: f.get("codigo") || null,
                     pai_id: null, ativo: g ? !!f.get("ativo") : true};
      if (g) await api(E(`/categorias/${g.id}`), {metodo: "PUT", corpo}); else await api(E("/categorias"), {metodo: "POST", corpo});
      toast("Grupo salvo."); cadPlanoRecarregar(el);
    });
  $("#novo-grupo").onclick = () => formGrupo(null);
  $$("[data-grupo]", el).forEach(b => b.onclick = () => formGrupo(catPorId(+b.dataset.grupo)));
}
async function cadPlanoRecarregar(el) { CAD.categorias = await api(E("/categorias")); cadPlano(el); }

// ------------------------------------------------------------------ centros de custo
async function cadCentros(el) {
  const adm = pode("admin");
  el.innerHTML = `<div class="linha-acoes" style="margin-bottom:14px;justify-content:space-between">
      <p class="sub" style="margin:0">Áreas, unidades, projetos ou obras: o que você quer enxergar separado nos relatórios.</p>
      ${adm ? `<button class="btn primario" id="novo">+ Novo centro de custo</button>` : ""}</div>
    <div class="tabela-wrap"><table><thead><tr><th>Código</th><th>Nome</th><th class="num">Lançamentos</th><th>Situação</th><th></th></tr></thead><tbody>
    ${CAD.centros.map(c => `<tr><td>${esc(c.codigo)}</td><td>${esc(c.nome)}</td><td class="num">${c.usos || "—"}</td><td>${c.ativo ? selo("pago", "Ativo") : selo("inativo", "Inativo")}</td>
      <td>${adm ? `<div class="acoes-linha"><button class="btn" data-ed="${c.id}">Editar</button>${c.usos ? "" : `<button class="btn perigo" data-ex="${c.id}">Excluir</button>`}</div>` : ""}</td></tr>`).join("")}
    </tbody></table></div>`;
  if (!adm) return;
  const form = c => modal(c ? "Editar centro de custo" : "Novo centro de custo", `<div class="grade-form">
      <label class="campo">Código<input type="text" name="codigo" value="${esc(c?.codigo || "")}" placeholder="automático"></label>
      <label class="campo">Nome<input type="text" name="nome" required value="${esc(c?.nome || "")}"></label>
      ${c ? `<label class="opcao"><input type="checkbox" name="ativo" ${c.ativo ? "checked" : ""}> Ativo</label>` : ""}</div>`, async f => {
      const corpo = {codigo: f.get("codigo") || null, nome: f.get("nome"), ativo: c ? !!f.get("ativo") : true};
      if (c) await api(E(`/centros-custo/${c.id}`), {metodo: "PUT", corpo}); else await api(E("/centros-custo"), {metodo: "POST", corpo});
      toast("Centro de custo salvo."); CAD.centros = await api(E("/centros-custo")); cadCentros(el);
    });
  $("#novo").onclick = () => form(null);
  $$("[data-ed]", el).forEach(b => b.onclick = () => form(CAD.centros.find(c => c.id === +b.dataset.ed)));
  $$("[data-ex]", el).forEach(b => b.onclick = tentar(async () => {
    const cc = CAD.centros.find(c => c.id === +b.dataset.ex);
    if (!await confirmar(`Excluir o centro de custo ${esc(cc?.nome || "")}?`, "Excluir")) return;
    await api(E(`/centros-custo/${b.dataset.ex}`), {metodo: "DELETE"}); toast("Excluído."); CAD.centros = await api(E("/centros-custo")); cadCentros(el); }));
}

// ------------------------------------------------------------------ clientes e fornecedores
const ESTADO_CT = {busca: "", tipo: "", pagina: 0};
async function cadContatos(el) {
  el.innerHTML = `<div class="barra-filtros"><label class="campo busca">Buscar<input type="search" id="ct-busca" value="${esc(ESTADO_CT.busca)}" placeholder="Nome, e-mail ou CPF/CNPJ"></label>
      <div id="ct-tipo"></div>${pode() ? `<button class="btn primario" id="ct-novo" style="margin-left:auto">+ Novo cadastro</button>` : ""}</div>
    <div class="tabela-wrap"><table><thead><tr><th>Nome</th><th>Tipo</th><th>CPF/CNPJ</th><th>Contato</th><th>Categoria padrão</th><th>Situação</th></tr></thead><tbody id="ct-corpo"></tbody></table></div>
    <div class="paginacao" id="ct-pag"></div>`;
  $("#ct-tipo").append(seg([["", "Todos"], ["cliente", "Clientes"], ["fornecedor", "Fornecedores"]], ESTADO_CT.tipo, v => { ESTADO_CT.tipo = v; ESTADO_CT.pagina = 0; carregar(); }));
  let espera;
  $("#ct-busca").oninput = e => { clearTimeout(espera); espera = setTimeout(() => { ESTADO_CT.busca = e.target.value; ESTADO_CT.pagina = 0; carregar(); }, 300); };
  $("#ct-novo") && ($("#ct-novo").onclick = () => formContato(null, carregar));
  const docFmt = d => !d ? "—" : d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4") : d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
  async function carregar() {
    const r = await api(E("/contatos?" + qs({busca: ESTADO_CT.busca, tipo: ESTADO_CT.tipo, pagina: ESTADO_CT.pagina, por_pagina: 100})));
    $("#ct-corpo").innerHTML = r.itens.map(c => `<tr class="clicavel" data-id="${c.id}"><td>${esc(c.nome)}</td><td>${({cliente: "Cliente", fornecedor: "Fornecedor", ambos: "Cliente e fornecedor"})[c.tipo]}</td>
      <td>${docFmt(c.documento)}</td><td>${esc([c.email, c.telefone].filter(Boolean).join(" · ") || "—")}</td>
      <td>${esc(catPorId(c.categoria_padrao_id) ? catPorId(c.categoria_padrao_id).codigo + " " + catPorId(c.categoria_padrao_id).nome : "—")}</td>
      <td>${c.ativo ? selo("pago", "Ativo") : selo("inativo", "Inativo")}</td></tr>`).join("") || `<tr><td colspan="6" class="vazio">Nenhum cadastro encontrado.</td></tr>`;
    const pags = Math.ceil(r.total / 100);
    $("#ct-pag").innerHTML = `<span>${r.total} cadastros</span>` + (pags > 1 ? `<span class="linha-acoes"><button class="btn" id="ct-ant" ${ESTADO_CT.pagina ? "" : "disabled"}>Anterior</button>
      <button class="btn" id="ct-prox" ${ESTADO_CT.pagina + 1 < pags ? "" : "disabled"}>Próxima</button></span>` : "");
    $("#ct-ant") && ($("#ct-ant").onclick = () => { ESTADO_CT.pagina--; carregar(); });
    $("#ct-prox") && ($("#ct-prox").onclick = () => { ESTADO_CT.pagina++; carregar(); });
    $$("#ct-corpo tr[data-id]").forEach(tr => tr.onclick = () => pode() && formContato(r.itens.find(c => c.id === +tr.dataset.id), carregar));
  }
  await carregar();
}
function formContato(c, aoSalvar) {
  modal(c ? "Editar cadastro" : "Novo cliente ou fornecedor", `<div class="grade-form">
      <label class="campo largo">Nome<input type="text" name="nome" required value="${esc(c?.nome || "")}"></label>
      <label class="campo">Tipo<select name="tipo">${[["fornecedor", "Fornecedor"], ["cliente", "Cliente"], ["ambos", "Cliente e fornecedor"]].map(([k, v]) => `<option value="${k}" ${c?.tipo === k ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="campo">CPF ou CNPJ<input type="text" name="documento" value="${esc(c?.documento || "")}" inputmode="numeric"></label>
      <label class="campo">E-mail<input type="email" name="email" value="${esc(c?.email || "")}"></label>
      <label class="campo">Telefone<input type="text" name="telefone" value="${esc(c?.telefone || "")}"></label>
      <label class="campo">Chave Pix<input type="text" name="chave_pix" value="${esc(c?.chave_pix || "")}"></label>
      <label class="campo">Banco / agência / conta<input type="text" name="banco" value="${esc(c?.banco || "")}"></label>
      <label class="campo">Categoria padrão<select name="categoria_padrao_id">${optCategorias(null, c?.categoria_padrao_id, {vazio: "— nenhuma —"})}</select><span class="dica-campo">Sugerida ao lançar e ao conciliar o extrato.</span></label>
      <label class="campo">Centro de custo padrão<select name="centro_custo_padrao_id">${optCentros(c?.centro_custo_padrao_id)}</select></label>
      <label class="campo largo">Observação<textarea name="observacao">${esc(c?.observacao || "")}</textarea></label>
      ${c ? `<label class="opcao"><input type="checkbox" name="ativo" ${c.ativo ? "checked" : ""}> Ativo</label>` : ""}</div>
    ${c ? `<button type="button" class="btn perigo" id="ct-excluir">Excluir cadastro</button>` : ""}`, async f => {
      const d = Object.fromEntries(f);
      const corpo = {...d, categoria_padrao_id: +d.categoria_padrao_id || null, centro_custo_padrao_id: +d.centro_custo_padrao_id || null,
                     ativo: c ? !!d.ativo : true};
      for (const k of ["documento", "email", "telefone", "chave_pix", "banco", "observacao"]) corpo[k] = corpo[k] || null;
      if (c) await api(E(`/contatos/${c.id}`), {metodo: "PUT", corpo}); else await api(E("/contatos"), {metodo: "POST", corpo});
      CAD.contatos = null; toast("Cadastro salvo."); aoSalvar?.();
    });
  $("#ct-excluir") && ($("#ct-excluir").onclick = tentar(async () => {
    if (!await confirmar(`Excluir o cadastro ${esc(c.nome)}? Só é possível se ele não tiver lançamentos.`, "Excluir")) return;
    await api(E(`/contatos/${c.id}`), {metodo: "DELETE"}); CAD.contatos = null; toast("Cadastro excluído."); aoSalvar?.(); }));
}

// ------------------------------------------------------------------ contas bancárias
async function cadContas(el) {
  const bancos = await api(E("/bancos")), adm = pode("admin");
  const TIPO = {corrente: "Conta corrente", poupanca: "Poupança", investimento: "Investimento", caixa: "Caixa (dinheiro)", cartao: "Cartão de crédito"};
  el.innerHTML = `<div class="linha-acoes" style="margin-bottom:14px;justify-content:space-between">
      <p class="sub" style="margin:0">O saldo inicial é o saldo da conta no dia informado; tudo depois dele vem dos lançamentos e do extrato. Cartão de crédito fica fora do saldo disponível.</p>
      ${adm ? `<button class="btn primario" id="nova">+ Nova conta</button>` : ""}</div>
    <div class="tabela-wrap"><table><thead><tr><th>Conta</th><th>Banco</th><th>Agência / número</th><th>Tipo</th><th class="num">Saldo inicial</th><th>Integração</th><th>Situação</th></tr></thead><tbody>
    ${CAD.contas.map(c => `<tr class="${adm ? "clicavel" : ""}" data-id="${c.id}"><td>${esc(c.nome)}</td><td>${esc(c.banco_nome || c.banco_codigo || "—")}</td>
      <td>${esc([c.agencia, c.numero].filter(Boolean).join(" / ") || "—")}</td><td>${TIPO[c.tipo]}</td>
      <td class="num">${brl(c.saldo_inicial)}${c.data_saldo_inicial ? `<span class="sublinha">em ${dataBR(c.data_saldo_inicial)}</span>` : ""}</td>
      <td>${c.integracao === "inter" ? selo("conciliado", "API Inter") : c.integracao === "openfinance" ? selo("conciliado", "Open Finance" + (c.integracao_banco ? " · " + c.integracao_banco : "")) : c.tipo === "caixa" ? "—" : "Arquivo (OFX, Excel, CSV)"}</td><td>${c.ativo ? selo("pago", "Ativa") : selo("inativo", "Inativa")}</td></tr>`).join("")
      || `<tr><td colspan="7" class="vazio">Nenhuma conta ainda.</td></tr>`}</tbody></table></div>`;
  if (!adm) return;
  const form = c => modal(c ? "Editar conta" : "Nova conta", `<div class="grade-form">
      <label class="campo largo">Nome da conta<input type="text" name="nome" required value="${esc(c?.nome || "")}" placeholder="Ex.: Itaú PJ, Inter, Caixa da loja"></label>
      <label class="campo">Banco<select name="banco_codigo"><option value="">— nenhum (caixa) —</option>${bancos.map(b => `<option value="${b.codigo}" ${c?.banco_codigo === b.codigo ? "selected" : ""}>${b.codigo} · ${esc(b.nome)}${b.api ? " (API)" : ""}</option>`).join("")}</select></label>
      <label class="campo">Tipo<select name="tipo">${Object.entries(TIPO).map(([k, v]) => `<option value="${k}" ${c?.tipo === k ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="campo">Agência<input type="text" name="agencia" value="${esc(c?.agencia || "")}"></label>
      <label class="campo">Número da conta<input type="text" name="numero" value="${esc(c?.numero || "")}"><span class="dica-campo">Igual ao do extrato: serve para conferir se o arquivo importado é desta conta.</span></label>
      <label class="campo">Saldo inicial (R$)<input type="text" name="saldo_inicial" inputmode="decimal" value="${c ? num(c.saldo_inicial).toFixed(2).replace(".", ",") : "0,00"}"></label>
      <label class="campo">Saldo em<input type="date" name="data_saldo_inicial" value="${c?.data_saldo_inicial || ""}"></label>
      ${c ? `<label class="opcao"><input type="checkbox" name="ativo" ${c.ativo ? "checked" : ""}> Ativa</label>` : ""}</div>
    ${c ? `<button type="button" class="btn perigo" id="cb-excluir">Excluir conta</button>` : ""}`, async f => {
      const d = Object.fromEntries(f);
      const corpo = {...d, banco_codigo: d.banco_codigo || null, agencia: d.agencia || null, numero: d.numero || null,
        saldo_inicial: valorBR(d.saldo_inicial || "0") || "0", data_saldo_inicial: d.data_saldo_inicial || null, ativo: c ? !!d.ativo : true};
      if (c) await api(E(`/contas/${c.id}`), {metodo: "PUT", corpo}); else await api(E("/contas"), {metodo: "POST", corpo});
      toast("Conta salva."); CAD.contas = await api(E("/contas")); cadContas(el);
    });
  $("#nova").onclick = () => form(null);
  $$("tr[data-id]", el).forEach(tr => tr.onclick = () => {
    const c = CAD.contas.find(x => x.id === +tr.dataset.id); form(c);
    $("#cb-excluir").onclick = tentar(async () => {
      if (!await confirmar(`Excluir a conta ${esc(c.nome)}? Só é possível se ela não tiver nenhuma movimentação.`, "Excluir conta")) return;
      await api(E(`/contas/${c.id}`), {metodo: "DELETE"}); toast("Conta excluída."); CAD.contas = await api(E("/contas")); cadContas(el); });
  });
}

// ------------------------------------------------------------------ regras do extrato
async function cadRegras(el) {
  const regras = await api(E("/regras")); await contatos();
  const nomeContato = id => (CAD.contatos || []).find(c => c.id === id)?.nome;
  el.innerHTML = `<div class="linha-acoes" style="margin-bottom:14px;justify-content:space-between">
      <p class="sub" style="margin:0">Quando a descrição do extrato contém o texto, o movimento já vem com a categoria, o centro de custo e o cliente/fornecedor. Também são criadas na conciliação, ao marcar “criar regra”.</p>
      ${pode() ? `<button class="btn primario" id="nova">+ Nova regra</button>` : ""}</div>
    <div class="tabela-wrap"><table><thead><tr><th>Se a descrição contém</th><th>Sentido</th><th>Categoria</th><th>Centro de custo</th><th>Cliente/fornecedor</th><th class="num">Usada</th><th></th></tr></thead><tbody>
    ${regras.map(r => `<tr><td><b>${esc(r.texto)}</b>${r.ativo ? "" : " " + selo("inativo", "Inativa")}</td><td>${({C: "Entrada", D: "Saída", "*": "Qualquer"})[r.natureza]}</td>
      <td>${esc(catPorId(r.categoria_id) ? catPorId(r.categoria_id).codigo + " " + catPorId(r.categoria_id).nome : "—")}</td>
      <td>${esc(CAD.centros.find(c => c.id === r.centro_custo_id)?.nome || "—")}</td><td>${esc(nomeContato(r.contato_id) || "—")}</td>
      <td class="num">${r.vezes_usada}×</td><td>${pode() ? `<div class="acoes-linha"><button class="btn" data-ed="${r.id}">Editar</button><button class="btn perigo" data-ex="${r.id}">Excluir</button></div>` : ""}</td></tr>`).join("")
      || `<tr><td colspan="7" class="vazio">Nenhuma regra ainda.</td></tr>`}</tbody></table></div>`;
  if (!pode()) return;
  const form = r => modal(r ? "Editar regra" : "Nova regra", `<div class="grade-form">
      <label class="campo largo">Se a descrição do extrato contém<input type="text" name="texto" required value="${esc(r?.texto || "")}" placeholder="Ex.: TARIFA, UNIMED, PIX RECEBIDO JOAO"></label>
      <label class="campo">Sentido<select name="natureza">${[["*", "Entrada ou saída"], ["D", "Só saídas"], ["C", "Só entradas"]].map(([k, v]) => `<option value="${k}" ${r?.natureza === k ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="campo">Prioridade<input type="number" name="prioridade" value="${r?.prioridade ?? 100}"><span class="dica-campo">Menor número vale primeiro.</span></label>
      <label class="campo">Categoria<select name="categoria_id">${optCategorias(null, r?.categoria_id)}</select></label>
      <label class="campo">Centro de custo<select name="centro_custo_id">${optCentros(r?.centro_custo_id)}</select></label>
      <label class="campo largo">Cliente/fornecedor${campoContato("contato", nomeContato(r?.contato_id) || "")}</label>
      ${r ? `<label class="opcao"><input type="checkbox" name="ativo" ${r.ativo ? "checked" : ""}> Ativa</label>` : ""}</div>`, async f => {
      const d = Object.fromEntries(f);
      const corpo = {texto: d.texto, natureza: d.natureza, prioridade: +d.prioridade || 100, categoria_id: +d.categoria_id || null,
        centro_custo_id: +d.centro_custo_id || null, contato_id: await resolverContato(d.contato, d.natureza === "C" ? "cliente" : "fornecedor"), ativo: r ? !!d.ativo : true};
      if (r) await api(E(`/regras/${r.id}`), {metodo: "PUT", corpo}); else await api(E("/regras"), {metodo: "POST", corpo});
      toast("Regra salva."); cadRegras(el);
    });
  $("#nova").onclick = () => form(null);
  $$("[data-ed]", el).forEach(b => b.onclick = () => form(regras.find(r => r.id === +b.dataset.ed)));
  $$("[data-ex]", el).forEach(b => b.onclick = tentar(async () => {
    if (!await confirmar("Excluir esta regra do extrato? Os lançamentos já feitos com ela não mudam.", "Excluir")) return;
    await api(E(`/regras/${b.dataset.ex}`), {metodo: "DELETE"}); toast("Regra excluída."); cadRegras(el); }));
}

// ------------------------------------------------------------------ usuários e empresa
async function cadUsuarios(el) {
  const us = await api(E("/usuarios"));
  const PAP = {admin: "Administrador", financeiro: "Financeiro", leitura: "Só consulta"};
  el.innerHTML = `<div class="linha-acoes" style="margin-bottom:14px;justify-content:space-between">
      <p class="sub" style="margin:0"><b>Administrador</b>: tudo, inclusive cadastros e usuários. <b>Financeiro</b>: lança, baixa e concilia. <b>Só consulta</b>: vê telas e relatórios (bom para o contador).</p>
      <button class="btn primario" id="novo">+ Dar acesso</button></div>
    <div class="tabela-wrap"><table><thead><tr><th>Nome</th><th>E-mail</th><th>Acesso</th><th>Duas etapas</th><th>Último acesso</th><th></th></tr></thead><tbody>
    ${us.map(u => `<tr><td>${esc(u.nome)}</td><td>${esc(u.email)}</td><td>${PAP[u.papel]}</td><td>${u.totp_ativo ? selo("pago", "Ligada") : selo("vencido", "Desligada")}</td><td>${u.ultimo_acesso ? new Date(u.ultimo_acesso).toLocaleString("pt-BR") : "—"}</td>
      <td>${u.id !== EU.id ? `<div class="acoes-linha"><button class="btn" data-ed="${u.id}">Alterar acesso</button><button class="btn perigo" data-ex="${u.id}">Tirar acesso</button></div>` : ""}</td></tr>`).join("")}
    </tbody></table></div>`;
  const form = u => modal(u ? "Alterar acesso" : "Dar acesso a esta empresa", `<div class="grade-form">
      <label class="campo largo">E-mail<input type="email" name="email" required value="${esc(u?.email || "")}" ${u ? "readonly" : ""}></label>
      ${u ? "" : `<label class="campo">Nome<input type="text" name="nome"></label><label class="campo">Senha inicial<input type="password" name="senha" autocomplete="new-password"><span class="dica-campo">Só para quem ainda não tem usuário. 10 caracteres ou mais; peça para a pessoa trocar no primeiro acesso.</span></label>`}
      <label class="campo largo">Acesso<select name="papel">${Object.entries(PAP).map(([k, v]) => `<option value="${k}" ${u?.papel === k ? "selected" : ""}>${v}</option>`).join("")}</select></label></div>`, async f => {
      const d = Object.fromEntries(f);
      await api(E("/usuarios"), {metodo: "POST", corpo: {email: d.email, nome: d.nome || null, senha: d.senha || null, papel: d.papel}});
      toast("Acesso salvo."); cadUsuarios(el);
    });
  $("#novo").onclick = () => form(null);
  $$("[data-ed]", el).forEach(b => b.onclick = () => form(us.find(u => u.id === +b.dataset.ed)));
  $$("[data-ex]", el).forEach(b => b.onclick = tentar(async () => {
    if (!await confirmar("Tirar o acesso desta pessoa a esta empresa?", "Tirar acesso")) return;
    await api(E(`/usuarios/${b.dataset.ex}`), {metodo: "DELETE"}); toast("Acesso removido."); cadUsuarios(el); }));
}

async function cadEmpresa(el) {
  const e = await api(E(""));
  el.innerHTML = `<form class="bloco" id="f-emp" style="max-width:640px"><div class="grade-form">
      <label class="campo largo">Nome fantasia<input type="text" name="nome" required value="${esc(e.nome)}"></label>
      <label class="campo">CNPJ<input type="text" name="cnpj" value="${esc(e.cnpj || "")}"></label>
      <label class="campo">Razão social<input type="text" name="razao_social" value="${esc(e.razao_social || "")}"></label></div>
      <div class="linha-acoes" style="margin-top:16px"><button class="btn primario">Salvar</button></div></form>`;
  $("#f-emp").onsubmit = tentar(async ev => {
    ev.preventDefault();
    await api(E(""), {metodo: "PUT", corpo: Object.fromEntries(new FormData(ev.target))});
    EU = await api("/api/eu"); toast("Dados da empresa salvos.");
  });
}
