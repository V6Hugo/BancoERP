/* FinancePro ERP — núcleo da interface: acesso à API, sessão, navegação e componentes comuns. */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
const num = v => Number(v || 0);
const brl = v => num(v).toLocaleString("pt-BR", {style: "currency", currency: "BRL"});
const brlSinal = v => (num(v) < 0 ? "−" : "") + brl(Math.abs(num(v)));
const dataBR = d => d ? String(d).slice(0, 10).split("-").reverse().join("/") : "";
// valor digitado (1.234,56 · 1234,56 · 1234.56 · R$ 10) -> texto decimal para a API ("1234.56"); "" se inválido
function valorBR(txt) {
  let s = String(txt ?? "").replace(/[^\d,.-]/g, "");
  if (!s) return "";
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  else if ((s.match(/\./g) || []).length > 1 || /^\d{1,3}\.\d{3}$/.test(s)) s = s.replace(/\./g, "");
  const n = Number(s);
  return Number.isFinite(n) ? n.toFixed(2) : "";
}
const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const hojeISO = () => iso(new Date());
const MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const MESES_CURTO = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
const mesNome = m => { const [a, mm] = m.split("-"); return `${MESES[+mm - 1]} ${a}`; };
const mesCurto = m => { const [a, mm] = m.split("-"); return `${MESES_CURTO[+mm - 1]}/${a.slice(2)}`; };
const fimDoMes = (a, m) => iso(new Date(a, m, 0));      // m = 1..12
const ROTULO_SIT = {aberto: "Em aberto", parcial: "Parcial", pago: "Pago", vencido: "Vencido", cancelado: "Cancelado",
                    pendente: "Pendente", conciliado: "Conciliado", ignorado: "Ignorado"};

let EU = null, EMP = null, PAPEL = null;
const CAD = {categorias: null, centros: null, contas: null, contatos: null};

// ------------------------------------------------------------------ API
async function api(caminho, {metodo = "GET", corpo, form, _repetida = false} = {}) {
  // X-FP: cabeçalho que só a própria tela envia (proteção contra requisições forjadas por outros sites)
  const op = {method: metodo, credentials: "same-origin", headers: {"X-FP": "1"}};
  if (form) op.body = form;
  else if (corpo !== undefined) { op.body = JSON.stringify(corpo); op.headers["Content-Type"] = "application/json"; }
  const r = await fetch(caminho, op);
  if (r.status === 401 && !caminho.startsWith("/api/login")) { mostrarEntrada(true); throw new Error("Sessão expirada. Entre de novo."); }
  const tipo = r.headers.get("content-type") || "";
  const dados = tipo.includes("json") ? await r.json() : await r.text();
  if (r.status === 403 && dados?.confirmar && !_repetida) {
    // ação sensível: pede a senha (e o código) e repete a mesma chamada
    if (await pedirConfirmacao(dados.pedir_codigo)) return api(caminho, {metodo, corpo, form, _repetida: true});
    throw new Error("Ação cancelada: a senha não foi confirmada.");
  }
  if (!r.ok) {
    let msg = dados?.detail ?? dados;
    if (Array.isArray(msg)) msg = msg.map(traduzirValidacao).join("; ");
    const erro = new Error(typeof msg === "string" ? msg : `Erro ${r.status}`);
    erro.dados = dados; erro.status = r.status;
    throw erro;
  }
  return dados;
}
// mensagens de validação da API (em inglês) para português
const CAMPOS_PT = {valor: "Valor", descricao: "Descrição", vencimento: "Vencimento", competencia: "Competência", nome: "Nome",
  email: "E-mail", senha: "Senha", nova: "Nova senha", data: "Data", client_id: "Client ID", documento: "Documento",
  conta_bancaria_id: "Conta", categoria_id: "Categoria", texto: "Texto", codigo: "Código", saldo_inicial: "Saldo inicial",
  conta_origem_id: "Conta de origem", conta_destino_id: "Conta de destino", parcelas: "Parcelas", repetir_meses: "Repetição"};
function traduzirValidacao(e) {
  const campo = CAMPOS_PT[(e.loc || []).slice(-1)[0]] || (e.loc || []).slice(-1)[0] || "Campo";
  const m = e.msg || "";
  const t = /required/i.test(m) ? "é obrigatório" : /greater than 0|greater than or equal to 1/i.test(m) ? "precisa ser maior que zero"
    : /at least 1 character/i.test(m) ? "não pode ficar vazio" : /at most (\d+) character/i.test(m) ? `aceita até ${m.match(/(\d+)/)[1]} caracteres`
    : /valid decimal|valid number|valid integer/i.test(m) ? "não é um número válido" : /valid date/i.test(m) ? "não é uma data válida"
    : /valid email/i.test(m) ? "não é um e-mail válido" : /pattern/i.test(m) ? "tem um valor não aceito" : m;
  return `${campo} ${t}`;
}
const E = caminho => `/api/e/${EMP}${caminho}`;
const qs = o => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== null && v !== undefined && v !== "")).toString();

function toast(msg, erro = false) {
  const t = document.createElement("div");
  t.className = "toast" + (erro ? " erro" : "");
  t.textContent = msg;
  $("#toasts").append(t);
  setTimeout(() => t.remove(), erro ? 6000 : 3200);
}
const tentar = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };
const pode = (min = "financeiro") => ({leitura: 1, financeiro: 2, admin: 3})[PAPEL] >= ({leitura: 1, financeiro: 2, admin: 3})[min];

// ------------------------------------------------------------------ janela (modal) e gaveta
let _modalOk = null;
function modal(titulo, html, aoSalvar, {rotulo = "Salvar", largo = false} = {}) {
  $("#modal-titulo").textContent = titulo;
  $("#modal-corpo").innerHTML = html;
  $("#modal-erro").textContent = "";
  $("#modal-ok").textContent = rotulo;
  $("#modal-ok").hidden = !aoSalvar;
  $("#modal-cancelar").hidden = false;
  $("#modal .caixa").style.width = largo ? "min(920px,100%)" : "";
  _modalOk = aoSalvar;
  $("#modal").classList.add("ativo");
  setTimeout(() => $("#modal-corpo input:not([type=hidden]),#modal-corpo select")?.focus(), 30);
  return $("#modal-corpo");
}
function fecharModal() { $("#modal").classList.remove("ativo"); _modalOk = null; }
$("#modal-form").addEventListener("submit", async ev => {
  ev.preventDefault();
  if (!_modalOk) return;
  const b = $("#modal-ok"); b.disabled = true;
  try { const r = await _modalOk(new FormData($("#modal-form")), $("#modal-corpo")); if (r !== false) fecharModal(); }
  catch (e) { $("#modal-erro").textContent = e.message; }
  finally { b.disabled = false; }
});
$("#modal-fechar").onclick = $("#modal-cancelar").onclick = fecharModal;

function gaveta(tituloHtml, corpoHtml) {
  $("#gav-titulo").innerHTML = tituloHtml;
  $("#gav-corpo").innerHTML = corpoHtml;
  $("#gaveta").classList.add("aberta"); $("#veu").classList.add("ativo");
  return $("#gav-corpo");
}
function fecharGaveta() { $("#gaveta").classList.remove("aberta"); $("#veu").classList.remove("ativo"); }
$("#gav-fechar").onclick = $("#veu").onclick = fecharGaveta;
document.addEventListener("keydown", e => { if (e.key === "Escape") { fecharModal(); fecharGaveta(); } });

// confirmação dentro da página (sem diálogo do navegador)
function confirmar(texto, rotulo = "Confirmar") {
  return new Promise(res => {
    modal("Confirmar", `<p style="margin:0">${texto}</p>`, () => { res(true); }, {rotulo});
    const cancelar = () => { res(false); fecharModal(); };
    $("#modal-cancelar").onclick = cancelar; $("#modal-fechar").onclick = cancelar;
  }).finally(() => { $("#modal-cancelar").onclick = $("#modal-fechar").onclick = fecharModal; });
}

// confirmação de senha para ações sensíveis: janela própria, por cima de qualquer outra
function pedirConfirmacao(pedirCodigo, texto) {
  return new Promise(res => {
    const caixa = $("#reauth"), f = $("#reauth-form");
    f.reset(); $("#reauth-erro").textContent = "";
    $("#reauth-codigo").hidden = !pedirCodigo;
    $("#reauth-codigo input").required = !!pedirCodigo;
    if (texto) $("#reauth-texto").textContent = texto;
    caixa.classList.add("ativo");
    setTimeout(() => $("#reauth-form input[name=senha]").focus(), 30);
    const fim = ok => { caixa.classList.remove("ativo"); f.onsubmit = null; res(ok); };
    $("#reauth-cancelar").onclick = () => fim(false);
    f.onsubmit = async ev => {
      ev.preventDefault();
      const d = Object.fromEntries(new FormData(f));
      try { await api("/api/eu/confirmar", {metodo: "POST", corpo: {senha: d.senha, codigo: d.codigo || null}, _repetida: true}); fim(true); }
      catch (e) { $("#reauth-erro").textContent = e.message; }
    };
  });
}

// fim da sessão por inatividade (o servidor também encerra; aqui a tela avisa na hora)
let _ultimoUso = Date.now();
["click", "keydown", "mousemove", "touchstart", "scroll"].forEach(ev => addEventListener(ev, () => { _ultimoUso = Date.now(); }, {passive: true}));
setInterval(async () => {
  if (!EU || !EU.inatividade_min) return;
  if (Date.now() - _ultimoUso > EU.inatividade_min * 60000) {
    EU = null;
    try { await api("/api/logout", {metodo: "POST"}); } catch {}
    fecharModal(); fecharGaveta(); mostrarEntrada(true);
    $("#erro-login").textContent = "Sessão encerrada por inatividade. Entre de novo.";
  }
}, 30000);

// ------------------------------------------------------------------ cadastros em memória
async function carregarCadastros(forcar = false) {
  if (forcar) Object.keys(CAD).forEach(k => CAD[k] = null);
  const [cats, ccs, contas] = await Promise.all([
    CAD.categorias ?? api(E("/categorias")), CAD.centros ?? api(E("/centros-custo")), CAD.contas ?? api(E("/contas"))]);
  Object.assign(CAD, {categorias: cats, centros: ccs, contas});
}
async function contatos() {
  if (!CAD.contatos) CAD.contatos = (await api(E("/contatos?" + qs({ativos: true, por_pagina: 2000})))).itens;
  return CAD.contatos;
}
function catPorId(id) {
  for (const g of CAD.categorias || []) { if (g.id === id) return g; for (const c of g.categorias) if (c.id === id) return c; }
  return null;
}
function optCategorias(tipo, sel, {vazio = "— sem categoria —"} = {}) {
  // recebimento: receitas e movimentações; pagamento: despesas e movimentações
  const ok = g => !tipo || g.natureza === "neutra" || (tipo === "receber" ? g.natureza === "receita" : g.natureza === "despesa");
  return `<option value="">${vazio}</option>` + (CAD.categorias || []).filter(ok).map(g =>
    `<optgroup label="${esc(g.codigo + " " + g.nome)}">${g.categorias.filter(c => c.ativo || c.id === sel).map(c =>
      `<option value="${c.id}" ${c.id === sel ? "selected" : ""}>${esc(c.codigo + " " + c.nome)}</option>`).join("")}</optgroup>`).join("");
}
const optCentros = (sel, vazio = "— nenhum —") => `<option value="">${vazio}</option>` + (CAD.centros || [])
  .filter(c => c.ativo || c.id === sel).map(c => `<option value="${c.id}" ${c.id === sel ? "selected" : ""}>${esc(c.codigo + " " + c.nome)}</option>`).join("");
const optContas = (sel, vazio = "— escolha —", soAtivas = true) => `<option value="">${vazio}</option>` + (CAD.contas || [])
  .filter(c => !soAtivas || c.ativo || c.id === sel).map(c => `<option value="${c.id}" ${c.id === sel ? "selected" : ""}>${esc(c.nome)}</option>`).join("");

// campo de cliente/fornecedor: digita o nome; se não existir, é criado ao salvar
function campoContato(nome = "contato", atual = "", tipo = "fornecedor") {
  return `<input type="text" name="${nome}" list="lista-contatos" value="${esc(atual)}" autocomplete="off" data-tipo-contato="${tipo}" placeholder="Digite o nome">
    <datalist id="lista-contatos">${(CAD.contatos || []).map(c => `<option value="${esc(c.nome)}">`).join("")}</datalist>`;
}
async function resolverContato(nome, tipo, documento = null) {
  nome = (nome || "").trim();
  if (!nome) return null;
  const lista = await contatos();
  const achado = lista.find(c => c.nome.toLowerCase() === nome.toLowerCase()) || (documento && lista.find(c => c.documento === documento));
  if (achado) return achado.id;
  let novo;
  try { novo = await api(E("/contatos"), {metodo: "POST", corpo: {nome, tipo, documento}}); }
  catch (e) {                              // CPF/CNPJ do extrato inválido ou já usado: cria só com o nome
    if (!documento) throw e;
    novo = await api(E("/contatos"), {metodo: "POST", corpo: {nome, tipo}});
  }
  CAD.contatos.push(novo);
  toast(`Cadastro criado: ${nome}`);
  return novo.id;
}

// ------------------------------------------------------------------ gráficos (Chart.js) no tema do ERP
const COR = {marca: "#44E26B", deb: "#FF7A6B", azul: "#6CB6FF", amarelo: "#F5B941", tinta3: "#8A928E", linha: "#222725",
             paleta: ["#44E26B", "#6CB6FF", "#F5B941", "#FF7A6B", "#B794F6", "#4FD1C5", "#F687B3", "#A0AEC0", "#68D391", "#F6AD55"]};
if (window.Chart) {
  Chart.defaults.color = COR.tinta3;
  Chart.defaults.font.family = "Montserrat, 'Segoe UI', sans-serif";
  Chart.defaults.borderColor = COR.linha;
  Chart.defaults.plugins.tooltip.callbacks.label = c => ` ${c.dataset.label || c.label}: ${brl(c.parsed.y ?? c.parsed)}`;
}
const _graficos = {};
function grafico(id, cfg) {
  _graficos[id]?.destroy();
  const el = document.getElementById(id);
  if (!el || !window.Chart) return null;
  cfg.options = Object.assign({responsive: true, maintainAspectRatio: false, interaction: {mode: "index", intersect: false},
    plugins: {legend: {labels: {usePointStyle: true, boxWidth: 8}}}}, cfg.options || {});
  _graficos[id] = new Chart(el, cfg);
  return _graficos[id];
}
const eixoReais = {ticks: {callback: v => Math.abs(v) >= 1000 ? (v / 1000).toLocaleString("pt-BR") + " mil" : v}};

// ------------------------------------------------------------------ navegação
const TELAS = {};             // cada arquivo de telas registra as suas: TELAS.nome = async (main, param) => {}
let telaAtual = "painel";
async function ir(tela, param) {
  if (!TELAS[tela]) tela = "painel";
  telaAtual = tela;
  const h = "#" + tela + (param ? "/" + param : "");
  if (location.hash !== h) history.replaceState(null, "", h);
  $$("nav button[data-tela]").forEach(b => b.setAttribute("aria-current", b.dataset.tela === tela ? "page" : "false"));
  fecharGaveta();
  // cada navegação desenha numa área nova: uma tela que ainda está carregando não sobrescreve a seguinte
  const main = document.createElement("section");
  main.className = "tela-area";
  main.innerHTML = `<div class="carregando">Carregando…</div>`;
  $("#tela").replaceChildren(main);
  try { await carregarCadastros(); await TELAS[tela](main, param); }
  catch (e) { if (main.isConnected) main.innerHTML = `<div class="aviso-empresa">${esc(e.message)}</div>`; }
}
$$("nav button[data-tela]").forEach(b => b.onclick = () => ir(b.dataset.tela));
window.addEventListener("hashchange", () => { if (!EU) return; const [t, p] = location.hash.slice(1).split("/"); if (t !== telaAtual || p) ir(t, p); });

// ------------------------------------------------------------------ sessão
function mostrarEntrada(login, etapa2fa = false) {
  $("#app").hidden = true; $("#entrada").hidden = false;
  $("#form-login").hidden = !login || etapa2fa; $("#form-setup").hidden = login; $("#form-2fa").hidden = !etapa2fa;
  $$("#entrada .erro-campo").forEach(e => e.textContent = "");
  setTimeout(() => $(etapa2fa ? "#login-2fa input" : login ? "#login input" : "#setup input")?.focus(), 30);
}
function entrar(eu) {
  EU = eu;
  if (!eu.empresas.length) { $("#tela").innerHTML = ""; toast("Seu usuário não tem acesso a nenhuma empresa.", true); return; }
  let salvo = null; try { salvo = +localStorage.getItem("fp-empresa"); } catch {}
  const emp = eu.empresas.find(e => e.id === salvo) || eu.empresas[0];
  EMP = emp.id; PAPEL = emp.papel;
  $("#empresa").innerHTML = eu.empresas.map(e => `<option value="${e.id}" ${e.id === EMP ? "selected" : ""}>${esc(e.nome)}</option>`).join("") +
    (eu.admin_sistema ? `<option value="nova">+ Nova empresa…</option>` : "");
  $("#usuario-nome").textContent = eu.nome;
  $("#entrada").hidden = true; $("#app").hidden = false;
  document.title = `FinancePro ERP | ${emp.nome}`;
  const [t, p] = location.hash.slice(1).split("/");
  ir(t || "painel", p);
}
$("#empresa").addEventListener("change", e => {
  if (e.target.value === "nova") { e.target.value = EMP; return novaEmpresa(); }
  EMP = +e.target.value; PAPEL = EU.empresas.find(x => x.id === EMP).papel;
  try { localStorage.setItem("fp-empresa", EMP); } catch {}
  document.title = `FinancePro ERP | ${EU.empresas.find(x => x.id === EMP).nome}`;
  carregarCadastros(true).then(() => ir(telaAtual));
});
function novaEmpresa() {
  modal("Nova empresa", `<div class="grade-form"><label class="campo largo">Nome<input type="text" name="nome" required></label>
    <label class="campo">CNPJ<input type="text" name="cnpj"></label><label class="campo">Razão social<input type="text" name="razao_social"></label></div>
    <p class="dica-campo">A empresa já começa com o plano de contas e os centros de custo padrão, que você pode editar em Cadastros.</p>`,
    async f => {
      const e = await api("/api/empresas", {metodo: "POST", corpo: Object.fromEntries(f)});
      try { localStorage.setItem("fp-empresa", e.id); } catch {}
      entrar(await api("/api/eu")); toast(`Empresa ${e.nome} criada.`);
    }, {rotulo: "Criar empresa"});
}
$("#setup").addEventListener("submit", async ev => {
  ev.preventDefault();
  try { entrar(await api("/api/setup", {metodo: "POST", corpo: Object.fromEntries(new FormData(ev.target))})); }
  catch (e) { $("#erro-setup").textContent = e.message; }
});
$("#login").addEventListener("submit", async ev => {
  ev.preventDefault();
  const b = $("#login button"); b.disabled = true;
  try {
    const r = await api("/api/login", {metodo: "POST", corpo: Object.fromEntries(new FormData(ev.target))});
    if (r.etapa === "2fa") { mostrarEntrada(true, true); return; }
    ev.target.reset(); entrar(r);
  } catch (e) { $("#erro-login").textContent = e.message; }
  finally { b.disabled = false; }
});
$("#login-2fa").addEventListener("submit", async ev => {
  ev.preventDefault();
  try { const r = await api("/api/login/2fa", {metodo: "POST", corpo: Object.fromEntries(new FormData(ev.target))}); ev.target.reset(); $("#login").reset(); entrar(r); }
  catch (e) {
    $("#erro-2fa").textContent = e.message;
    if (/acabou/.test(e.message)) setTimeout(() => { mostrarEntrada(true); $("#erro-login").textContent = e.message; }, 1500);
  }
});
$("#voltar-login").onclick = ev => { ev.preventDefault(); mostrarEntrada(true); };
$("#sair").onclick = async ev => {
  ev.preventDefault(); EU = null;
  try { await api("/api/logout", {metodo: "POST"}); } finally { history.replaceState(null, "", location.pathname); $("#tela").replaceChildren(); mostrarEntrada(true); }
};
$("#minha-conta").onclick = ev => { ev.preventDefault(); minhaConta(); };

async function iniciar() {
  const est = await api("/api/estado");
  if (est.usuario) entrar(est.usuario);
  else mostrarEntrada(est.configurado, est.etapa_2fa);
}

// ------------------------------------------------------------------ pequenos componentes
function navMes(ano, mes, aoMudar) {
  const el = document.createElement("div");
  el.className = "mes-nav";
  const pinta = () => el.innerHTML = `<button type="button" aria-label="Mês anterior">‹</button><span>${MESES[mes - 1]} ${ano}</span><button type="button" aria-label="Próximo mês">›</button>`;
  pinta();
  el.addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    mes += b === el.firstElementChild ? -1 : 1;
    if (mes < 1) { mes = 12; ano--; } if (mes > 12) { mes = 1; ano++; }
    pinta(); aoMudar(ano, mes);
  });
  return el;
}
function seg(opcoes, atual, aoMudar) {
  const el = document.createElement("div");
  el.className = "seg";
  el.innerHTML = opcoes.map(([v, t]) => `<button type="button" data-v="${v}" aria-pressed="${v === atual}">${t}</button>`).join("");
  el.addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    $$("button", el).forEach(x => x.setAttribute("aria-pressed", x === b)); aoMudar(b.dataset.v);
  });
  return el;
}
const selo = (s, txt) => `<span class="selo ${esc(s)}">${esc(txt ?? ROTULO_SIT[s] ?? s)}</span>`;
function baixarArquivo(url) {           // Excel: o navegador baixa pelo link (sessão vai no cookie)
  const a = document.createElement("a"); a.href = url; a.download = ""; document.body.append(a); a.click(); a.remove();
}
