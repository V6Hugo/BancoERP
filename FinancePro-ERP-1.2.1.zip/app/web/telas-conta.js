/* Minha conta (senha, verificação em duas etapas, sessões) e Cadastros › Segurança (administrador). */
"use strict";

const NAV_CURTO = ua => {
  if (!ua) return "Navegador";
  const nav = /Edg\//.test(ua) ? "Edge" : /OPR\//.test(ua) ? "Opera" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Navegador";
  const so = /Windows/.test(ua) ? "Windows" : /Android/.test(ua) ? "Android" : /iPhone|iPad/.test(ua) ? "iPhone/iPad" : /Mac OS/.test(ua) ? "Mac" : /Linux/.test(ua) ? "Linux" : "";
  return so ? `${nav} no ${so}` : nav;
};
const quando = d => d ? new Date(d).toLocaleString("pt-BR", {dateStyle: "short", timeStyle: "short"}) : "—";

// ================================================================== minha conta

async function minhaConta() {
  const [eu, sessoes] = await Promise.all([api("/api/eu"), api("/api/eu/sessoes")]);
  EU = {...EU, ...eu};
  const corpo = modal("Minha conta", `
    <section class="conta-sec"><h3>Verificação em duas etapas</h3>
      ${eu.totp_ativo ? `<p>${selo("pago", "Ligada")} Ao entrar, além da senha, o sistema pede o código do aplicativo no celular.
          Restam <b>${eu.codigos_restantes}</b> código(s) de recuperação.</p>
        <div class="linha-acoes"><button type="button" class="btn" id="c-codigos">Gerar novos códigos de recuperação</button>
          <button type="button" class="btn perigo" id="c-desligar">Desligar</button></div>`
      : `<p>${selo("vencido", "Desligada")} Com ela, quem descobrir a sua senha ainda não consegue entrar: falta o código que só o seu celular gera.
          <b>Recomendado para quem mexe com bancos.</b></p>
        <button type="button" class="btn primario" id="c-ligar">Ligar a verificação em duas etapas</button>`}
    </section>
    <section class="conta-sec"><h3>Senha</h3>
      <div class="grade-form">
        <label class="campo largo">Senha atual<input type="password" id="c-atual" autocomplete="current-password"></label>
        <label class="campo">Nova senha<input type="password" id="c-nova" autocomplete="new-password" minlength="10"></label>
        <label class="campo">Repita a nova senha<input type="password" id="c-nova2" autocomplete="new-password"></label></div>
      <p class="dica-campo">Pelo menos 10 caracteres, com letras e números. Uma frase longa é melhor que uma senha curta cheia de símbolos.
        Trocar a senha encerra as outras sessões abertas.</p>
      <button type="button" class="btn" id="c-senha">Trocar senha</button>
    </section>
    <section class="conta-sec"><h3>Onde você está conectado</h3>
      <div class="tabela-wrap"><table><tbody>${sessoes.map(x => `<tr><td>${esc(NAV_CURTO(x.navegador))}${x.atual ? ` ${selo("pago", "esta")}` : ""}
          <span class="sublinha">${esc(x.ip || "")} · entrou ${quando(x.criada_em)}</span></td><td class="num fraco">usado ${quando(x.ultimo_uso)}</td></tr>`).join("")}</tbody></table></div>
      ${sessoes.length > 1 ? `<button type="button" class="btn" id="c-outras" style="margin-top:10px">Encerrar as outras ${sessoes.length - 1} sessão(ões)</button>` : ""}
      <p class="dica-campo">Sem uso por ${eu.inatividade_min} minutos, a sessão termina sozinha.</p>
    </section>`, null);
  $("#c-ligar", corpo) && ($("#c-ligar", corpo).onclick = tentar(ligar2fa));
  $("#c-desligar", corpo) && ($("#c-desligar", corpo).onclick = tentar(async () => {
    if (!await confirmar("Desligar a verificação em duas etapas? A conta passa a depender só da senha.", "Desligar")) return minhaConta();
    await api("/api/eu/2fa/desligar", {metodo: "POST"}); toast("Verificação em duas etapas desligada."); minhaConta();
  }));
  $("#c-codigos", corpo) && ($("#c-codigos", corpo).onclick = tentar(async () => {
    const r = await api("/api/eu/2fa/novos-codigos", {metodo: "POST"}); mostrarCodigos(r.codigos_recuperacao, true);
  }));
  $("#c-senha", corpo).onclick = tentar(async () => {
    const atual = $("#c-atual").value, nova = $("#c-nova").value;
    if (!atual || !nova) throw new Error("Preencha a senha atual e a nova.");
    if (nova !== $("#c-nova2").value) throw new Error("A nova senha e a repetição não são iguais.");
    const r = await api("/api/eu/senha", {metodo: "POST", corpo: {atual, nova}});
    toast(`Senha alterada.${r.sessoes_encerradas ? ` ${r.sessoes_encerradas} outra(s) sessão(ões) encerrada(s).` : ""}`); minhaConta();
  });
  $("#c-outras", corpo) && ($("#c-outras", corpo).onclick = tentar(async () => {
    const r = await api("/api/eu/sessoes/encerrar-outras", {metodo: "POST"}); toast(`${r.encerradas} sessão(ões) encerrada(s).`); minhaConta();
  }));
}

async function ligar2fa() {
  const r = await api("/api/eu/2fa/iniciar", {metodo: "POST"});
  const corpo = modal("Ligar a verificação em duas etapas", `
    <ol class="passos-of">
      <li>Instale no celular um aplicativo autenticador: <b>Google Authenticator</b>, <b>Microsoft Authenticator</b> ou <b>Authy</b> (gratuitos).</li>
      <li>No aplicativo, toque em <b>+</b> e leia o QR code abaixo.</li>
      <li>Digite o código de 6 números que aparecer.</li></ol>
    <div class="qr-2fa"><div class="qr">${r.qr_svg}</div>
      <div><p class="dica-campo" style="margin-top:0">Não consegue ler? Digite esta chave no aplicativo:</p><code class="chave-2fa">${esc(r.segredo)}</code></div></div>
    <div class="grade-form" style="margin-top:14px"><label class="campo">Código do aplicativo<input type="text" name="codigo" required inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000"></label></div>`,
    async f => {
      const res = await api("/api/eu/2fa/ativar", {metodo: "POST", corpo: {codigo: f.get("codigo")}});
      EU.totp_ativo = true;
      setTimeout(() => mostrarCodigos(res.codigos_recuperacao, false), 0);
    }, {rotulo: "Confirmar e ligar"});
  // o QR vem do próprio servidor (SVG gerado por nós); tira qualquer script por garantia
  $$("script", corpo).forEach(x => x.remove());
}

function mostrarCodigos(codigos, novos) {
  const texto = `FinancePro ERP - códigos de recuperação (${EU.email})\nCada código vale uma vez.\n\n${codigos.join("\n")}\n`;
  const corpo = modal(novos ? "Novos códigos de recuperação" : "Verificação em duas etapas ligada", `
    <p style="margin-top:0">${novos ? "Os códigos antigos deixaram de valer." : "Pronto. A partir do próximo login o sistema pede o código do celular."}
      Guarde estes <b>códigos de recuperação</b> em lugar seguro (impressos ou num cofre de senhas).
      Se perder o celular, cada um deles permite entrar uma vez.</p>
    <div class="codigos-rec">${codigos.map(c => `<code>${esc(c)}</code>`).join("")}</div>
    <div class="linha-acoes" style="margin-top:12px"><button type="button" class="btn" id="cod-copiar">Copiar</button>
      <button type="button" class="btn" id="cod-baixar">Baixar .txt</button></div>
    <p class="dica-campo">Eles não aparecem de novo. Se perder, gere novos em Minha conta.</p>`, () => {}, {rotulo: "Já guardei"});
  $("#cod-copiar", corpo).onclick = tentar(async () => { await navigator.clipboard.writeText(texto); toast("Códigos copiados."); });
  $("#cod-baixar", corpo).onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([texto], {type: "text/plain"})); a.download = "financepro-codigos-recuperacao.txt";
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  $("#modal-cancelar").hidden = true;          // só sai pelo "Já guardei"
}

// ================================================================== Cadastros › Segurança

const EVENTO = {
  login: "Entrou", logout: "Saiu", login_falhou: "Senha errada", login_bloqueado: "Bloqueado por tentativas",
  primeiro_acesso: "Primeiro acesso", senha_trocada: "Trocou a senha", senha_confirmada: "Confirmou a senha",
  "2fa_ligada": "Ligou a verificação em 2 etapas", "2fa_desligada": "Desligou a verificação em 2 etapas",
  "2fa_falhou": "Código de 2 etapas errado", "2fa_codigo_recuperacao": "Usou código de recuperação",
  "2fa_novos_codigos": "Gerou novos códigos de recuperação", sessoes_encerradas: "Encerrou outras sessões",
  vincular: "Deu ou alterou acesso", desvincular: "Tirou acesso", encerrar_sessoes: "Encerrou sessões de usuário",
  redefinir_2fa: "Redefiniu 2 etapas de usuário", bloquear: "Bloqueou usuário", desbloquear: "Desbloqueou usuário",
  configurar_inter: "Configurou API do Inter", remover_inter: "Desligou API do Inter",
  configurar_open_finance: "Configurou Open Finance", remover_open_finance: "Removeu Open Finance",
  ligar_open_finance: "Conectou conta pelo Open Finance", desligar_open_finance: "Desconectou conta do Open Finance",
  desfazer: "Desfez importação/ação", exportar: "Exportou para Excel"};
const ALERTA = new Set(["login_falhou", "login_bloqueado", "2fa_falhou", "2fa_desligada", "redefinir_2fa", "2fa_codigo_recuperacao"]);

async function cadSeguranca(el) {
  const [dados, us] = await Promise.all([api(E("/seguranca")), api(E("/usuarios"))]);
  const c = dados.config, semDois = us.filter(u => u.ativo && !u.totp_ativo);
  const item = (ok, titulo, texto) => `<li class="${ok ? "ok" : "falta"}"><b>${ok ? "✓" : "!"}</b><div><strong>${titulo}</strong><span>${texto}</span></div></li>`;
  let filtro = "todos";
  el.innerHTML = `
    <ul class="checklist">
      ${item(c.somente_este_computador, "Acesso só neste computador", c.somente_este_computador ? "Outros aparelhos da rede não chegam à tela de login." : "O sistema aceita acesso pela rede. Use só com HTTPS e firewall (veja SEGURANCA.md).")}
      ${item(!semDois.length, "Verificação em duas etapas", semDois.length ? `${semDois.length} usuário(s) ainda sem: ${esc(semDois.map(u => u.nome).join(", "))}.` : "Todos os usuários desta empresa usam.")}
      ${item(c.chave_ok && !c.troca_de_chave_pendente, "Chave secreta", c.troca_de_chave_pendente ? "Troca de chave concluída: apague SECRET_KEY_ANTERIOR do .env." : c.chave_ok ? "Forte e aleatória. Guarde uma cópia do .env fora deste computador." : "Fraca: gere uma nova.")}
      ${item(!dados.falhas_24h, "Tentativas de acesso", dados.falhas_24h ? `${dados.falhas_24h} tentativa(s) com erro nas últimas 24 h. Confira abaixo.` : "Nenhum erro de senha nas últimas 24 h.")}
      ${item(true, "Sessões", `Terminam após ${c.inatividade_min} min sem uso e no máximo em ${c.sessao_horas} h. Credenciais de banco pedem a senha de novo.`)}
      ${item(c.https || c.somente_este_computador, "Conexão", c.https ? "HTTPS ligado." : c.somente_este_computador ? "Uso local; HTTPS só é preciso se for acessar pela rede ou internet." : "Sem HTTPS: senhas trafegam abertas na rede.")}
    </ul>
    <h2 style="margin-top:26px">Usuários desta empresa</h2>
    <div class="tabela-wrap"><table><thead><tr><th>Usuário</th><th>Duas etapas</th><th>Sessões abertas</th><th>Último acesso</th><th></th></tr></thead><tbody>
      ${us.map(u => `<tr><td>${esc(u.nome)}<span class="sublinha">${esc(u.email)}${u.ativo ? "" : " · bloqueado"}</span></td>
        <td>${u.totp_ativo ? selo("pago", "Ligada") : selo("vencido", "Desligada")}</td><td>${u.sessoes}</td><td>${quando(u.ultimo_acesso)}</td>
        <td>${u.id === EU.id ? `<span class="sublinha">você · <a href="#" data-minha>Minha conta</a></span>` : `<div class="acoes-linha">
          ${u.sessoes ? `<button class="btn" data-sair="${u.id}">Encerrar sessões</button>` : ""}
          ${EU.admin_sistema && u.totp_ativo ? `<button class="btn" data-r2fa="${u.id}">Redefinir 2 etapas</button>` : ""}
          ${EU.admin_sistema ? `<button class="btn ${u.ativo ? "perigo" : ""}" data-bloq="${u.id}" data-ativo="${u.ativo}">${u.ativo ? "Bloquear" : "Desbloquear"}</button>` : ""}</div>`}</td></tr>`).join("")}
    </tbody></table></div>
    <div class="topo-tela" style="margin:26px 0 10px"><div><h2 style="margin:0">Eventos de segurança</h2><p class="sub" style="margin:2px 0 0">Últimos 60 dias: entradas, erros de senha, mudanças de acesso, credenciais de banco e exportações.</p></div>
      <div id="ev-filtro"></div></div>
    <div class="tabela-wrap" id="eventos"></div>`;
  const desenhar = () => {
    const lista = dados.eventos.filter(e => filtro === "todos" || (filtro === "alertas" ? ALERTA.has(e.acao) : ["login", "logout", "login_falhou", "login_bloqueado", "2fa_falhou"].includes(e.acao)));
    $("#eventos").innerHTML = lista.length ? `<table><thead><tr><th>Quando</th><th>Evento</th><th>Quem</th><th>Endereço</th><th>Detalhe</th></tr></thead><tbody>
      ${lista.map(e => `<tr class="${ALERTA.has(e.acao) ? "ev-alerta" : ""}"><td>${quando(e.quando)}</td><td>${esc(EVENTO[e.acao] || e.acao)}</td>
        <td>${esc(e.usuario || e.email || "—")}</td><td class="fraco">${esc(e.ip || "—")}</td>
        <td class="fraco">${esc(Object.entries(e.detalhe || {}).filter(([k, v]) => v !== null && v !== "" && k !== "navegador").map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : v}`).join(" · ").slice(0, 120))}</td></tr>`).join("")}
      </tbody></table>` : `<div class="vazio">Nenhum evento.</div>`;
  };
  $("#ev-filtro").append(seg([["todos", "Todos"], ["alertas", "Alertas"], ["acessos", "Entradas"]], filtro, v => { filtro = v; desenhar(); }));
  desenhar();
  $("[data-minha]", el) && ($("[data-minha]", el).onclick = e => { e.preventDefault(); minhaConta(); });
  $$("[data-sair]", el).forEach(b => b.onclick = tentar(async () => {
    const u = us.find(x => x.id === +b.dataset.sair);
    if (!await confirmar(`Encerrar todas as sessões de ${esc(u.nome)}? Ele precisará entrar de novo.`, "Encerrar")) return;
    const r = await api(E(`/usuarios/${u.id}/encerrar-sessoes`), {metodo: "POST"}); toast(`${r.encerradas} sessão(ões) encerrada(s).`); cadSeguranca(el);
  }));
  $$("[data-r2fa]", el).forEach(b => b.onclick = tentar(async () => {
    const u = us.find(x => x.id === +b.dataset.r2fa);
    if (!await confirmar(`Redefinir a verificação em duas etapas de ${esc(u.nome)}? Use quando a pessoa perdeu o celular e os códigos. Ela entra só com a senha e deve ligar de novo.`, "Redefinir")) return;
    await api(E(`/usuarios/${u.id}/redefinir-2fa`), {metodo: "POST"}); toast("Verificação redefinida."); cadSeguranca(el);
  }));
  $$("[data-bloq]", el).forEach(b => b.onclick = tentar(async () => {
    const u = us.find(x => x.id === +b.dataset.bloq), ativo = b.dataset.ativo !== "true";
    if (!ativo && !await confirmar(`Bloquear ${esc(u.nome)}? Ele sai na hora e não consegue mais entrar em nenhuma empresa.`, "Bloquear")) return;
    await api(E(`/usuarios/${u.id}/ativo?ativo=${ativo}`), {metodo: "POST"}); toast(ativo ? "Usuário desbloqueado." : "Usuário bloqueado."); cadSeguranca(el);
  }));
}
