/* Relatórios: comparativo entre meses, DRE gerencial e composição, com gráficos interativos e detalhamento. */
"use strict";

const ESTADO_R = {aba: "comparativo", regime: "caixa", meses: null, dimensao: "categoria", tipo: "pagar",
                  dre_ini: null, dre_fim: null, comp_mes: null, comp_dim: "grupo"};

function ultimosMeses(n) {
  const h = new Date(), out = [];
  for (let i = n - 1; i >= 0; i--) { const d = new Date(h.getFullYear(), h.getMonth() - i, 1); out.push(iso(d).slice(0, 7)); }
  return out;
}
const fimMesISO = m => fimDoMes(+m.slice(0, 4), +m.slice(5, 7));

TELAS.relatorios = async (main, param) => {
  if (param && ["comparativo", "dre", "composicao"].includes(param)) ESTADO_R.aba = param;
  ESTADO_R.meses ??= ultimosMeses(3);
  const ult = ultimosMeses(1)[0];
  ESTADO_R.dre_ini ??= ultimosMeses(6)[0]; ESTADO_R.dre_fim ??= ult; ESTADO_R.comp_mes ??= ult;
  main.innerHTML = `<div class="topo-tela"><div><h1>Relatórios</h1>
      <p class="sub">Compare meses, acompanhe o resultado no DRE e veja para onde vai o dinheiro. Clique em barras, fatias e linhas para ver os lançamentos.</p></div>
      <div id="regime"></div></div>
    <div class="abas" role="tablist">
      <button role="tab" data-aba="comparativo">Comparativo entre meses</button>
      <button role="tab" data-aba="dre">DRE gerencial</button>
      <button role="tab" data-aba="composicao">Composição</button></div>
    <div id="rel"></div>`;
  $("#regime").append(seg([["caixa", "Regime de caixa"], ["competencia", "Competência"]], ESTADO_R.regime, v => { ESTADO_R.regime = v; abrir(); }));
  const abrir = tentar(async () => {
    $$(".abas button").forEach(b => b.setAttribute("aria-selected", b.dataset.aba === ESTADO_R.aba));
    history.replaceState(null, "", "#relatorios/" + ESTADO_R.aba);
    await ({comparativo: relComparativo, dre: relDRE, composicao: relComposicao})[ESTADO_R.aba]($("#rel"));
  });
  $$(".abas button").forEach(b => b.onclick = () => { ESTADO_R.aba = b.dataset.aba; abrir(); });
  await abrir();
};

// ------------------------------------------------------------------ comparativo
async function relComparativo(el) {
  const disponiveis = ultimosMeses(18);
  el.innerHTML = `
    <div class="bloco"><div class="barra-filtros" style="margin:0 0 12px">
        <div><span class="dica-campo">Analisar</span><div id="c-tipo"></div></div>
        <div><span class="dica-campo">Agrupar por</span><div id="c-dim"></div></div>
        <button class="btn" id="c-excel" style="margin-left:auto">Excel</button></div>
      <span class="dica-campo">Meses (clique para incluir ou tirar)</span><div class="meses-chips" id="c-meses"></div></div>
    <div class="cartoes" id="c-cart"></div>
    <div class="graficos"><section class="graf-bloco"><h2 id="c-tit-g"></h2><p class="sub">Os 10 maiores itens. Clique numa barra para ver os lançamentos.</p><div class="graf alto"><canvas id="g-comp"></canvas></div></section>
      <section class="graf-bloco"><h2>Total por mês</h2><p class="sub">&nbsp;</p><div class="graf alto"><canvas id="g-comp-tot"></canvas></div></section></div>
    <div class="tabela-wrap"><table class="rel ${ESTADO_R.tipo === "receber" ? "receita-ctx" : ""}" id="c-tab"></table></div>`;
  const chips = () => $("#c-meses").innerHTML = disponiveis.map(m => `<button type="button" data-m="${m}" class="${ESTADO_R.meses.includes(m) ? "sel" : ""}">${mesCurto(m)}</button>`).join("");
  chips();
  $("#c-meses").onclick = e => {
    const b = e.target.closest("button"); if (!b) return;
    const m = b.dataset.m, i = ESTADO_R.meses.indexOf(m);
    if (i >= 0) { if (ESTADO_R.meses.length > 1) ESTADO_R.meses.splice(i, 1); } else ESTADO_R.meses.push(m);
    ESTADO_R.meses.sort(); chips(); carregar();
  };
  $("#c-tipo").append(seg([["pagar", "Despesas"], ["receber", "Receitas"], ["ambos", "Resultado"]], ESTADO_R.tipo, v => { ESTADO_R.tipo = v; relComparativo(el); }));
  $("#c-dim").append(seg([["grupo", "Linha do DRE"], ["categoria", "Categoria"], ["centro_custo", "Centro de custo"], ["contato", "Cliente/fornecedor"]],
                         ESTADO_R.dimensao, v => { ESTADO_R.dimensao = v; carregar(); }));
  const params = () => ({meses: ESTADO_R.meses.join(","), dimensao: ESTADO_R.dimensao, tipo: ESTADO_R.tipo, regime: ESTADO_R.regime});
  $("#c-excel").onclick = () => baixarArquivo(E("/relatorios/comparativo.xlsx?" + qs(params())));
  async function carregar() {
    const c = await api(E("/relatorios/comparativo?" + qs(params())));
    const ms = c.meses, ult = ms[ms.length - 1], pen = ms[ms.length - 2];
    const tot = m => num(c.totais[m]);
    const nomeTipo = {pagar: "Despesas", receber: "Receitas", ambos: "Resultado"}[ESTADO_R.tipo];
    const varTot = pen ? tot(ult) - tot(pen) : null;
    const pct = pen && tot(pen) ? varTot / Math.abs(tot(pen)) * 100 : null;
    const ruim = v => ESTADO_R.tipo === "pagar" ? v > 0 : v < 0;
    $("#c-cart").innerHTML = ms.slice(-4).map(m => `<div class="cartao"><span class="rot">${nomeTipo} · ${mesNome(m)}</span><span class="num-g">${brlSinal(tot(m))}</span></div>`).join("") +
      (pen ? `<div class="cartao ${ruim(varTot) ? "alerta" : "ok"}"><span class="rot">Variação ${mesCurto(pen)} → ${mesCurto(ult)}</span><span class="num-g">${brlSinal(varTot)}</span><small>${pct !== null ? pct.toFixed(1).replace(".", ",") + "%" : ""}</small></div>` : "");
    $("#c-tit-g").textContent = `${nomeTipo} por ${({grupo: "linha do DRE", categoria: "categoria", centro_custo: "centro de custo", contato: "cliente/fornecedor"})[ESTADO_R.dimensao]}`;
    const top = c.linhas.slice(0, 10);
    const g = grafico("g-comp", {type: "bar", data: {labels: top.map(l => l.nome.length > 28 ? l.nome.slice(0, 27) + "…" : l.nome),
        datasets: ms.map((m, i) => ({label: mesCurto(m), data: top.map(l => num(l.valores[m])), backgroundColor: COR.paleta[(i + ms.length * 0) % COR.paleta.length], borderRadius: 3}))},
      options: {indexAxis: "y", scales: {x: eixoReais}, onClick: (ev, els) => {
        if (!els.length) return; const l = top[els[0].index], m = ms[els[0].datasetIndex];
        abrirDetalheRelatorio(`${l.nome} · ${mesNome(m)}`, {inicio: m + "-01", fim: fimMesISO(m), regime: ESTADO_R.regime, chave: l.chave,
          dimensao: ESTADO_R.dimensao, tipo: ESTADO_R.tipo === "ambos" ? null : ESTADO_R.tipo});
      }}});
    grafico("g-comp-tot", {type: "bar", data: {labels: ms.map(mesCurto), datasets: [{label: nomeTipo, data: ms.map(tot),
        backgroundColor: ms.map(m => tot(m) < 0 ? COR.deb : ESTADO_R.tipo === "pagar" ? COR.deb : COR.marca), borderRadius: 4}]},
      options: {plugins: {legend: {display: false}}, scales: {y: eixoReais}}});
    const cel = (l, m, i) => {
      const v = num(l.valores[m]);
      if (!i) return `<td class="num">${v ? brlSinal(v) : "—"}</td>`;
      const x = l.variacao[m], a = num(x?.abs);
      const cls = a === 0 ? "" : (ESTADO_R.tipo === "pagar" ? (a > 0 ? "var-pos" : "var-neg") : (a > 0 ? "var-neg" : "var-pos"));
      return `<td class="num">${v ? brlSinal(v) : "—"}</td><td class="num pct ${cls}">${a ? (a > 0 ? "▲ " : "▼ ") + (x.pct !== null ? String(Math.abs(num(x.pct))).replace(".", ",") + "%" : "novo") : ""}</td>`;
    };
    $("#c-tab").innerHTML = `<thead><tr><th>Item</th>${ms.map((m, i) => `<th class="num">${mesCurto(m)}</th>${i ? `<th class="num">var.</th>` : ""}`).join("")}<th class="num">Total</th></tr></thead>
      <tbody>${c.linhas.map(l => `<tr class="clicavel" data-chave="${esc(l.chave)}"><td>${esc(l.nome)}</td>${ms.map((m, i) => cel(l, m, i)).join("")}<td class="num"><b>${brlSinal(l.total)}</b></td></tr>`).join("")
        || `<tr><td colspan="${ms.length * 2 + 1}" class="vazio">Sem lançamentos nesses meses.</td></tr>`}
      <tr class="subtotal"><td>Total</td>${ms.map((m, i) => `<td class="num">${brlSinal(tot(m))}</td>${i ? "<td></td>" : ""}`).join("")}<td class="num">${brlSinal(ms.reduce((a, m) => a + tot(m), 0))}</td></tr></tbody>`;
    $$("#c-tab tr[data-chave]").forEach(tr => tr.onclick = () => {
      const l = c.linhas.find(x => x.chave === tr.dataset.chave);
      abrirDetalheRelatorio(`${l.nome} · ${mesCurto(ms[0])} a ${mesCurto(ult)}`, {inicio: ms[0] + "-01", fim: fimMesISO(ult), regime: ESTADO_R.regime,
        chave: l.chave, dimensao: ESTADO_R.dimensao, tipo: ESTADO_R.tipo === "ambos" ? null : ESTADO_R.tipo});
    });
    return g;
  }
  await carregar();
}

// ------------------------------------------------------------------ DRE
async function relDRE(el) {
  const opcoes = ultimosMeses(36).reverse();
  el.innerHTML = `<div class="barra-filtros">
      <label class="campo">De<select id="d-ini">${opcoes.map(m => `<option value="${m}" ${m === ESTADO_R.dre_ini ? "selected" : ""}>${mesNome(m)}</option>`).join("")}</select></label>
      <label class="campo">Até<select id="d-fim">${opcoes.map(m => `<option value="${m}" ${m === ESTADO_R.dre_fim ? "selected" : ""}>${mesNome(m)}</option>`).join("")}</select></label>
      <button class="btn" id="d-abrir">Abrir tudo</button><button class="btn" id="d-excel">Excel</button></div>
    <section class="graf-bloco"><h2>Receita e resultado</h2><div class="graf"><canvas id="g-dre"></canvas></div></section>
    <div class="tabela-wrap"><table class="rel" id="d-tab"></table></div><p class="sub" style="margin-top:12px" id="d-obs"></p>`;
  const p = () => ({inicio: ESTADO_R.dre_ini + "-01", fim: fimMesISO(ESTADO_R.dre_fim), regime: ESTADO_R.regime});
  $("#d-ini").onchange = e => { ESTADO_R.dre_ini = e.target.value; carregar(); };
  $("#d-fim").onchange = e => { ESTADO_R.dre_fim = e.target.value; carregar(); };
  $("#d-excel").onclick = () => baixarArquivo(E("/relatorios/dre.xlsx?" + qs(p())));
  $("#d-abrir").onclick = () => { const abre = !$$("#d-tab tr.grupo.aberto").length; $$("#d-tab tr.grupo").forEach(g => g.classList.toggle("aberto", abre));
    $$("#d-tab tr.item").forEach(i => i.classList.toggle("ver", abre)); };
  async function carregar() {
    if (ESTADO_R.dre_ini > ESTADO_R.dre_fim) return toast("O mês inicial é depois do final.", true);
    const d = await api(E("/relatorios/dre?" + qs(p())));
    const ms = d.meses, mostra = v => num(v) ? brlSinal(v) : "—";
    let gi = 0, html = `<thead><tr><th>Conta</th>${ms.map(m => `<th class="num">${mesCurto(m)}</th>`).join("")}<th class="num">Total</th><th class="num">% rec.</th></tr></thead><tbody>`;
    const rb = num(d.linhas.find(x => x.grupo === "receita_bruta")?.total);
    for (const x of d.linhas) {
      if (x.tipo === "grupo" && !x.itens.length && !num(x.total)) continue;
      const fora = ["investimentos", "nao_operacional"].includes(x.grupo);
      const pc = rb && !fora ? (num(x.total) / rb * 100).toFixed(1).replace(".", ",") + "%" : "";
      if (x.tipo === "subtotal") {
        html += `<tr class="subtotal"><td>${esc(x.nome)}</td>${ms.map(m => `<td class="num ${num(x.valores[m]) < 0 ? "neg" : ""}">${mostra(x.valores[m])}</td>`).join("")}<td class="num">${mostra(x.total)}</td><td class="num pct">${pc}</td></tr>`;
        continue;
      }
      gi++;
      html += `<tr class="grupo" data-g="${gi}"><td>${esc(x.nome)}</td>${ms.map(m => `<td class="num">${mostra(x.valores[m])}</td>`).join("")}<td class="num">${mostra(x.total)}</td><td class="num pct">${pc}</td></tr>`;
      html += x.itens.map(it => `<tr class="item clicavel" data-g="${gi}" data-chave="${esc(it.chave)}"><td class="recuo">${esc(it.nome)}</td>${ms.map(m =>
        `<td class="num" data-m="${m}">${mostra(it.valores[m])}</td>`).join("")}<td class="num">${mostra(it.total)}</td><td class="num pct">${rb ? (num(it.total) / rb * 100).toFixed(1).replace(".", ",") + "%" : ""}</td></tr>`).join("");
    }
    html += `<tr><td class="pct">Margem líquida</td>${ms.map(m => `<td class="num pct">${d.margem_liquida[m] !== null ? String(d.margem_liquida[m]).replace(".", ",") + "%" : "—"}</td>`).join("")}<td></td><td></td></tr></tbody>`;
    $("#d-tab").innerHTML = html;
    $$("#d-tab tr.grupo").forEach(tr => tr.onclick = () => {
      tr.classList.toggle("aberto"); $$(`#d-tab tr.item[data-g="${tr.dataset.g}"]`).forEach(i => i.classList.toggle("ver", tr.classList.contains("aberto")));
    });
    $$("#d-tab tr.item").forEach(tr => tr.onclick = e => {
      const m = e.target.closest("td")?.dataset.m;
      abrirDetalheRelatorio(tr.cells[0].textContent + (m ? " · " + mesNome(m) : ""), {inicio: m ? m + "-01" : ms[0] + "-01",
        fim: m ? fimMesISO(m) : fimMesISO(ms[ms.length - 1]), regime: ESTADO_R.regime, chave: tr.dataset.chave});
    });
    const linha = n => d.linhas.find(x => x.nome === n);
    grafico("g-dre", {type: "bar", data: {labels: ms.map(mesCurto), datasets: [
        {label: "Receita bruta", data: ms.map(m => num(d.linhas.find(x => x.grupo === "receita_bruta").valores[m])), backgroundColor: "rgba(68,226,107,.35)", borderRadius: 4},
        {label: "Resultado líquido", data: ms.map(m => num(linha("Resultado líquido").valores[m])), backgroundColor: ms.map(m => num(linha("Resultado líquido").valores[m]) < 0 ? COR.deb : COR.marca), borderRadius: 4},
        {label: "Resultado operacional", type: "line", data: ms.map(m => num(linha("Resultado operacional (EBITDA)").valores[m])), borderColor: COR.azul, backgroundColor: COR.azul, tension: .3}]},
      options: {scales: {y: eixoReais}}});
    $("#d-obs").textContent = ESTADO_R.regime === "caixa" ? "Regime de caixa: valores pela data em que foram pagos ou recebidos. Juros e descontos das baixas entram nas linhas financeiras."
      : "Regime de competência: valores pelo mês de competência de cada lançamento, pagos ou não.";
  }
  await carregar();
}

// ------------------------------------------------------------------ composição
async function relComposicao(el) {
  const opcoes = ultimosMeses(24).reverse();
  el.innerHTML = `<div class="barra-filtros">
      <label class="campo">Mês<select id="p-mes">${opcoes.map(m => `<option value="${m}" ${m === ESTADO_R.comp_mes ? "selected" : ""}>${mesNome(m)}</option>`).join("")}</select></label>
      <div><span class="dica-campo">Agrupar por</span><div id="p-dim"></div></div></div>
    <div class="grade-2"><section class="graf-bloco"><h2>Para onde foi o dinheiro</h2><p class="sub" id="p-sub-d"></p><div class="graf alto"><canvas id="g-pd"></canvas></div></section>
      <section class="graf-bloco"><h2>De onde veio</h2><p class="sub" id="p-sub-r"></p><div class="graf alto"><canvas id="g-pr"></canvas></div></section></div>`;
  $("#p-mes").onchange = e => { ESTADO_R.comp_mes = e.target.value; carregar(); };
  $("#p-dim").append(seg([["grupo", "Linha do DRE"], ["categoria", "Categoria"], ["centro_custo", "Centro de custo"], ["contato", "Cliente/fornecedor"]],
                         ESTADO_R.comp_dim, v => { ESTADO_R.comp_dim = v; carregar(); }));
  async function pizza(id, tipo, sub) {
    const m = ESTADO_R.comp_mes;
    const c = await api(E("/relatorios/comparativo?" + qs({meses: m, dimensao: ESTADO_R.comp_dim, tipo, regime: ESTADO_R.regime})));
    const ls = c.linhas.filter(l => num(l.valores[m]) > 0);
    const top = ls.slice(0, 9), resto = ls.slice(9).reduce((a, l) => a + num(l.valores[m]), 0);
    const total = ls.reduce((a, l) => a + num(l.valores[m]), 0);
    $(sub).textContent = total ? `${brl(total)} em ${mesNome(m)}` : `Nada em ${mesNome(m)}.`;
    grafico(id, {type: "doughnut", data: {labels: [...top.map(l => l.nome), ...(resto ? ["Outros"] : [])],
        datasets: [{data: [...top.map(l => num(l.valores[m])), ...(resto ? [resto] : [])], backgroundColor: COR.paleta, borderColor: "#0E100F", borderWidth: 2}]},
      options: {cutout: "58%", interaction: {mode: "nearest"}, plugins: {legend: {position: "right", labels: {boxWidth: 10, font: {size: 11.5}}},
        tooltip: {callbacks: {label: x => ` ${x.label}: ${brl(x.parsed)} (${(x.parsed / total * 100).toFixed(1).replace(".", ",")}%)`}}},
        onClick: (ev, els) => {
          if (!els.length || els[0].index >= top.length) return; const l = top[els[0].index];
          abrirDetalheRelatorio(`${l.nome} · ${mesNome(m)}`, {inicio: m + "-01", fim: fimMesISO(m), regime: ESTADO_R.regime, chave: l.chave, dimensao: ESTADO_R.comp_dim, tipo});
        }}});
  }
  const carregar = () => Promise.all([pizza("g-pd", "pagar", "#p-sub-d"), pizza("g-pr", "receber", "#p-sub-r")]);
  await carregar();
}
