/* Painel, Recebimentos, Pagamentos e Fluxo de caixa. */
"use strict";

// ================================================================== painel
TELAS.painel = async main => {
  const h = new Date(), a = h.getFullYear(), m = h.getMonth() + 1;
  const ini12 = iso(new Date(a, m - 12, 1)), fimMes = fimDoMes(a, m);
  const [res, serie, saldos, rec, pag] = await Promise.all([
    api(E("/relatorios/resumo?" + qs({inicio: `${a}-${String(m).padStart(2, "0")}-01`, fim: fimMes}))),
    api(E("/relatorios/serie?" + qs({inicio: ini12, fim: fimMes}))),
    api(E("/saldos")),
    api(E("/lancamentos?" + qs({tipo: "receber", situacao: "abertos", fim: iso(new Date(a, m - 1, h.getDate() + 15)), por_pagina: 8}))),
    api(E("/lancamentos?" + qs({tipo: "pagar", situacao: "abertos", fim: iso(new Date(a, m - 1, h.getDate() + 15)), por_pagina: 8}))),
  ]);
  const emp = EU.empresas.find(e => e.id === EMP);
  const linha = l => `<a href="#${l.tipo}/${l.id}"><span class="dt ${l.situacao === "vencido" ? "atrasado" : ""}">${l.vencimento.slice(0, 4) === String(a) ? dataBR(l.vencimento).slice(0, 5) : dataBR(l.vencimento)}</span>
      <span class="tx">${esc(l.contato || l.descricao)}<span class="sublinha">${esc(l.contato ? l.descricao : (l.categoria || ""))}</span></span>
      <span class="num">${brl(l.restante)}</span></a>`;
  main.innerHTML = `
    <div class="topo-tela"><div><h1>${esc(emp.nome)}</h1><p class="sub">${MESES[m - 1]} de ${a}: o que entrou, o que saiu e o que vem pela frente.</p></div></div>
    ${EU.totp_ativo ? "" : `<div class="aviso-seg"><span><b>Proteja o acesso:</b> ligue a verificação em duas etapas. Mesmo que alguém descubra a sua senha, não entra sem o código do seu celular.</span>
      <button class="btn primario" id="ligar-2fa">Ligar agora</button></div>`}
    <div class="cartoes">
      <div class="cartao ok"><span class="rot">Saldo disponível hoje</span><span class="num-g">${brl(res.saldo_disponivel)}</span><small>${saldos.contas.filter(c => c.ativo).length} contas</small></div>
      <div class="cartao"><span class="rot">Entradas no mês</span><span class="num-g c">${brl(res.entradas)}</span><small>saídas ${brl(res.saidas)}</small></div>
      <div class="cartao ${num(res.resultado) < 0 ? "alerta" : "ok"}"><span class="rot">Resultado de caixa no mês</span><span class="num-g">${brlSinal(res.resultado)}</span><small>entradas − saídas</small></div>
      <div class="cartao"><span class="rot">A receber</span><span class="num-g">${brl(res.a_receber)}</span><small class="${num(res.receber_vencido) ? "atrasado" : ""}">${num(res.receber_vencido) ? brl(res.receber_vencido) + " vencidos" : "nada vencido"}</small></div>
      <div class="cartao"><span class="rot">A pagar</span><span class="num-g">${brl(res.a_pagar)}</span><small class="${num(res.pagar_vencido) ? "atrasado" : ""}">${num(res.pagar_vencido) ? brl(res.pagar_vencido) + " vencidos" : "nada vencido"}</small></div>
    </div>
    <div class="graficos">
      <section class="graf-bloco"><h2>Entradas e saídas · últimos 12 meses</h2><p class="sub">Regime de caixa. Clique numa barra para ver os lançamentos do mês.</p><div class="graf"><canvas id="g-serie"></canvas></div></section>
      <section class="graf-bloco"><h2>Atenção</h2><div class="atencao" id="atencao"></div>
        <h2 style="margin-top:20px">Saldo por conta</h2><div class="lista-venc">${saldos.contas.filter(c => c.ativo).map(c =>
          `<a href="#bancos"><span class="banco-ico">${esc(c.banco_codigo || (c.tipo === "caixa" ? "R$" : "•"))}</span><span class="tx">${esc(c.nome)}</span><span class="num ${num(c.saldo) < 0 ? "d" : ""}">${brl(c.saldo)}</span></a>`).join("") || `<p class="sub">Cadastre suas contas em Cadastros.</p>`}</div></section>
    </div>
    <div class="grade-2">
      <section class="bloco"><h2>Próximos recebimentos</h2><div class="lista-venc">${rec.itens.map(linha).join("") || `<p class="sub" style="margin:0">Nada a receber nos próximos 15 dias.</p>`}</div></section>
      <section class="bloco"><h2>Próximos pagamentos</h2><div class="lista-venc">${pag.itens.map(linha).join("") || `<p class="sub" style="margin:0">Nada a pagar nos próximos 15 dias.</p>`}</div></section>
    </div>`;
  $("#ligar-2fa") && ($("#ligar-2fa").onclick = () => minhaConta());
  const at = [];
  if (num(res.pagar_vencido)) at.push(`<button data-ir="pagar/vencidos"><span>Pagamentos vencidos</span><b class="d">${brl(res.pagar_vencido)}</b></button>`);
  if (num(res.receber_vencido)) at.push(`<button data-ir="receber/vencidos"><span>Recebimentos atrasados</span><b class="d">${brl(res.receber_vencido)}</b></button>`);
  if (res.pendentes_conciliar) at.push(`<button data-ir="bancos"><span>Movimentos do banco a conciliar</span><b>${res.pendentes_conciliar}</b></button>`);
  if (num(res.pagar_7d)) at.push(`<button data-ir="pagar"><span>A pagar nos próximos 7 dias</span><b>${brl(res.pagar_7d)}</b></button>`);
  $("#atencao").innerHTML = at.join("") || `<div class="tudo-ok">Tudo em dia: nada vencido e nada a conciliar.</div>`;
  $$("#atencao [data-ir]").forEach(b => b.onclick = () => { const [t, p] = b.dataset.ir.split("/"); ir(t, p); });
  grafico("g-serie", {type: "bar", data: {labels: serie.map(x => mesCurto(x.mes)), datasets: [
      {label: "Entradas", data: serie.map(x => num(x.entradas)), backgroundColor: COR.marca, borderRadius: 4},
      {label: "Saídas", data: serie.map(x => num(x.saidas)), backgroundColor: COR.deb, borderRadius: 4},
      {label: "Resultado", data: serie.map(x => num(x.resultado)), type: "line", borderColor: COR.azul, backgroundColor: COR.azul, tension: .3, pointRadius: 3}]},
    options: {scales: {y: eixoReais}, onClick: (ev, el) => {
      if (!el.length) return; const mes = serie[el[0].index].mes;
      abrirDetalheRelatorio(`Lançamentos de ${mesNome(mes)}`, {inicio: mes + "-01", fim: fimDoMes(+mes.slice(0, 4), +mes.slice(5)),
        tipo: el[0].datasetIndex === 1 ? "pagar" : el[0].datasetIndex === 0 ? "receber" : null});
    }}});
};

// ================================================================== recebimentos e pagamentos
const ESTADO_L = {};
function estadoL(tipo) {
  const h = new Date();
  return ESTADO_L[tipo] ??= {ano: h.getFullYear(), mes: h.getMonth() + 1, situacao: "abertos", busca: "", categoria_id: "",
                             centro_custo_id: "", periodo: "mes", pagina: 0, sel: new Set()};
}

async function telaLancamentos(main, tipo, param) {
  const st = estadoL(tipo);
  const ehRec = tipo === "receber";
  if (param === "vencidos") { st.situacao = "vencidos"; st.periodo = "tudo"; }
  main.innerHTML = `
    <div class="topo-tela"><div><h1>${ehRec ? "Recebimentos" : "Pagamentos"}</h1>
      <p class="sub">${ehRec ? "Contas a receber: vendas, serviços, parcelas de clientes." : "Contas a pagar: fornecedores, impostos, salários, despesas fixas."}</p></div>
      <div class="linha-acoes">${pode() ? `<button class="btn primario" id="novo">${ehRec ? "+ Novo recebimento" : "+ Novo pagamento"}</button>` : ""}
        <button class="btn" id="excel">Excel</button></div></div>
    <div class="barra-filtros">
      <div id="per"></div><div id="sit"></div>
      <label class="campo busca">Buscar<input type="search" id="busca" placeholder="Descrição, ${ehRec ? "cliente" : "fornecedor"} ou documento" value="${esc(st.busca)}"></label>
      <label class="campo">Categoria<select id="f-cat">${optCategorias(tipo, +st.categoria_id || null, {vazio: "Todas"})}</select></label>
      <label class="campo">Centro de custo<select id="f-cc">${optCentros(+st.centro_custo_id || null, "Todos")}</select></label>
    </div>
    <div class="totais" id="totais"></div>
    <div class="tabela-wrap"><table><thead><tr>
      <th class="chk"><input type="checkbox" id="todos" aria-label="Selecionar todos"></th><th>Vencimento</th><th>Descrição</th><th>Categoria</th>
      <th>Centro de custo</th><th class="num">Valor</th><th class="num">${ehRec ? "Recebido" : "Pago"}</th><th>Situação</th></tr></thead>
      <tbody id="corpo"></tbody></table></div>
    <div class="paginacao" id="pag"></div>`;
  const per = $("#per");
  const desenharPeriodo = () => {
    per.innerHTML = "";
    if (st.periodo === "mes") per.append(navMes(st.ano, st.mes, (a, m) => { st.ano = a; st.mes = m; st.pagina = 0; carregar(); }));
    per.append(Object.assign(document.createElement("button"), {className: "btn", style: "margin-left:8px",
      textContent: st.periodo === "mes" ? "Todo o período" : "Por mês", onclick: () => { st.periodo = st.periodo === "mes" ? "tudo" : "mes"; desenharPeriodo(); carregar(); }}));
  };
  desenharPeriodo();
  $("#sit").append(seg([["abertos", "Em aberto"], ["vencidos", "Vencidos"], ["pago", ehRec ? "Recebidos" : "Pagos"], ["todos", "Todos"]], st.situacao,
                       v => { st.situacao = v; st.pagina = 0; carregar(); }));
  let espera;
  $("#busca").oninput = e => { clearTimeout(espera); espera = setTimeout(() => { st.busca = e.target.value; st.pagina = 0; carregar(); }, 300); };
  $("#f-cat").onchange = e => { st.categoria_id = e.target.value; st.pagina = 0; carregar(); };
  $("#f-cc").onchange = e => { st.centro_custo_id = e.target.value; st.pagina = 0; carregar(); };
  $("#novo") && ($("#novo").onclick = () => formLancamento(tipo, null, carregar));
  const filtros = () => {
    const f = {tipo, situacao: st.situacao, busca: st.busca, categoria_id: st.categoria_id, centro_custo_id: st.centro_custo_id};
    if (st.periodo === "mes") {
      f.fim = fimDoMes(st.ano, st.mes);
      // em aberto/vencidos: o mês mostra também o que ficou para trás (vencido em meses anteriores)
      if (!["abertos", "vencidos"].includes(st.situacao)) f.inicio = `${st.ano}-${String(st.mes).padStart(2, "0")}-01`;
      if (st.situacao === "pago") f.data_base = "pagamento";
    }
    return f;
  };
  $("#excel").onclick = () => baixarArquivo(E("/relatorios/lancamentos.xlsx?" + qs(filtros())));
  async function carregar() {
    const r = await api(E("/lancamentos?" + qs({...filtros(), pagina: st.pagina, por_pagina: 100})));
    st.sel.clear();
    $("#totais").innerHTML = `<div>${r.total} lançamentos<b>${brl(r.valor_total)}</b></div>
      <div>${ehRec ? "Recebido" : "Pago"}<b class="${ehRec ? "c" : "d"}">${brl(r.valor_pago)}</b></div>
      <div>Em aberto<b>${brl(r.valor_restante)}</b></div>
      ${st.periodo === "mes" && ["abertos", "vencidos"].includes(st.situacao) ? `<div class="sublinha" style="align-self:center">Até ${dataBR(fimDoMes(st.ano, st.mes))}, incluindo o que ficou de meses anteriores</div>` : ""}
      <div class="acoes">${pode() ? `<button class="btn" id="baixar-sel" disabled>${ehRec ? "Receber" : "Pagar"} selecionados</button>` : ""}</div>`;
    $("#corpo").innerHTML = r.itens.map(l => `<tr class="clicavel" data-id="${l.id}">
        <td class="chk">${["aberto", "parcial", "vencido"].includes(l.situacao) ? `<input type="checkbox" value="${l.id}">` : ""}</td>
        <td class="${l.situacao === "vencido" ? "atrasado" : ""}">${dataBR(l.vencimento)}</td>
        <td class="desc">${esc(l.contato || l.descricao)}<small>${esc(l.contato ? l.descricao : "")}${l.documento ? " · " + esc(l.documento) : ""}</small></td>
        <td>${esc(l.categoria || "—")}</td><td>${esc(l.centro_custo || "—")}</td>
        <td class="num">${brl(l.valor)}</td><td class="num ${num(l.pago) ? (ehRec ? "c" : "d") : ""}">${num(l.pago) ? brl(l.pago) : "—"}</td>
        <td>${selo(l.situacao)}${l.data_pagamento && l.situacao === "pago" ? `<span class="sublinha">em ${dataBR(l.data_pagamento)}</span>` : ""}</td></tr>`).join("")
      || `<tr><td colspan="8" class="vazio">Nenhum ${ehRec ? "recebimento" : "pagamento"} com estes filtros.</td></tr>`;
    const paginas = Math.ceil(r.total / 100);
    $("#pag").innerHTML = paginas > 1 ? `<span>Página ${st.pagina + 1} de ${paginas}</span><span class="linha-acoes">
      <button class="btn" ${st.pagina ? "" : "disabled"} id="ant">Anterior</button><button class="btn" ${st.pagina + 1 < paginas ? "" : "disabled"} id="prox">Próxima</button></span>` : "";
    $("#ant") && ($("#ant").onclick = () => { st.pagina--; carregar(); });
    $("#prox") && ($("#prox").onclick = () => { st.pagina++; carregar(); });
    $$("#corpo tr.clicavel").forEach(tr => tr.onclick = e => { if (!e.target.closest("td.chk")) detalheLancamento(+tr.dataset.id, carregar); });
    const marcar = () => { const n = st.sel.size; const b = $("#baixar-sel"); if (b) { b.disabled = !n; b.textContent = `${ehRec ? "Receber" : "Pagar"} selecionados${n ? ` (${n})` : ""}`; } };
    $$("#corpo input[type=checkbox]").forEach(c => c.onchange = () => { c.checked ? st.sel.add(+c.value) : st.sel.delete(+c.value); marcar(); });
    $("#todos").checked = false;
    $("#todos").onchange = e => { $$("#corpo input[type=checkbox]").forEach(c => { c.checked = e.target.checked; c.onchange(); }); };
    $("#baixar-sel") && ($("#baixar-sel").onclick = () => baixaLote(tipo, [...st.sel], carregar));
  }
  await carregar();
  if (param && /^\d+$/.test(param)) detalheLancamento(+param, carregar);
}
TELAS.receber = (main, p) => telaLancamentos(main, "receber", p);
TELAS.pagar = (main, p) => telaLancamentos(main, "pagar", p);

async function formLancamento(tipo, l, aoSalvar) {
  await contatos();
  const ehRec = tipo === "receber", novo = !l;
  l = l || {vencimento: hojeISO(), conta_bancaria_id: CAD.contas.find(c => c.ativo)?.id};
  modal(novo ? (ehRec ? "Novo recebimento" : "Novo pagamento") : "Editar lançamento", `
    <div class="grade-form">
      <label class="campo largo">Descrição<input type="text" name="descricao" required maxlength="300" value="${esc(l.descricao)}" placeholder="${ehRec ? "Ex.: Consulta, venda NF 123" : "Ex.: Aluguel de outubro, NF 456"}"></label>
      <label class="campo">${ehRec ? "Cliente" : "Fornecedor"}${campoContato("contato", l.contato || "", ehRec ? "cliente" : "fornecedor")}</label>
      <label class="campo">Valor (R$)<input type="text" name="valor" required inputmode="decimal" value="${l.valor ? num(l.valor).toFixed(2).replace(".", ",") : ""}" placeholder="0,00"></label>
      <label class="campo">Categoria<select name="categoria_id">${optCategorias(tipo, l.categoria_id)}</select></label>
      <label class="campo">Centro de custo<select name="centro_custo_id">${optCentros(l.centro_custo_id)}</select></label>
      <label class="campo">Vencimento<input type="date" name="vencimento" required value="${l.vencimento || ""}"></label>
      <label class="campo">Competência<input type="date" name="competencia" value="${l.competencia || ""}"><span class="dica-campo">Mês a que o valor pertence (DRE por competência). Vazio = vencimento.</span></label>
      <label class="campo">Conta bancária prevista<select name="conta_bancaria_id">${optContas(l.conta_bancaria_id, "— qualquer —")}</select></label>
      <label class="campo">Documento<input type="text" name="documento" maxlength="60" value="${esc(l.documento)}" placeholder="NF, boleto, contrato"></label>
      ${novo ? `
      <label class="campo">Repetição<select name="modo"><option value="">Uma vez</option><option value="parcelas">Parcelado (divide o valor)</option><option value="repetir">Todo mês (repete o valor)</option></select></label>
      <label class="campo">Quantidade<input type="number" name="qtd" min="2" max="120" value="2" disabled></label>
      <label class="opcao largo"><input type="checkbox" name="ja_pago"> Já foi ${ehRec ? "recebido" : "pago"} (baixa na conta escolhida, na data do vencimento)</label>` : ""}
      <label class="campo largo">Observação<textarea name="observacao">${esc(l.observacao)}</textarea></label>
    </div>`, async f => {
      const d = Object.fromEntries(f);
      const corpo = {descricao: d.descricao, valor: valorBR(d.valor), vencimento: d.vencimento,
        competencia: d.competencia || null, categoria_id: +d.categoria_id || null, centro_custo_id: +d.centro_custo_id || null,
        conta_bancaria_id: +d.conta_bancaria_id || null, documento: d.documento || null, observacao: d.observacao || null,
        contato_id: await resolverContato(d.contato, ehRec ? "cliente" : "fornecedor")};
      if (novo) {
        corpo.tipo = tipo;
        if (d.modo === "parcelas") corpo.parcelas = +d.qtd; else if (d.modo === "repetir") corpo.repetir_meses = +d.qtd;
        if (d.ja_pago) { if (!corpo.conta_bancaria_id) throw new Error("Escolha a conta onde foi " + (ehRec ? "recebido." : "pago.")); corpo.pago_em = d.vencimento; }
        const r = await api(E("/lancamentos"), {metodo: "POST", corpo});
        toast(r.length > 1 ? `${r.length} lançamentos criados.` : "Lançamento criado.");
      } else {
        await api(E(`/lancamentos/${l.id}`), {metodo: "PUT", corpo});
        toast("Lançamento salvo.");
      }
      aoSalvar?.();
    });
  const corpo = $("#modal-corpo");
  if (novo) corpo.querySelector("[name=modo]").onchange = e => corpo.querySelector("[name=qtd]").disabled = !e.target.value;
  // ao escolher o cliente/fornecedor, sugere a categoria e o centro de custo padrão dele
  corpo.querySelector("[name=contato]").addEventListener("change", e => {
    const c = (CAD.contatos || []).find(x => x.nome.toLowerCase() === e.target.value.trim().toLowerCase());
    if (!c) return;
    const cat = corpo.querySelector("[name=categoria_id]"), cc = corpo.querySelector("[name=centro_custo_id]");
    if (c.categoria_padrao_id && !cat.value) cat.value = c.categoria_padrao_id;
    if (c.centro_custo_padrao_id && !cc.value) cc.value = c.centro_custo_padrao_id;
  });
}

async function detalheLancamento(id, aoMudar) {
  const l = await api(E(`/lancamentos/${id}`));
  const ehRec = l.tipo === "receber", aberto = ["aberto", "parcial", "vencido"].includes(l.situacao);
  const corpo = gaveta(`<div>${selo(l.situacao)}</div><div class="valor-grande ${ehRec ? "c" : "d"}">${brl(l.valor)}</div><div>${esc(l.descricao)}</div>`, `
    <dl class="ficha">
      <dt>${ehRec ? "Cliente" : "Fornecedor"}</dt><dd>${esc(l.contato || "—")}</dd>
      <dt>Vencimento</dt><dd class="${l.situacao === "vencido" ? "atrasado" : ""}">${dataBR(l.vencimento)}</dd>
      <dt>Competência</dt><dd>${dataBR(l.competencia)}</dd>
      <dt>Categoria</dt><dd>${esc(l.categoria || "—")}</dd>
      <dt>Centro de custo</dt><dd>${esc(l.centro_custo || "—")}</dd>
      <dt>Conta prevista</dt><dd>${esc(l.conta_bancaria || "—")}</dd>
      ${l.documento ? `<dt>Documento</dt><dd>${esc(l.documento)}</dd>` : ""}
      ${l.total_parcelas > 1 ? `<dt>Parcela</dt><dd>${l.parcela} de ${l.total_parcelas}</dd>` : ""}
      ${l.recorrente ? `<dt>Repetição</dt><dd>mensal</dd>` : ""}
      ${l.observacao ? `<dt>Observação</dt><dd>${esc(l.observacao)}</dd>` : ""}
      <dt>Em aberto</dt><dd><b>${brl(l.restante)}</b></dd>
    </dl>
    <h2>${ehRec ? "Recebimentos" : "Pagamentos"} feitos</h2>
    ${l.baixas.length ? l.baixas.map(b => `<div class="envio"><div class="topo"><strong>${brl(b.valor)}${num(b.juros) ? ` + ${brl(b.juros)} juros` : ""}${num(b.desconto) ? ` − ${brl(b.desconto)} desc.` : ""}</strong>
        <span>${dataBR(b.data)}</span></div><div>${esc(b.conta_bancaria)} ${b.conciliada ? selo("conciliado", "conferido no extrato") : ""}
        ${pode() ? `<button class="btn perigo" style="float:right;padding:3px 10px;font-size:12px" data-estornar="${b.id}">Estornar</button>` : ""}</div></div>`).join("")
      : `<p class="sub">Nenhum ainda.</p>`}
    ${pode() && aberto ? `<form class="form-class" id="f-baixa"><h2>${ehRec ? "Registrar recebimento" : "Registrar pagamento"}</h2>
      <div class="grade-form">
        <label class="campo">Data<input type="date" name="data" value="${hojeISO()}" required></label>
        <label class="campo">Valor<input type="text" name="valor" value="${num(l.restante).toFixed(2).replace(".", ",")}" inputmode="decimal" required></label>
        <label class="campo">Conta<select name="conta_bancaria_id" required>${optContas(l.conta_bancaria_id || CAD.contas.find(c => c.ativo)?.id)}</select></label>
        <label class="campo">Juros / multa<input type="text" name="juros" value="0,00" inputmode="decimal"></label>
        <label class="campo">Desconto<input type="text" name="desconto" value="0,00" inputmode="decimal"></label>
      </div><div class="linha-acoes" style="margin-top:12px"><button class="btn primario" type="submit">${ehRec ? "Receber" : "Pagar"}</button></div></form>` : ""}
    ${pode() ? `<div class="linha-acoes" style="margin-top:22px;border-top:1px solid var(--linha);padding-top:16px">
      ${l.situacao !== "cancelado" ? `<button class="btn" id="b-editar">Editar</button>` : ""}
      ${!l.baixas.length && l.situacao !== "cancelado" ? `<button class="btn" id="b-cancelar">Cancelar</button>` : ""}
      ${l.situacao === "cancelado" ? `<button class="btn" id="b-reativar">Reativar</button>` : ""}
      ${!l.baixas.length ? `<button class="btn perigo" id="b-excluir">Excluir</button>` : ""}</div>` : ""}`);
  const dec = v => valorBR(v || "0") || "0";
  const recarregar = async () => { await aoMudar?.(); detalheLancamento(id, aoMudar); };
  $("#f-baixa", corpo)?.addEventListener("submit", tentar(async ev => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(ev.target));
    await api(E(`/lancamentos/${id}/baixar`), {metodo: "POST", corpo: {data: d.data, valor: dec(d.valor), conta_bancaria_id: +d.conta_bancaria_id,
                                                                     juros: dec(d.juros), desconto: dec(d.desconto)}});
    toast(ehRec ? "Recebimento registrado." : "Pagamento registrado."); recarregar();
  }));
  $$("[data-estornar]", corpo).forEach(b => b.onclick = tentar(async () => {
    if (!await confirmar("Estornar esta baixa? O lançamento volta a ficar em aberto.", "Estornar")) return;
    await api(E(`/baixas/${b.dataset.estornar}`), {metodo: "DELETE"}); toast("Baixa estornada."); recarregar();
  }));
  $("#b-editar", corpo) && ($("#b-editar", corpo).onclick = () => formLancamento(l.tipo, l, recarregar));
  $("#b-cancelar", corpo) && ($("#b-cancelar", corpo).onclick = tentar(async () => {
    await api(E(`/lancamentos/${id}/cancelar`), {metodo: "POST"}); toast("Lançamento cancelado."); recarregar(); }));
  $("#b-reativar", corpo) && ($("#b-reativar", corpo).onclick = tentar(async () => {
    await api(E(`/lancamentos/${id}/reativar`), {metodo: "POST"}); toast("Lançamento reativado."); recarregar(); }));
  $("#b-excluir", corpo) && ($("#b-excluir", corpo).onclick = tentar(async () => {
    if (!await confirmar(`Excluir “${esc(l.descricao)}”? Isso não pode ser desfeito.`, "Excluir")) return;
    await api(E(`/lancamentos/${id}`), {metodo: "DELETE"}); toast("Lançamento excluído."); fecharGaveta(); aoMudar?.(); }));
}

function baixaLote(tipo, ids, aoSalvar) {
  modal(`${tipo === "receber" ? "Receber" : "Pagar"} ${ids.length} lançamentos`, `<div class="grade-form">
      <label class="campo">Data<input type="date" name="data" value="${hojeISO()}" required></label>
      <label class="campo">Conta<select name="conta_bancaria_id" required>${optContas(CAD.contas.find(c => c.ativo)?.id)}</select></label></div>
    <p class="dica-campo">Cada um é baixado pelo valor que falta, sem juros nem desconto.</p>`, async f => {
      const d = Object.fromEntries(f);
      const r = await api(E("/lancamentos/baixar-lote"), {metodo: "POST", corpo: {ids, data: d.data, conta_bancaria_id: +d.conta_bancaria_id}});
      toast(`${r.baixados} lançamentos baixados.`); aoSalvar?.();
    }, {rotulo: "Confirmar baixa"});
}

// ================================================================== fluxo de caixa
const ESTADO_F = {agrupamento: "mes", meses_antes: 5, meses_depois: 6};
TELAS.fluxo = async main => {
  main.innerHTML = `<div class="topo-tela"><div><h1>Fluxo de caixa</h1>
      <p class="sub">Realizado (o que entrou e saiu das contas) e previsto (o que está em aberto, pelo vencimento). Contas em aberto já vencidas aparecem como previstas para hoje.</p></div></div>
    <div class="barra-filtros"><div id="agr"></div>
      <label class="campo">De<input type="date" id="f-ini"></label><label class="campo">Até<input type="date" id="f-fim"></label>
      <button class="btn" id="aplicar">Atualizar</button></div>
    <div class="cartoes" id="c-fluxo"></div>
    <section class="graf-bloco"><div class="graf alto"><canvas id="g-fluxo"></canvas></div></section>
    <div class="tabela-wrap"><table><thead><tr><th>Período</th><th class="num">Entradas</th><th class="num">Saídas</th><th class="num">Resultado</th>
      <th class="num">A receber</th><th class="num">A pagar</th><th class="num">Saldo realizado</th><th class="num">Saldo projetado</th></tr></thead><tbody id="t-fluxo"></tbody></table></div>`;
  const h = new Date();
  const padrao = {mes: [iso(new Date(h.getFullYear(), h.getMonth() - 5, 1)), iso(new Date(h.getFullYear(), h.getMonth() + 7, 0))],
                  semana: [iso(new Date(h.getFullYear(), h.getMonth() - 1, 1)), iso(new Date(h.getFullYear(), h.getMonth() + 3, 0))],
                  dia: [iso(new Date(h.getFullYear(), h.getMonth(), 1)), iso(new Date(h.getFullYear(), h.getMonth() + 1, 0))]};
  const fixa = () => { [$("#f-ini").value, $("#f-fim").value] = padrao[ESTADO_F.agrupamento]; };
  $("#agr").append(seg([["dia", "Diário"], ["semana", "Semanal"], ["mes", "Mensal"]], ESTADO_F.agrupamento, v => { ESTADO_F.agrupamento = v; fixa(); carregar(); }));
  fixa();
  $("#aplicar").onclick = () => carregar();
  async function carregar() {
    const f = await api(E("/fluxo?" + qs({inicio: $("#f-ini").value, fim: $("#f-fim").value, agrupamento: ESTADO_F.agrupamento})));
    const rot = p => ESTADO_F.agrupamento === "mes" ? mesCurto(p.slice(0, 7)) : dataBR(p).slice(0, 5);
    const ps = f.periodos, fim = ps[ps.length - 1] || {};
    const soma = k => ps.reduce((a, x) => a + num(x[k]), 0);
    $("#c-fluxo").innerHTML = `
      <div class="cartao"><span class="rot">Saldo no início</span><span class="num-g">${brl(f.saldo_inicial)}</span><small>${dataBR(f.inicio)}</small></div>
      <div class="cartao"><span class="rot">Entradas realizadas</span><span class="num-g c">${brl(soma("entradas"))}</span><small>a receber ${brl(soma("entradas_previstas"))}</small></div>
      <div class="cartao"><span class="rot">Saídas realizadas</span><span class="num-g d">${brl(soma("saidas"))}</span><small>a pagar ${brl(soma("saidas_previstas"))}</small></div>
      <div class="cartao ${num(fim.saldo_projetado) < 0 ? "alerta" : "ok"}"><span class="rot">Saldo projetado no fim</span><span class="num-g">${brlSinal(fim.saldo_projetado)}</span><small>${dataBR(f.fim)}</small></div>
      ${num(f.vencidos.pagar) || num(f.vencidos.receber) ? `<div class="cartao alerta"><span class="rot">Vencido e não pago</span><span class="num-g">${brl(f.vencidos.pagar)}</span><small>a pagar · e ${brl(f.vencidos.receber)} a receber atrasado</small></div>` : ""}`;
    grafico("g-fluxo", {type: "bar", data: {labels: ps.map(p => rot(p.periodo)), datasets: [
        {label: "Entradas", data: ps.map(p => num(p.entradas)), backgroundColor: COR.marca, stack: "e", borderRadius: 3},
        {label: "A receber", data: ps.map(p => num(p.entradas_previstas)), backgroundColor: "rgba(68,226,107,.3)", stack: "e", borderRadius: 3},
        {label: "Saídas", data: ps.map(p => -num(p.saidas)), backgroundColor: COR.deb, stack: "s", borderRadius: 3},
        {label: "A pagar", data: ps.map(p => -num(p.saidas_previstas)), backgroundColor: "rgba(255,122,107,.3)", stack: "s", borderRadius: 3},
        {label: "Saldo projetado", type: "line", data: ps.map(p => num(p.saldo_projetado)), borderColor: COR.azul, backgroundColor: COR.azul, tension: .25, pointRadius: 2, yAxisID: "y"}]},
      options: {scales: {x: {stacked: true}, y: {...eixoReais, stacked: false}},
        plugins: {tooltip: {callbacks: {label: c => ` ${c.dataset.label}: ${brl(Math.abs(c.parsed.y))}`}}}}});
    $("#t-fluxo").innerHTML = ps.map(p => `<tr><td>${ESTADO_F.agrupamento === "mes" ? mesNome(p.periodo.slice(0, 7)) : dataBR(p.periodo)}</td>
      <td class="num c">${num(p.entradas) ? brl(p.entradas) : "—"}</td><td class="num d">${num(p.saidas) ? brl(p.saidas) : "—"}</td>
      <td class="num ${num(p.resultado) < 0 ? "d" : ""}">${num(p.resultado) ? brlSinal(p.resultado) : "—"}</td>
      <td class="num">${num(p.entradas_previstas) ? brl(p.entradas_previstas) : "—"}</td><td class="num">${num(p.saidas_previstas) ? brl(p.saidas_previstas) : "—"}</td>
      <td class="num">${p.saldo !== null ? brlSinal(p.saldo) : ""}</td><td class="num ${num(p.saldo_projetado) < 0 ? "d" : ""}"><b>${brlSinal(p.saldo_projetado)}</b></td></tr>`).join("");
  }
  await carregar();
};

// detalhamento usado por gráficos e relatórios
async function abrirDetalheRelatorio(titulo, filtros) {
  const itens = await api(E("/relatorios/detalhe?" + qs({regime: "caixa", ...filtros})));
  const total = itens.reduce((a, x) => a + (x.tipo === "receber" ? 1 : -1) * num(x.valor), 0);
  const corpo = gaveta(`<div class="valor-grande">${itens.length}</div><div>${esc(titulo)}</div>`,
    `<p class="sub">Saldo destes lançamentos: <b>${brlSinal(total)}</b></p><div class="lista-venc">${itens.map(x =>
      `<a href="#${x.tipo}/${x.lancamento_id}"><span class="dt">${dataBR(x.data).slice(0, 5)}</span><span class="tx">${esc(x.descricao)}<span class="sublinha">${esc(x.categoria || "")}</span></span>
       <span class="num ${x.tipo === "receber" ? "c" : "d"}">${brl(x.valor)}</span></a>`).join("") || `<p class="sub">Nada neste recorte.</p>`}</div>`);
  $$("a", corpo).forEach(a => a.addEventListener("click", () => fecharGaveta()));
}
