"""Segurança: senhas (bcrypt), sessões no servidor, verificação em duas etapas (TOTP), códigos de
recuperação e cifra de segredos (Fernet, com rotação da chave)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import bcrypt
import jwt
from cryptography.fernet import Fernet, InvalidToken, MultiFernet

from app.config import get_settings

COOKIE = "fp_sessao"
COOKIE_2FA = "fp_2fa"                 # etapa intermediária do login (senha certa, falta o código)
CHAVE_PADRAO = "troque-esta-chave"


# ============================================================================ senhas

def hash_senha(senha: str) -> str:
    return bcrypt.hashpw(senha.encode("utf-8")[:72], bcrypt.gensalt(rounds=12)).decode()


def confere_senha(senha: str, hash_: str) -> bool:
    try:
        return bcrypt.checkpw(senha.encode("utf-8")[:72], hash_.encode())
    except ValueError:
        return False


# hash qualquer, para o login gastar o mesmo tempo quando o e-mail não existe (não revela quem tem conta)
HASH_FALSO = bcrypt.hashpw(b"nao-existe", bcrypt.gensalt(rounds=12)).decode()

COMUNS = {"1234567890", "12345678910", "0123456789", "senha12345", "senha123456", "qwerty1234", "qwertyuiop1",
          "password12", "password123", "abc1234567", "financepro1", "financepro123", "admin12345", "admin123456",
          "mudar12345", "trocar12345", "brasil2026", "brasil12345", "empresa123", "a1b2c3d4e5", "1q2w3e4r5t",
          "teste12345", "iloveyou12", "senhasenha1", "minhasenha1", "123mudar123"}


def _sem_acento(t: str) -> str:
    return unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()


def senha_fraca(senha: str, email: str | None = None, nome: str | None = None) -> str | None:
    """Política básica (recomendação do NIST 800-63B): tamanho manda mais que símbolos; bloqueia as óbvias."""
    if len(senha) < 10:
        return "A senha precisa de pelo menos 10 caracteres."
    if len(senha) > 128:
        return "A senha pode ter no máximo 128 caracteres."
    if senha.isdigit() or senha.isalpha():
        return "Use letras e números na senha."
    s = _sem_acento(senha)
    if s in COMUNS or len(set(s)) <= 3:
        return "Essa senha é muito comum. Escolha outra."
    for parte in [(email or "").split("@")[0], *(_sem_acento(nome or "").split())]:
        parte = _sem_acento(parte)
        if len(parte) >= 4 and parte in s:
            return "A senha não pode conter o seu nome ou o seu e-mail."
    return None


# ============================================================================ sessões

def novo_token() -> tuple[str, str]:
    """(token para o cookie, hash para o banco). O banco nunca guarda o token em si."""
    t = secrets.token_urlsafe(32)
    return t, hash_token(t)


def hash_token(t: str) -> str:
    return hashlib.sha256(t.encode()).hexdigest()


def token_2fa(usuario_id: int) -> str:
    """Prova curta (5 min) de que a senha já foi conferida; falta o código da verificação em duas etapas."""
    agora = datetime.now(timezone.utc)
    return jwt.encode({"sub": str(usuario_id), "etapa": "2fa", "iat": agora, "exp": agora + timedelta(minutes=5)},
                      get_settings().secret_key, algorithm="HS256")


def ler_token_2fa(token: str) -> int | None:
    try:
        d = jwt.decode(token, get_settings().secret_key, algorithms=["HS256"])
        return int(d["sub"]) if d.get("etapa") == "2fa" else None
    except (jwt.PyJWTError, KeyError, ValueError):
        return None


# ============================================================================ verificação em duas etapas (RFC 6238)

def novo_segredo_totp() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def codigo_totp(segredo: str, passo: int) -> str:
    chave = base64.b32decode(segredo + "=" * (-len(segredo) % 8), casefold=True)
    h = hmac.new(chave, struct.pack(">Q", passo), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1_000_000:06d}"


def conferir_totp(segredo: str, codigo: str, ultimo_passo: int | None = None, agora: float | None = None) -> int | None:
    """Devolve o passo usado (para impedir reuso) ou None. Aceita 30 s de diferença no relógio do celular."""
    codigo = "".join(c for c in (codigo or "") if c.isdigit())
    if len(codigo) != 6:
        return None
    atual = int((agora if agora is not None else time.time()) // 30)
    for passo in (atual - 1, atual, atual + 1):
        if ultimo_passo is not None and passo <= ultimo_passo:
            continue
        if hmac.compare_digest(codigo_totp(segredo, passo), codigo):
            return passo
    return None


def uri_totp(segredo: str, email: str, emissor: str = "FinancePro ERP") -> str:
    return (f"otpauth://totp/{quote(emissor)}:{quote(email)}?secret={segredo}&issuer={quote(emissor)}"
            "&algorithm=SHA1&digits=6&period=30")


def qr_svg(texto: str) -> str:
    import io
    import segno
    buf = io.BytesIO()
    segno.make(texto, error="m").save(buf, kind="svg", scale=5, border=2, dark="#04140A", light="#FFFFFF", xmldecl=False)
    return buf.getvalue().decode()


def novos_codigos_recuperacao(n: int = 8) -> tuple[list[str], list[str]]:
    """(códigos para mostrar uma vez, hashes para guardar). Cada código vale uma vez."""
    alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    codigos = ["-".join("".join(secrets.choice(alfabeto) for _ in range(4)) for _ in range(2)) for _ in range(n)]
    return codigos, [_hash_codigo(c) for c in codigos]


def _hash_codigo(c: str) -> str:
    return hashlib.sha256(("fp-rec:" + c.replace("-", "").replace(" ", "").upper()).encode()).hexdigest()


def usar_codigo_recuperacao(codigo: str, hashes: list[str]) -> list[str] | None:
    """Se o código vale, devolve a lista sem ele; senão None."""
    h = _hash_codigo(codigo or "")
    for x in hashes or []:
        if hmac.compare_digest(x, h):
            return [y for y in hashes if y != x]
    return None


# ============================================================================ cifra de segredos

def _fernet_de(chave_texto: str) -> Fernet:
    chave = hashlib.sha256(("fp-segredos:" + chave_texto).encode()).digest()
    return Fernet(base64.urlsafe_b64encode(chave))


def _fernet() -> MultiFernet:
    """Cifra sempre com a SECRET_KEY atual; decifra também com a anterior (durante a troca de chave)."""
    st = get_settings()
    chaves = [_fernet_de(st.secret_key)]
    if st.secret_key_anterior:
        chaves.append(_fernet_de(st.secret_key_anterior))
    return MultiFernet(chaves)


def cifrar(texto: str) -> str:
    return _fernet().encrypt(texto.encode()).decode()


def cifrar_bytes(dado: bytes) -> bytes:
    return _fernet().encrypt(dado)


def decifrar_bytes(dado: bytes) -> bytes:
    try:
        return _fernet().decrypt(dado)
    except InvalidToken as exc:
        raise ValueError("Não foi possível ler o arquivo cifrado (a SECRET_KEY mudou?). Envie de novo.") from exc


def decifrar(cifrado: str) -> str:
    try:
        return _fernet().decrypt(cifrado.encode()).decode()
    except InvalidToken as exc:
        raise ValueError("Não foi possível ler a credencial (a SECRET_KEY mudou?). Cadastre de novo.") from exc


def recifrar(cifrado: str) -> str:
    """Reescreve com a chave atual (usado depois de trocar a SECRET_KEY)."""
    return _fernet().rotate(cifrado.encode()).decode()


def problema_da_chave(chave: str) -> str | None:
    if not chave or chave == CHAVE_PADRAO:
        return "SECRET_KEY não definida (está com o valor de exemplo)."
    if len(chave) < 32:
        return "SECRET_KEY curta demais: use pelo menos 32 caracteres aleatórios."
    if len(set(chave)) < 10:
        return "SECRET_KEY pouco aleatória."
    return None
