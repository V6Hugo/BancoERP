"""FinancePro ERP: gestão financeira multiempresa (recebimentos, pagamentos, fluxo de caixa,
integração bancária e relatórios)."""
__version__ = "1.2.1"
