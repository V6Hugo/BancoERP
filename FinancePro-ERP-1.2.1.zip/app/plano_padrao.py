"""Plano de contas gerencial padrão: objetivo, organizado pelas linhas do DRE.

Cada empresa nova recebe uma cópia e pode renomear, criar, desativar e reorganizar à vontade.
Formato: (código, nome, natureza, grupo_dre, [categorias (código, nome)]).
"""
from __future__ import annotations

PLANO_PADRAO: list[tuple[str, str, str, str, list[tuple[str, str]]]] = [
    ("1", "Receitas operacionais", "receita", "receita_bruta", [
        ("1.01", "Venda de produtos"),
        ("1.02", "Prestação de serviços"),
        ("1.03", "Outras receitas operacionais"),
    ]),
    ("2", "Deduções da receita", "despesa", "deducoes", [
        ("2.01", "Simples Nacional / DAS"),
        ("2.02", "ISS"),
        ("2.03", "ICMS"),
        ("2.04", "PIS e COFINS"),
        ("2.05", "Devoluções e cancelamentos"),
        ("2.06", "Taxas de cartão e meios de pagamento"),
    ]),
    ("3", "Custos diretos", "despesa", "custos", [
        ("3.01", "Compra de mercadorias e insumos"),
        ("3.02", "Serviços terceirizados (produção)"),
        ("3.03", "Fretes e logística"),
        ("3.04", "Comissões de venda"),
    ]),
    ("4", "Despesas com pessoal", "despesa", "despesas_operacionais", [
        ("4.01", "Salários"),
        ("4.02", "Pró-labore"),
        ("4.03", "INSS e FGTS"),
        ("4.04", "Férias e 13º salário"),
        ("4.05", "Vale-transporte e vale-refeição"),
        ("4.06", "Plano de saúde"),
        ("4.07", "Rescisões"),
        ("4.08", "Treinamentos"),
    ]),
    ("5", "Despesas administrativas", "despesa", "despesas_operacionais", [
        ("5.01", "Aluguel e condomínio"),
        ("5.02", "Energia, água e gás"),
        ("5.03", "Telefone e internet"),
        ("5.04", "Contabilidade"),
        ("5.05", "Jurídico e consultorias"),
        ("5.06", "Sistemas e softwares"),
        ("5.07", "Material de escritório e limpeza"),
        ("5.08", "Manutenção e conservação"),
        ("5.09", "Seguros"),
        ("5.10", "Viagens e deslocamentos"),
        ("5.11", "Impostos e taxas diversas (IPTU, alvará)"),
    ]),
    ("6", "Despesas comerciais", "despesa", "despesas_operacionais", [
        ("6.01", "Marketing e publicidade"),
        ("6.02", "Brindes e eventos"),
    ]),
    ("7", "Receitas financeiras", "receita", "receitas_financeiras", [
        ("7.01", "Rendimentos de aplicações"),
        ("7.02", "Juros e multas recebidos"),
        ("7.03", "Descontos obtidos"),
    ]),
    ("8", "Despesas financeiras", "despesa", "despesas_financeiras", [
        ("8.01", "Tarifas bancárias"),
        ("8.02", "Juros e multas pagos"),
        ("8.03", "IOF"),
        ("8.04", "Juros de empréstimos e financiamentos"),
    ]),
    ("9", "Impostos sobre o lucro", "despesa", "impostos_lucro", [
        ("9.01", "IRPJ"),
        ("9.02", "CSLL"),
    ]),
    ("10", "Investimentos", "despesa", "investimentos", [
        ("10.01", "Máquinas e equipamentos"),
        ("10.02", "Móveis e utensílios"),
        ("10.03", "Computadores e periféricos"),
        ("10.04", "Obras e benfeitorias"),
    ]),
    ("11", "Movimentações não operacionais", "neutra", "nao_operacional", [
        ("11.01", "Empréstimos recebidos"),
        ("11.02", "Pagamento de empréstimos (principal)"),
        ("11.03", "Aporte de sócios"),
        ("11.04", "Distribuição de lucros"),
        ("11.05", "Aplicações financeiras"),
        ("11.06", "Resgates de aplicações"),
    ]),
]

CENTROS_PADRAO: list[tuple[str, str]] = [
    ("01", "Administrativo"),
    ("02", "Comercial"),
    ("03", "Operacional"),
    ("04", "Financeiro"),
]

# linhas do DRE na ordem em que aparecem, e o sinal com que entram no resultado
LINHAS_DRE: list[tuple[str, str, int]] = [
    ("receita_bruta", "Receita bruta", 1),
    ("deducoes", "(−) Deduções da receita", -1),
    ("custos", "(−) Custos diretos", -1),
    ("despesas_operacionais", "(−) Despesas operacionais", -1),
    ("receitas_financeiras", "(+) Receitas financeiras", 1),
    ("despesas_financeiras", "(−) Despesas financeiras", -1),
    ("impostos_lucro", "(−) IRPJ e CSLL", -1),
    ("investimentos", "Investimentos (fora do resultado)", -1),
    ("nao_operacional", "Movimentações não operacionais (fora do resultado)", 0),
]
NOMES_DRE = {k: n for k, n, _ in LINHAS_DRE}

# subtotais do DRE: nome e quais linhas somam até ele
SUBTOTAIS_DRE: list[tuple[str, str, list[str]]] = [
    ("deducoes", "Receita líquida", ["receita_bruta", "deducoes"]),
    ("custos", "Lucro bruto", ["receita_bruta", "deducoes", "custos"]),
    ("despesas_operacionais", "Resultado operacional (EBITDA)", ["receita_bruta", "deducoes", "custos",
                                                                 "despesas_operacionais"]),
    ("impostos_lucro", "Resultado líquido", ["receita_bruta", "deducoes", "custos", "despesas_operacionais",
                                             "receitas_financeiras", "despesas_financeiras", "impostos_lucro"]),
]

# bancos mais usados (código COMPE) — o OFX funciona com qualquer um; integração por API: Inter
BANCOS: dict[str, str] = {
    "001": "Banco do Brasil", "033": "Santander", "041": "Banrisul", "077": "Inter", "104": "Caixa",
    "208": "BTG Pactual", "212": "Banco Original", "237": "Bradesco", "260": "Nubank", "290": "PagBank",
    "323": "Mercado Pago", "336": "C6 Bank", "341": "Itaú", "380": "PicPay", "403": "Cora", "422": "Safra",
    "655": "Votorantim", "748": "Sicredi", "756": "Sicoob", "197": "Stone", "102": "XP",
}
