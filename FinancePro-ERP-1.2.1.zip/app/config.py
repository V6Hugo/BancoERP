"""Configuração lida do ambiente (ou do arquivo .env)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # PostgreSQL em produção. Ex.: postgresql+psycopg://financepro:senha@localhost:5432/financepro
    database_url: str = "postgresql+psycopg://financepro:financepro@localhost:5432/financepro"

    # chave para assinar a sessão e cifrar segredos (credenciais de banco). Gere uma longa e guarde bem.
    secret_key: str = "troque-esta-chave"
    # ao trocar a SECRET_KEY, ponha a antiga aqui: o sistema re-cifra as credenciais e depois ela pode sair
    secret_key_anterior: str = ""
    sessao_horas: int = 12               # duração máxima de uma sessão
    sessao_inatividade_min: int = 60     # sem usar por este tempo, a sessão termina
    cookie_seguro: bool = False          # True quando estiver em HTTPS

    # endereços pelos quais o sistema pode ser aberto (protege contra "DNS rebinding"). "*" = qualquer um
    hosts_permitidos: str = "localhost,127.0.0.1"
    # documentação interativa da API em /docs (deixe desligada no uso normal)
    docs_api: bool = False

    # certificados das APIs bancárias (ex.: Inter) ficam aqui, fora do banco de dados
    pasta_certificados: str = "dados/certificados"
    pasta_backups: str = "dados/backups"

    tamanho_max_upload_mb: int = 20
    log_level: str = "INFO"

    # sincronização automática dos bancos integrados a cada N minutos (0 = só manual)
    sincronizar_bancos_min: int = 0

    @property
    def dir_certificados(self) -> Path:
        return Path(self.pasta_certificados)


@lru_cache
def get_settings() -> Settings:
    return Settings()
