"""Empresas: criação já com o plano de contas e os centros de custo padrão."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.documentos import cnpj_valido, somente_digitos
from app.models import Categoria, CentroCusto, Empresa, Vinculo
from app.plano_padrao import CENTROS_PADRAO, PLANO_PADRAO
from app.servicos import NegocioErro, auditar


def criar_empresa(session: Session, nome: str, cnpj: str | None = None, razao_social: str | None = None,
                  dono_id: int | None = None) -> Empresa:
    nome = (nome or "").strip()
    if not nome:
        raise NegocioErro("Informe o nome da empresa.")
    doc = somente_digitos(cnpj) or None
    if doc and not cnpj_valido(doc):
        raise NegocioErro("CNPJ inválido. Confira os números.")
    if doc and session.scalar(select(Empresa.id).where(Empresa.cnpj == doc)):
        raise NegocioErro("Já existe uma empresa com este CNPJ.")
    emp = Empresa(nome=nome, cnpj=doc, razao_social=(razao_social or "").strip() or None)
    session.add(emp)
    session.flush()
    semear_plano(session, emp.id)
    if dono_id:
        session.add(Vinculo(usuario_id=dono_id, empresa_id=emp.id, papel="admin"))
    auditar(session, emp.id, dono_id, "empresa", emp.id, "criar", {"nome": nome})
    session.flush()
    return emp


def semear_plano(session: Session, empresa_id: int) -> None:
    for cod, nome, natureza, grupo, cats in PLANO_PADRAO:
        pai = Categoria(empresa_id=empresa_id, codigo=cod, nome=nome, natureza=natureza, grupo_dre=grupo)
        session.add(pai)
        session.flush()
        for c_cod, c_nome in cats:
            session.add(Categoria(empresa_id=empresa_id, pai_id=pai.id, codigo=c_cod, nome=c_nome,
                                  natureza=natureza, grupo_dre=grupo))
    for cod, nome in CENTROS_PADRAO:
        session.add(CentroCusto(empresa_id=empresa_id, codigo=cod, nome=nome))
    session.flush()
