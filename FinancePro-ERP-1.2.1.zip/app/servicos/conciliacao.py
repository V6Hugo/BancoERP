"""Extrato bancário: importação (OFX ou API), regras de classificação e conciliação com os lançamentos."""
from __future__ import annotations

from collections import Counter
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.bancos import TransacaoBanco
from app.models import (Baixa, Categoria, ContaBancaria, Contato, ImportacaoExtrato, Lancamento, Movimento,
                        RegraClassificacao)
from app.servicos import NegocioErro, auditar, normalizar
from app.servicos import lancamentos as svc_l

JANELA_DIAS = 10        # vencimento até 10 dias antes/depois do movimento conta como candidato


# ============================================================================ importação

ORIGENS = {"ofx": "Arquivo OFX", "planilha": "Planilha", "api_inter": "API Inter", "openfinance": "Open Finance"}


def _separar(session: Session, conta: ContaBancaria, transacoes: list[TransacaoBanco], origem: str,
             pular_parecidos: bool) -> tuple[list[tuple[str, TransacaoBanco]], int, int]:
    """Divide as transações em novas, já importadas (mesma chave) e parecidas: mesma data, valor e sentido de
    um movimento que já está na conta com outra descrição (ex.: o mesmo dia importado por OFX e agora por
    planilha, ou uma planilha importada antes com menos colunas). A tela mostra os parecidos e deixa importar."""
    vistos: Counter = Counter()
    chaves = []
    for t in transacoes:
        chave = t.chave()
        vistos[chave] += 1
        chaves.append(f"{chave}#{vistos[chave]}" if vistos[chave] > 1 else chave)
    existentes: dict[str, tuple] = {}
    if transacoes:
        ini, fim = min(t.data for t in transacoes), max(t.data for t in transacoes)
        for k, d, n, v in session.execute(select(Movimento.id_externo, Movimento.data, Movimento.natureza, Movimento.valor)
                                          .where(Movimento.conta_bancaria_id == conta.id)):
            existentes[k] = (d, n, Decimal(v)) if ini <= d <= fim else None
    # os movimentos já na conta que não casam pela chave ficam disponíveis para casar como "parecidos"
    usadas = {k for k in chaves if k in existentes}
    livres: Counter = Counter(x for k, x in existentes.items() if x and k not in usadas) if pular_parecidos else Counter()
    novas, dup, par = [], 0, 0
    for chave, t in zip(chaves, transacoes):
        if chave in existentes:
            dup += 1
            continue
        k = (t.data, t.natureza, t.valor)
        if livres[k] > 0:
            livres[k] -= 1
            par += 1
            continue
        existentes[chave] = None
        novas.append((chave, t))
    return novas, dup, par


def importar(session: Session, conta: ContaBancaria, transacoes: list[TransacaoBanco], origem: str,
             usuario_id: int | None, arquivo: str | None = None, saldo: Decimal | None = None,
             data_saldo: date | None = None, pular_parecidos: bool = True) -> dict[str, Any]:
    """Grava as transações como movimentos da conta. Reimportar o mesmo período não duplica
    (chave do banco por conta); transações idênticas no mesmo arquivo são mantidas (sufixo #2, #3)."""
    if conta.tipo == "caixa":
        raise NegocioErro("Conta do tipo caixa não tem extrato bancário.")
    novas, dup, par = _separar(session, conta, transacoes, origem, pular_parecidos)
    imp = ImportacaoExtrato(empresa_id=conta.empresa_id, conta_bancaria_id=conta.id, origem=origem, arquivo=(arquivo or "")[:255] or None,
                            inicio=min((t.data for t in transacoes), default=None),
                            fim=max((t.data for t in transacoes), default=None),
                            recebidos=len(transacoes), duplicados=dup + par, saldo_banco=saldo, data_saldo_banco=data_saldo,
                            criado_por=usuario_id)
    session.add(imp)
    session.flush()
    novos = []
    for chave, t in novas:
        m = Movimento(empresa_id=conta.empresa_id, conta_bancaria_id=conta.id, importacao_id=imp.id, data=t.data,
                      valor=t.valor, natureza=t.natureza, descricao=t.descricao[:300], documento=(t.documento or None) and t.documento[:60],
                      id_externo=chave, origem=origem, dados_brutos={k: str(v) for k, v in (t.dados_brutos or {}).items()})
        session.add(m)
        novos.append(m)
    imp.novos = len(novos)
    session.flush()
    auto = conciliar_automatico(session, conta.empresa_id, [m.id for m in novos])
    auditar(session, conta.empresa_id, usuario_id, "importacao", imp.id, "importar",
            {"conta": conta.nome, "origem": origem, "novos": imp.novos, "duplicados": dup, "parecidos": par})
    session.flush()
    return {"importacao_id": imp.id, "recebidos": imp.recebidos, "novos": imp.novos, "duplicados": dup, "parecidos": par,
            "periodo": [imp.inicio, imp.fim], "saldo_banco": saldo, "data_saldo_banco": data_saldo, **auto}


def _conta_diferente(conta: ContaBancaria, no_arquivo: str | None) -> bool:
    from app.documentos import somente_digitos
    if not conta.numero or not no_arquivo:
        return False
    meu, dele = somente_digitos(conta.numero).lstrip("0"), somente_digitos(no_arquivo).lstrip("0")
    if not meu or not dele:
        return False
    return dele not in (meu, meu[:-1]) and meu not in dele and dele not in meu


def _conferir_conta_ofx(conta: ContaBancaria, extratos, tipo: str = "OFX") -> str | None:
    outros = [e.conta for e in extratos if _conta_diferente(conta, e.conta)]
    if outros:
        return (f"O {tipo} é da conta {', '.join(outros)} e não da conta {conta.numero} ({conta.nome}). "
                "Escolha a conta certa ou importe mesmo assim.")
    return None


def _conferir_conta_planilha(conta: ContaBancaria, grade, det) -> tuple[str | None, str | None]:
    from app.bancos import planilha as pl
    no_arquivo = pl.conta_no_cabecalho(grade, det.linha_cabecalho)
    if _conta_diferente(conta, no_arquivo):
        return no_arquivo, (f"A planilha é da conta {no_arquivo} e não da conta {conta.numero} ({conta.nome}). "
                            "Escolha a conta certa ou importe mesmo assim.")
    return no_arquivo, None


def _ler_ofx(conteudo: bytes):
    from app.bancos.ofx import OFXErro, ler_ofx
    try:
        extratos = ler_ofx(conteudo)
    except OFXErro as exc:
        raise NegocioErro(str(exc)) from exc
    trans = [t for e in extratos for t in e.transacoes]
    saldo = next((e.saldo for e in extratos if e.saldo is not None), None)
    data_saldo = next((e.data_saldo for e in extratos if e.data_saldo is not None), None)
    return extratos, trans, saldo, data_saldo


def importar_ofx(session: Session, conta: ContaBancaria, conteudo: bytes, nome: str, usuario_id: int | None,
                 forcar: bool = False, pular_parecidos: bool = True) -> dict[str, Any]:
    extratos, trans, saldo, data_saldo = _ler_ofx(conteudo)
    erro = None if forcar else _conferir_conta_ofx(conta, extratos)
    if erro:
        raise NegocioErro(erro)
    return importar(session, conta, trans, "ofx", usuario_id, arquivo=nome, saldo=saldo, data_saldo=data_saldo,
                    pular_parecidos=pular_parecidos)


def _ler_planilha(conteudo: bytes, nome: str, mapa: dict | None, inverter: bool, tolerante: bool = False):
    """Lê a planilha e reconhece as colunas. `mapa` (da tela) pode trazer a linha do cabeçalho e/ou as colunas.
    tolerante: em vez de erro por coluna faltando, devolve resultado None (a prévia deixa a pessoa corrigir)."""
    from app.bancos import planilha as pl
    try:
        linhas = pl.ler_linhas(conteudo, nome)
        det = pl.detectar(linhas)
        if mapa:
            if "cabecalho" in mapa:
                cab = mapa.get("cabecalho")
                i = None if cab in (None, "", -1, "-1") else max(0, min(int(cab), len(linhas) - 1))
                det = pl.detectar_na_linha(linhas, i)
            campos = pl.validar_mapa(mapa, len(det.colunas))
            if campos:
                det.mapa = campos
    except pl.PlanilhaErro as exc:
        raise NegocioErro(str(exc)) from exc
    try:
        res = pl.interpretar(linhas, det.linha_cabecalho, det.mapa, inverter)
    except pl.PlanilhaErro as exc:
        if not tolerante:
            raise NegocioErro(str(exc)) from exc
        return linhas, det, None, str(exc)
    return linhas, det, res, None


def previa_extrato(session: Session, conta: ContaBancaria, conteudo: bytes, nome: str, mapa: dict | None = None,
                   inverter: bool = False) -> dict[str, Any]:
    """Lê o arquivo sem gravar nada: mostra o que será importado, para conferir (e corrigir as colunas)."""
    from app.bancos import planilha as pl
    tipo = pl.tipo_arquivo(conteudo, nome)
    out: dict[str, Any] = {"arquivo": nome, "tipo": "ofx" if tipo == "ofx" else "planilha", "formato": tipo, "avisos": []}
    if tipo == "ofx":
        extratos, trans, saldo, data_saldo = _ler_ofx(conteudo)
        out["conta_no_arquivo"] = ", ".join(sorted({e.conta for e in extratos if e.conta})) or None
        out["alerta_conta"] = _conferir_conta_ofx(conta, extratos)
        linhas = [{"linha": i + 1, "data": t.data, "descricao": t.descricao, "valor": t.valor, "natureza": t.natureza,
                   "motivo": None} for i, t in enumerate(trans)]
        puladas = 0
    else:
        grade, det, res, erro = _ler_planilha(conteudo, nome, mapa, inverter, tolerante=True)
        if res is None:
            res = pl.Resultado([], [], None, None, [erro])
        trans, saldo, data_saldo = res.transacoes, res.saldo, res.data_saldo
        ini = 0 if det.linha_cabecalho is None else det.linha_cabecalho + 1
        out.update(colunas=det.colunas, mapa=det.mapa, linha_cabecalho=det.linha_cabecalho, campos=pl.CAMPOS,
                   amostra=[[pl._texto(c)[:60] for c in l] for l in grade[ini:ini + 5]],
                   cabecalho_opcoes=[{"indice": i, "texto": " | ".join(pl._texto(c)[:20] for c in l if c not in (None, ""))[:120]}
                                     for i, l in enumerate(grade[:25])])
        out["avisos"] += res.avisos
        out["conta_no_arquivo"], out["alerta_conta"] = _conferir_conta_planilha(conta, grade, det)
        linhas = [{"linha": x.numero, "data": x.data, "descricao": x.descricao, "valor": x.valor, "natureza": x.natureza,
                   "motivo": x.motivo} for x in res.linhas]
        puladas = sum(1 for x in res.linhas if x.motivo)
    novas, dup, par = _separar(session, conta, trans, "ofx" if tipo == "ofx" else "planilha", True)
    ent = [t.valor for t in trans if t.natureza == "C"]
    sai = [t.valor for t in trans if t.natureza == "D"]
    out["resumo"] = {"movimentos": len(trans), "entradas": len(ent), "saidas": len(sai), "total_entradas": sum(ent, Decimal("0")),
                     "total_saidas": sum(sai, Decimal("0")), "inicio": min((t.data for t in trans), default=None),
                     "fim": max((t.data for t in trans), default=None), "puladas": puladas, "novos": len(novas),
                     "ja_importados": dup, "parecidos": par}
    out["saldo_banco"], out["data_saldo_banco"] = saldo, data_saldo
    out["linhas"] = linhas[:400]
    if par:
        out["avisos"].append(f"{par} movimento(s) têm a mesma data, valor e sentido de movimentos que já estão nesta conta "
                             "(de um OFX ou de uma importação anterior). Por padrão eles não entram de novo.")
    return out


def importar_arquivo(session: Session, conta: ContaBancaria, conteudo: bytes, nome: str, usuario_id: int | None,
                     forcar: bool = False, mapa: dict | None = None, inverter: bool = False,
                     pular_parecidos: bool = True) -> dict[str, Any]:
    """Importa um extrato em OFX ou planilha (Excel, CSV): o formato é reconhecido pelo conteúdo."""
    from app.bancos import planilha as pl
    if pl.tipo_arquivo(conteudo, nome) == "ofx":
        return importar_ofx(session, conta, conteudo, nome, usuario_id, forcar, pular_parecidos)
    grade, det, res, _ = _ler_planilha(conteudo, nome, mapa, inverter)
    if not forcar:
        _, erro = _conferir_conta_planilha(conta, grade, det)
        if erro:
            raise NegocioErro(erro)
    return importar(session, conta, res.transacoes, "planilha", usuario_id, arquivo=nome, saldo=res.saldo,
                    data_saldo=res.data_saldo, pular_parecidos=pular_parecidos)


def importacoes(session: Session, empresa_id: int, conta_id: int | None = None, limite: int = 100) -> list[dict[str, Any]]:
    from sqlalchemy import func
    q = select(ImportacaoExtrato).where(ImportacaoExtrato.empresa_id == empresa_id)
    if conta_id:
        q = q.where(ImportacaoExtrato.conta_bancaria_id == conta_id)
    imps = list(session.scalars(q.order_by(ImportacaoExtrato.criado_em.desc(), ImportacaoExtrato.id.desc()).limit(limite)))
    cont: dict[int, dict[str, int]] = {}
    if imps:
        for iid, sit, n in session.execute(select(Movimento.importacao_id, Movimento.situacao, func.count()).where(
                Movimento.importacao_id.in_([i.id for i in imps])).group_by(Movimento.importacao_id, Movimento.situacao)):
            cont.setdefault(iid, {})[sit] = n
    contas = {c.id: c.nome for c in session.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == empresa_id))}
    return [{"id": i.id, "conta_id": i.conta_bancaria_id, "conta": contas.get(i.conta_bancaria_id), "origem": i.origem,
             "origem_nome": ORIGENS.get(i.origem, i.origem), "arquivo": i.arquivo, "inicio": i.inicio, "fim": i.fim,
             "recebidos": i.recebidos, "novos": i.novos, "duplicados": i.duplicados, "saldo_banco": i.saldo_banco,
             "data_saldo_banco": i.data_saldo_banco, "criado_em": i.criado_em,
             "pendentes": cont.get(i.id, {}).get("pendente", 0), "conciliados": cont.get(i.id, {}).get("conciliado", 0),
             "ignorados": cont.get(i.id, {}).get("ignorado", 0)} for i in imps]


def desfazer_importacao(session: Session, imp: ImportacaoExtrato, usuario_id: int | None) -> dict[str, int]:
    """Apaga os movimentos trazidos por uma importação (ex.: arquivo da conta errada). Só quando nenhum
    deles foi conciliado: o que já virou baixa ou transferência precisa ser desfeito antes, um a um."""
    movs = list(session.scalars(select(Movimento).where(Movimento.importacao_id == imp.id)))
    conc = sum(1 for m in movs if m.situacao == "conciliado")
    if conc:
        raise NegocioErro(f"{conc} movimento(s) desta importação já foram conciliados. Desfaça essas conciliações "
                          "(em Bancos › Conciliados) antes de desfazer a importação.")
    for m in movs:
        session.delete(m)
    auditar(session, imp.empresa_id, usuario_id, "importacao", imp.id, "desfazer",
            {"arquivo": imp.arquivo, "movimentos": len(movs)})
    session.delete(imp)
    session.flush()
    return {"removidos": len(movs)}


def sincronizar_inter(session: Session, conta: ContaBancaria, usuario_id: int | None, inicio: date | None = None,
                      fim: date | None = None, transport=None) -> dict[str, Any]:
    """Busca o extrato na API do Inter (desde a última sincronização, ou os últimos 30 dias)."""
    from app.bancos.inter import ClienteInter, InterErro
    from app.config import get_settings
    from app.seguranca import decifrar
    cfg = conta.integracao_config or {}
    if conta.integracao != "inter" or not cfg.get("client_id"):
        raise NegocioErro("Esta conta não tem a integração com o Inter configurada.")
    base = get_settings().dir_certificados
    fim = fim or date.today()
    if inicio is None:
        inicio = (conta.ultima_sincronizacao.date() - timedelta(days=3)) if conta.ultima_sincronizacao else fim - timedelta(days=30)
    import os
    import tempfile
    chave = base / cfg["chave"]
    temp = None
    if chave.name.endswith(".cifrada"):
        from app.seguranca import decifrar_bytes
        try:
            dado = decifrar_bytes(chave.read_bytes())
        except (OSError, ValueError) as exc:
            raise NegocioErro("Não consegui abrir o certificado do Inter. Envie o .zip de novo em “API Inter”.") from exc
        fd, temp = tempfile.mkstemp(suffix=".key")
        with os.fdopen(fd, "wb") as f:
            f.write(dado)
        chave = Path(temp)
    try:
        cli = ClienteInter(cfg["client_id"], decifrar(cfg["client_secret"]), base / cfg["certificado"], chave,
                           conta_corrente=cfg.get("conta_corrente"), transport=transport,
                           **({"base": cfg["base"]} if cfg.get("base") else {}))
    finally:
        if temp:
            os.unlink(temp)                # o httpx já carregou a chave na memória
    try:
        trans = cli.extrato(inicio, fim)
        try:
            saldo = cli.saldo()
        except InterErro:
            saldo = None
    except InterErro as exc:
        raise NegocioErro(str(exc)) from exc
    finally:
        cli.fechar()
    r = importar(session, conta, trans, "api_inter", usuario_id, arquivo=f"API Inter {inicio:%d/%m/%Y} a {fim:%d/%m/%Y}",
                 saldo=saldo, data_saldo=date.today() if saldo is not None else None)
    conta.ultima_sincronizacao = datetime.now(timezone.utc)
    session.flush()
    return r


def configurar_inter(session: Session, conta: ContaBancaria, usuario_id: int | None, client_id: str,
                     client_secret: str | None, cert_conteudo: bytes | None, cert_nome: str | None,
                     conta_corrente: str | None = None) -> None:
    from app.bancos.inter import InterErro, extrair_certificado
    from app.config import get_settings
    from app.seguranca import cifrar
    cfg = dict(conta.integracao_config or {})
    if not client_id.strip():
        raise NegocioErro("Informe o Client ID.")
    if not client_secret and not cfg.get("client_secret"):
        raise NegocioErro("Informe o Client Secret.")
    rel = Path(f"empresa_{conta.empresa_id}") / f"conta_{conta.id}"
    if cert_conteudo:
        try:
            extrair_certificado(cert_conteudo, cert_nome or "certificado.zip", get_settings().dir_certificados / rel)
        except InterErro as exc:
            raise NegocioErro(str(exc)) from exc
        cfg["certificado"], cfg["chave"] = str(rel / "certificado.crt"), str(rel / "chave.key.cifrada")
    elif not cfg.get("certificado"):
        raise NegocioErro("Envie o certificado (.zip) que o Inter gerou para a integração.")
    cfg["client_id"] = client_id.strip()
    if client_secret:
        cfg["client_secret"] = cifrar(client_secret.strip())
    cfg["conta_corrente"] = (conta_corrente or "").strip() or None
    conta.integracao, conta.integracao_config = "inter", cfg
    auditar(session, conta.empresa_id, usuario_id, "conta", conta.id, "configurar_inter",
            {"client_id": cfg["client_id"], "conta": conta.nome, "certificado_novo": bool(cert_conteudo)})
    session.flush()


# ============================================================================ regras

def regra_para(session: Session, m: Movimento, regras: list[RegraClassificacao] | None = None) -> RegraClassificacao | None:
    if regras is None:
        regras = list(session.scalars(select(RegraClassificacao).where(
            RegraClassificacao.empresa_id == m.empresa_id, RegraClassificacao.ativo.is_(True))))
    desc = normalizar(m.descricao)
    cands = [r for r in regras if r.natureza in ("*", m.natureza) and normalizar(r.texto) and normalizar(r.texto) in desc]
    return min(cands, key=lambda r: (r.prioridade, -len(r.texto), r.id), default=None)


def sugestao(session: Session, m: Movimento, regras=None, contatos=None) -> dict[str, Any]:
    """Classificação sugerida para um movimento sem lançamento: regra; senão o contato cujo nome aparece."""
    r = regra_para(session, m, regras)
    if r:
        return {"categoria_id": r.categoria_id, "centro_custo_id": r.centro_custo_id, "contato_id": r.contato_id,
                "origem": "regra", "regra_id": r.id, "regra_texto": r.texto}
    desc = normalizar(m.descricao)
    if contatos is None:
        contatos = session.scalars(select(Contato).where(Contato.empresa_id == m.empresa_id, Contato.ativo.is_(True))).all()
    doc = (m.dados_brutos or {}).get("cpf_cnpj")
    if doc:                                   # o extrato trouxe o CPF/CNPJ: é o jeito mais seguro de achar o cadastro
        c = next((c for c in contatos if c.documento and c.documento == doc), None)
        if c:
            return {"categoria_id": c.categoria_padrao_id, "centro_custo_id": c.centro_custo_padrao_id, "contato_id": c.id,
                    "origem": "contato", "regra_id": None, "regra_texto": None}
    achados = [c for c in contatos if len(normalizar(c.nome)) >= 5 and normalizar(c.nome) in desc]
    if achados:
        c = max(achados, key=lambda c: len(c.nome))
        return {"categoria_id": c.categoria_padrao_id, "centro_custo_id": c.centro_custo_padrao_id, "contato_id": c.id,
                "origem": "contato", "regra_id": None, "regra_texto": None}
    return {"categoria_id": None, "centro_custo_id": None, "contato_id": None, "origem": None,
            "regra_id": None, "regra_texto": None}


# ============================================================================ conciliação

def candidatos(session: Session, m: Movimento, limite: int = 8) -> list[Lancamento]:
    """Lançamentos em aberto que podem ser este movimento: mesmo sentido, valor que falta igual ao
    movimento (ou maior, para baixa parcial), vencimento próximo."""
    tipo = "receber" if m.natureza == "C" else "pagar"
    ls = session.scalars(select(Lancamento).where(
        Lancamento.empresa_id == m.empresa_id, Lancamento.tipo == tipo, Lancamento.situacao.in_(("aberto", "parcial")),
        Lancamento.vencimento.between(m.data - timedelta(days=60), m.data + timedelta(days=60)))).all()
    exatos = [l for l in ls if abs(svc_l.restante(l) - m.valor) <= Decimal("0.01")]
    exatos.sort(key=lambda l: (abs((l.vencimento - m.data).days), l.id))
    return exatos[:limite]


def conciliar(session: Session, m: Movimento, lancamento: Lancamento, usuario_id: int | None) -> Baixa:
    if m.situacao != "pendente":
        raise NegocioErro("Este movimento já foi conciliado ou ignorado.")
    if lancamento.empresa_id != m.empresa_id:
        raise NegocioErro("Lançamento de outra empresa.")
    if (lancamento.tipo == "receber") != (m.natureza == "C"):
        raise NegocioErro("Entrada no extrato só concilia com recebimento, e saída com pagamento.")
    falta = svc_l.restante(lancamento)
    valor = min(falta, m.valor)
    juros = m.valor - valor if m.valor > falta else Decimal("0")
    return svc_l.baixar(session, lancamento, usuario_id, m.data, valor, m.conta_bancaria_id, juros=juros, movimento=m)


def lancar_do_movimento(session: Session, m: Movimento, usuario_id: int | None, d: dict[str, Any]) -> Lancamento:
    """Cria o lançamento já pago a partir do movimento (ex.: tarifa, pagamento sem conta a pagar).
    d: categoria_id, centro_custo_id?, contato_id?, descricao?, criar_regra (texto)?"""
    if m.situacao != "pendente":
        raise NegocioErro("Este movimento já foi conciliado ou ignorado.")
    if not d.get("categoria_id"):
        raise NegocioErro("Escolha a categoria.")
    l = svc_l.criar(session, m.empresa_id, usuario_id, {
        "tipo": "receber" if m.natureza == "C" else "pagar",
        "descricao": (d.get("descricao") or m.descricao)[:300], "valor": m.valor, "vencimento": m.data,
        "competencia": m.data, "categoria_id": d["categoria_id"], "centro_custo_id": d.get("centro_custo_id"),
        "contato_id": d.get("contato_id"), "conta_bancaria_id": m.conta_bancaria_id, "documento": m.documento})[0]
    svc_l.baixar(session, l, usuario_id, m.data, m.valor, m.conta_bancaria_id, movimento=m)
    regra_id = d.get("regra_id")
    if regra_id:
        r = session.get(RegraClassificacao, regra_id)
        if r and r.empresa_id == m.empresa_id:
            r.vezes_usada += 1
    if (d.get("criar_regra") or "").strip():
        session.add(RegraClassificacao(empresa_id=m.empresa_id, texto=d["criar_regra"].strip()[:120], natureza=m.natureza,
                                       categoria_id=d["categoria_id"], centro_custo_id=d.get("centro_custo_id"),
                                       contato_id=d.get("contato_id"), vezes_usada=1))
    session.flush()
    return l


def ignorar(session: Session, m: Movimento, usuario_id: int | None) -> None:
    if m.situacao == "conciliado":
        raise NegocioErro("Movimento conciliado: desfaça a conciliação antes.")
    m.situacao = "ignorado"
    auditar(session, m.empresa_id, usuario_id, "movimento", m.id, "ignorar", {"descricao": m.descricao, "valor": m.valor})
    session.flush()


def desfazer(session: Session, m: Movimento, usuario_id: int | None) -> None:
    """Volta o movimento para pendente: estorna as baixas ligadas a ele e solta a transferência."""
    for b in list(session.scalars(select(Baixa).where(Baixa.movimento_id == m.id))):
        svc_l.estornar_baixa(session, b, usuario_id)
    if m.transferencia_id:
        from app.models import Transferencia
        from app.servicos.financeiro import excluir_transferencia
        t = session.get(Transferencia, m.transferencia_id)
        if t:
            excluir_transferencia(session, t, usuario_id)
    m.situacao, m.transferencia_id = "pendente", None
    session.flush()


def conciliar_automatico(session: Session, empresa_id: int, ids: list[int] | None = None) -> dict[str, int]:
    """Concilia sozinho o que é inequívoco: o movimento tem um único lançamento compatível (vencimento até
    10 dias) e esse lançamento só combina com ele. Também liga baixas manuais que ainda não têm extrato."""
    q = select(Movimento).where(Movimento.empresa_id == empresa_id, Movimento.situacao == "pendente")
    if ids is not None:
        if not ids:
            return {"conciliados_auto": 0, "baixas_ligadas": 0}
        q = q.where(Movimento.id.in_(ids))
    movs = list(session.scalars(q.order_by(Movimento.data, Movimento.id)))
    ligadas = 0
    # 1) baixa feita à mão (sem extrato) com mesma conta, valor e data próxima
    soltas = list(session.scalars(select(Baixa).join(Lancamento).where(Baixa.empresa_id == empresa_id, Baixa.movimento_id.is_(None))))
    for m in movs:
        cands = [b for b in soltas if b.conta_bancaria_id == m.conta_bancaria_id and abs((b.data - m.data).days) <= 3
                 and b.valor_caixa == m.valor and (b.lancamento.tipo == "receber") == (m.natureza == "C")]
        if len(cands) == 1:
            cands[0].movimento_id, m.situacao = m.id, "conciliado"
            soltas.remove(cands[0])
            ligadas += 1
    # 2) lançamento em aberto com o mesmo valor e vencimento próximo, sem ambiguidade dos dois lados
    pend = [m for m in movs if m.situacao == "pendente"]
    por_mov = {m.id: [l for l in candidatos(session, m) if abs((l.vencimento - m.data).days) <= JANELA_DIAS] for m in pend}
    uso = Counter(l.id for ls in por_mov.values() for l in ls)
    feitos = 0
    for m in pend:
        ls = por_mov[m.id]
        if len(ls) == 1 and uso[ls[0].id] == 1:
            conciliar(session, m, ls[0], None)
            feitos += 1
    session.flush()
    return {"conciliados_auto": feitos, "baixas_ligadas": ligadas}


def lancar_sugeridos(session: Session, empresa_id: int, usuario_id: int | None, ids: list[int] | None = None) -> dict[str, int]:
    """Lança de uma vez os movimentos pendentes que têm regra de classificação."""
    regras = list(session.scalars(select(RegraClassificacao).where(
        RegraClassificacao.empresa_id == empresa_id, RegraClassificacao.ativo.is_(True))))
    q = select(Movimento).where(Movimento.empresa_id == empresa_id, Movimento.situacao == "pendente")
    if ids:
        q = q.where(Movimento.id.in_(ids))
    feitos = sem = 0
    for m in session.scalars(q.order_by(Movimento.data)):
        r = regra_para(session, m, regras)
        cat = session.get(Categoria, r.categoria_id) if r and r.categoria_id else None
        if not cat:
            sem += 1
            continue
        lancar_do_movimento(session, m, usuario_id, {"categoria_id": cat.id, "centro_custo_id": r.centro_custo_id,
                                                     "contato_id": r.contato_id, "regra_id": r.id})
        feitos += 1
    return {"lancados": feitos, "sem_regra": sem}
