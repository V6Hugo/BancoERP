"""Regras de negócio. As rotas da API só validam a entrada e chamam estas funções."""
from __future__ import annotations

import re
import unicodedata
from calendar import monthrange
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from sqlalchemy.orm import Session

from app.models import Auditoria

CENTAVO = Decimal("0.01")
ZERO = Decimal("0.00")


class NegocioErro(ValueError):
    """Erro de regra de negócio, com mensagem para o usuário."""


def dinheiro(v: Any) -> Decimal:
    if v is None or v == "":
        return ZERO
    if isinstance(v, str):
        v = v.strip().replace("R$", "").replace(" ", "")
        if "," in v:
            v = v.replace(".", "").replace(",", ".")
    return Decimal(str(v)).quantize(CENTAVO, rounding=ROUND_HALF_UP)


def mais_meses(d: date, n: int) -> date:
    """Mesmo dia n meses depois (31/01 + 1 mês = 28 ou 29/02)."""
    m = d.month - 1 + n
    a, m = d.year + m // 12, m % 12 + 1
    return date(a, m, min(d.day, monthrange(a, m)[1]))


def normalizar(t: str | None) -> str:
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().upper()
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9]+", " ", t)).strip()


def auditar(session: Session, empresa_id: int | None, usuario_id: int | None, entidade: str,
            entidade_id: int | None, acao: str, dados: dict[str, Any] | None = None) -> None:
    session.add(Auditoria(empresa_id=empresa_id, usuario_id=usuario_id, entidade=entidade,
                          entidade_id=entidade_id, acao=acao, dados=_json(dados or {})))


def _json(v: Any) -> Any:
    if isinstance(v, dict):
        return {k: _json(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_json(x) for x in v]
    if isinstance(v, (Decimal, date)):
        return str(v)
    return v
