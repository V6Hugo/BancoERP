"""Recebimentos e pagamentos: criação (com parcelas ou recorrência), baixa, estorno, cancelamento."""
from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Baixa, Categoria, CentroCusto, ContaBancaria, Contato, Lancamento, Movimento
from app.servicos import CENTAVO, ZERO, NegocioErro, auditar, dinheiro, mais_meses

CAMPOS_EDITAVEIS = ("descricao", "contato_id", "categoria_id", "centro_custo_id", "conta_bancaria_id", "valor",
                    "competencia", "vencimento", "documento", "forma_pagamento", "observacao")


def restante(l: Lancamento) -> Decimal:
    return (l.valor - sum((b.valor for b in l.baixas), ZERO)).quantize(CENTAVO)


def recalcular(l: Lancamento) -> None:
    if l.situacao == "cancelado":
        return
    pago = sum((b.valor for b in l.baixas), ZERO)
    l.situacao = "aberto" if pago <= 0 else ("pago" if pago >= l.valor else "parcial")


def _validar_refs(session: Session, empresa_id: int, tipo: str, d: dict[str, Any]) -> None:
    """Tudo o que o lançamento aponta precisa ser da mesma empresa (e a categoria, do sentido certo)."""
    if d.get("categoria_id"):
        c = session.get(Categoria, d["categoria_id"])
        if not c or c.empresa_id != empresa_id:
            raise NegocioErro("Categoria não encontrada nesta empresa.")
        if session.scalar(select(Categoria.id).where(Categoria.pai_id == c.id).limit(1)):
            raise NegocioErro(f"“{c.nome}” é um grupo. Escolha uma categoria dentro dele.")
        if (tipo == "receber" and c.natureza == "despesa") or (tipo == "pagar" and c.natureza == "receita"):
            raise NegocioErro(f"A categoria “{c.nome}” é de {c.natureza} e não combina com "
                              f"{'um recebimento' if tipo == 'receber' else 'um pagamento'}.")
    for campo, modelo, nome in (("contato_id", Contato, "Cliente/fornecedor"), ("centro_custo_id", CentroCusto, "Centro de custo"),
                                ("conta_bancaria_id", ContaBancaria, "Conta bancária")):
        if d.get(campo):
            obj = session.get(modelo, d[campo])
            if not obj or obj.empresa_id != empresa_id:
                raise NegocioErro(f"{nome} não encontrado nesta empresa.")


def criar(session: Session, empresa_id: int, usuario_id: int | None, d: dict[str, Any]) -> list[Lancamento]:
    """d: tipo, descricao, valor, vencimento, competencia?, contato_id?, categoria_id?, centro_custo_id?,
    conta_bancaria_id?, documento?, forma_pagamento?, observacao?,
    parcelas (n>1 divide o valor), repetir_meses (n>1 repete o valor todo mês), pago_em (já baixa)."""
    tipo = d.get("tipo")
    if tipo not in ("receber", "pagar"):
        raise NegocioErro("Tipo deve ser receber ou pagar.")
    descricao = (d.get("descricao") or "").strip()
    if not descricao:
        raise NegocioErro("Informe a descrição.")
    valor = dinheiro(d.get("valor"))
    if valor <= 0:
        raise NegocioErro("O valor precisa ser maior que zero.")
    venc: date = d["vencimento"]
    _validar_refs(session, empresa_id, tipo, d)
    parcelas = max(1, int(d.get("parcelas") or 1))
    repetir = max(1, int(d.get("repetir_meses") or 1))
    if parcelas > 1 and repetir > 1:
        raise NegocioErro("Use parcelas ou repetição mensal, não os dois.")
    if parcelas > 120 or repetir > 120:
        raise NegocioErro("No máximo 120 parcelas ou repetições.")

    if parcelas > 1:
        base = (valor / parcelas).quantize(CENTAVO, rounding="ROUND_DOWN")
        valores = [base] * parcelas
        valores[-1] += valor - base * parcelas            # centavos na última parcela
    else:
        valores = [valor] * repetir
    n = len(valores)
    grupo = str(uuid.uuid4()) if n > 1 else None
    comp0: date = d.get("competencia") or venc
    criados = []
    for i, v in enumerate(valores):
        l = Lancamento(
            empresa_id=empresa_id, tipo=tipo, valor=v, vencimento=mais_meses(venc, i),
            competencia=mais_meses(comp0, i) if repetir > 1 else comp0,
            descricao=descricao + (f" ({i + 1}/{n})" if parcelas > 1 else ""),
            parcela=i + 1 if parcelas > 1 else 1, total_parcelas=parcelas,
            grupo_parcelas=grupo, recorrente=repetir > 1, criado_por=usuario_id,
            **{k: d.get(k) for k in ("contato_id", "categoria_id", "centro_custo_id", "conta_bancaria_id",
                                     "documento", "forma_pagamento", "observacao")})
        session.add(l)
        criados.append(l)
    session.flush()
    if d.get("pago_em"):
        if not d.get("conta_bancaria_id"):
            raise NegocioErro("Para lançar já pago, informe a conta bancária.")
        baixar(session, criados[0], usuario_id, d["pago_em"], criados[0].valor, d["conta_bancaria_id"])
    for l in criados:
        auditar(session, empresa_id, usuario_id, "lancamento", l.id, "criar",
                {"tipo": tipo, "valor": l.valor, "vencimento": l.vencimento, "descricao": l.descricao})
    session.flush()
    return criados


def atualizar(session: Session, l: Lancamento, usuario_id: int | None, d: dict[str, Any]) -> Lancamento:
    if l.situacao == "cancelado":
        raise NegocioErro("Lançamento cancelado não pode ser alterado. Reative-o antes.")
    novos = {k: v for k, v in d.items() if k in CAMPOS_EDITAVEIS}
    _validar_refs(session, l.empresa_id, l.tipo, novos)
    if "valor" in novos:
        novos["valor"] = dinheiro(novos["valor"])
        if novos["valor"] <= 0:
            raise NegocioErro("O valor precisa ser maior que zero.")
        pago = l.valor - restante(l)
        if novos["valor"] < pago:
            raise NegocioErro(f"Já foram baixados R$ {pago:.2f}; o valor não pode ficar menor que isso.")
    if "descricao" in novos and not (novos["descricao"] or "").strip():
        raise NegocioErro("Informe a descrição.")
    antes = {k: getattr(l, k) for k in novos}
    for k, v in novos.items():
        setattr(l, k, v)
    recalcular(l)
    auditar(session, l.empresa_id, usuario_id, "lancamento", l.id, "alterar",
            {"antes": antes, "depois": novos})
    session.flush()
    return l


def baixar(session: Session, l: Lancamento, usuario_id: int | None, data: date, valor: Any, conta_bancaria_id: int,
           juros: Any = 0, desconto: Any = 0, movimento: Movimento | None = None) -> Baixa:
    """Registra o pagamento/recebimento (total ou parcial)."""
    if l.situacao == "cancelado":
        raise NegocioErro("Lançamento cancelado não pode ser baixado.")
    valor, juros, desconto = dinheiro(valor), dinheiro(juros), dinheiro(desconto)
    falta = restante(l)
    if valor <= 0:
        raise NegocioErro("O valor da baixa precisa ser maior que zero.")
    if valor > falta:
        raise NegocioErro(f"O valor (R$ {valor:.2f}) é maior que o que falta (R$ {falta:.2f}). "
                          "Lance a diferença como juros/multa.")
    if juros < 0 or desconto < 0:
        raise NegocioErro("Juros e desconto não podem ser negativos.")
    conta = session.get(ContaBancaria, conta_bancaria_id)
    if not conta or conta.empresa_id != l.empresa_id:
        raise NegocioErro("Conta bancária não encontrada nesta empresa.")
    b = Baixa(empresa_id=l.empresa_id, lancamento=l, conta_bancaria_id=conta.id, data=data, valor=valor,
              juros=juros, desconto=desconto, movimento_id=movimento.id if movimento else None,
              criado_por=usuario_id)
    session.add(b)
    if movimento is not None:
        movimento.situacao = "conciliado"
    session.flush()
    recalcular(l)
    auditar(session, l.empresa_id, usuario_id, "baixa", b.id, "baixar",
            {"lancamento_id": l.id, "valor": valor, "juros": juros, "desconto": desconto, "data": data})
    session.flush()
    return b


def estornar_baixa(session: Session, b: Baixa, usuario_id: int | None) -> None:
    l = b.lancamento
    if b.movimento_id:
        m = session.get(Movimento, b.movimento_id)
        if m is not None:
            m.situacao = "pendente"
    auditar(session, l.empresa_id, usuario_id, "baixa", b.id, "estornar",
            {"lancamento_id": l.id, "valor": b.valor, "data": b.data})
    l.baixas.remove(b)
    session.delete(b)
    session.flush()
    recalcular(l)
    session.flush()


def cancelar(session: Session, l: Lancamento, usuario_id: int | None) -> None:
    if l.baixas:
        raise NegocioErro("Este lançamento tem baixas. Estorne as baixas antes de cancelar.")
    l.situacao = "cancelado"
    auditar(session, l.empresa_id, usuario_id, "lancamento", l.id, "cancelar", {})
    session.flush()


def reativar(session: Session, l: Lancamento, usuario_id: int | None) -> None:
    l.situacao = "aberto"
    recalcular(l)
    auditar(session, l.empresa_id, usuario_id, "lancamento", l.id, "reativar", {})
    session.flush()


def excluir(session: Session, l: Lancamento, usuario_id: int | None) -> None:
    if l.baixas:
        raise NegocioErro("Este lançamento tem baixas. Estorne as baixas antes de excluir.")
    auditar(session, l.empresa_id, usuario_id, "lancamento", l.id, "excluir",
            {"descricao": l.descricao, "valor": l.valor, "vencimento": l.vencimento})
    session.delete(l)
    session.flush()
