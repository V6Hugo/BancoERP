"""Relatórios financeiros: resumo do período, DRE gerencial, comparativo entre meses e detalhamento.

Regime de caixa: o que foi pago/recebido no período (baixas). Regime de competência: os lançamentos
pelo mês de competência (não cancelados), pagos ou não."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Baixa, Categoria, CentroCusto, Contato, Lancamento, Movimento
from app.plano_padrao import LINHAS_DRE, NOMES_DRE, SUBTOTAIS_DRE
from app.servicos import ZERO
from app.servicos.financeiro import saldos
from app.servicos.lancamentos import restante

SEM = {"categoria": "Sem categoria", "centro_custo": "Sem centro de custo", "contato": "Sem cliente/fornecedor"}


def meses_entre(inicio: date, fim: date) -> list[str]:
    out, d = [], inicio.replace(day=1)
    while d <= fim:
        out.append(d.strftime("%Y-%m"))
        d = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
    return out


def fatos(session: Session, empresa_id: int, inicio: date, fim: date, regime: str = "caixa") -> list[dict[str, Any]]:
    """Linhas de valor (cada uma com mês, tipo, categoria, centro de custo, contato e valor) no período.
    Caixa: baixas; juros e descontos das baixas viram linhas financeiras próprias."""
    out: list[dict[str, Any]] = []
    if regime == "competencia":
        for l in session.scalars(select(Lancamento).where(
                Lancamento.empresa_id == empresa_id, Lancamento.situacao != "cancelado",
                Lancamento.competencia.between(inicio, fim))):
            out.append({"data": l.competencia, "tipo": l.tipo, "valor": l.valor, "categoria_id": l.categoria_id,
                        "centro_custo_id": l.centro_custo_id, "contato_id": l.contato_id, "lancamento_id": l.id,
                        "descricao": l.descricao, "extra": None})
        return out
    q = select(Baixa, Lancamento).join(Lancamento).where(Baixa.empresa_id == empresa_id, Baixa.data.between(inicio, fim))
    for b, l in session.execute(q):
        base = {"data": b.data, "tipo": l.tipo, "centro_custo_id": l.centro_custo_id, "contato_id": l.contato_id,
                "lancamento_id": l.id, "descricao": l.descricao}
        out.append({**base, "valor": b.valor, "categoria_id": l.categoria_id, "extra": None})
        if b.juros:
            out.append({**base, "valor": b.juros, "categoria_id": None,
                        "extra": "juros_recebidos" if l.tipo == "receber" else "juros_pagos"})
        if b.desconto:
            out.append({**base, "valor": b.desconto, "categoria_id": None,
                        "extra": "desconto_concedido" if l.tipo == "receber" else "desconto_obtido"})
    return out


# juros e descontos nas baixas: em que linha do DRE entram e com que sinal no "valor da linha"
EXTRAS = {
    "juros_recebidos": ("receitas_financeiras", "Juros e multas recebidos (nas baixas)", 1),
    "juros_pagos": ("despesas_financeiras", "Juros e multas pagos (nas baixas)", 1),
    "desconto_obtido": ("receitas_financeiras", "Descontos obtidos (nas baixas)", 1),
    "desconto_concedido": ("deducoes", "Descontos concedidos (nas baixas)", 1),
}


def _categorias(session: Session, empresa_id: int) -> dict[int, Categoria]:
    return {c.id: c for c in session.scalars(select(Categoria).where(Categoria.empresa_id == empresa_id))}


def _grupo_do_fato(f: dict[str, Any], cats: dict[int, Categoria]) -> tuple[str, str, str]:
    """(grupo_dre, chave da linha, nome da linha)"""
    if f["extra"]:
        g, nome, _ = EXTRAS[f["extra"]]
        return g, f"x:{f['extra']}", nome
    c = cats.get(f["categoria_id"])
    if c is None:
        return ("receita_bruta" if f["tipo"] == "receber" else "despesas_operacionais"), \
            f"sem:{f['tipo']}", "Sem categoria (" + ("recebimentos" if f["tipo"] == "receber" else "pagamentos") + ")"
    return c.grupo_dre, f"c:{c.id}", f"{c.codigo} {c.nome}"


def dre(session: Session, empresa_id: int, inicio: date, fim: date, regime: str = "caixa") -> dict[str, Any]:
    meses = meses_entre(inicio, fim)
    cats = _categorias(session, empresa_id)
    grupos: dict[str, dict[str, Any]] = {g: {"grupo": g, "nome": NOMES_DRE[g], "itens": {}, "valores": defaultdict(lambda: ZERO)}
                                          for g, _, _ in LINHAS_DRE}
    for f in fatos(session, empresa_id, inicio, fim, regime):
        g, chave, nome = _grupo_do_fato(f, cats)
        # entrada em grupo de despesa (ex.: estorno de despesa) reduz o grupo, e vice-versa
        sinal_natural = 1 if g in ("receita_bruta", "receitas_financeiras") else -1
        mov = Decimal(1) if f["tipo"] == "receber" else Decimal(-1)
        if f["extra"]:
            mov = Decimal(sinal_natural)
        v = f["valor"] * mov * sinal_natural            # valor positivo = "no sentido da linha"
        it = grupos[g]["itens"].setdefault(chave, {"chave": chave, "nome": nome, "valores": defaultdict(lambda: ZERO)})
        m = f["data"].strftime("%Y-%m")
        it["valores"][m] += v
        grupos[g]["valores"][m] += v
    sinais = {g: s for g, _, s in LINHAS_DRE}
    linhas = []
    for g, _, _ in LINHAS_DRE:
        G = grupos[g]
        itens = sorted(G["itens"].values(), key=lambda i: i["nome"])
        linhas.append({"tipo": "grupo", "grupo": g, "nome": G["nome"],
                       "valores": {m: G["valores"][m] for m in meses}, "total": sum(G["valores"].values(), ZERO),
                       "itens": [{"chave": i["chave"], "nome": i["nome"], "valores": {m: i["valores"][m] for m in meses},
                                  "total": sum(i["valores"].values(), ZERO)} for i in itens]})
        for depois_de, nome, comp in SUBTOTAIS_DRE:
            if depois_de == g:
                vals = {m: sum((grupos[x]["valores"][m] * sinais[x] for x in comp), ZERO) for m in meses}
                linhas.append({"tipo": "subtotal", "nome": nome, "valores": vals, "total": sum(vals.values(), ZERO)})
    rb = {m: grupos["receita_bruta"]["valores"][m] for m in meses}
    res = next(x for x in linhas if x["tipo"] == "subtotal" and x["nome"] == "Resultado líquido")
    margem = {m: (res["valores"][m] / rb[m] * 100).quantize(Decimal("0.1")) if rb[m] else None for m in meses}
    return {"regime": regime, "meses": meses, "linhas": linhas, "margem_liquida": margem}


def resumo(session: Session, empresa_id: int, inicio: date, fim: date, hoje: date | None = None) -> dict[str, Any]:
    hoje = hoje or date.today()
    ent = sai = ZERO
    for f in fatos(session, empresa_id, inicio, fim, "caixa"):
        x = -f["valor"] if f["extra"] in ("desconto_concedido", "desconto_obtido") else f["valor"]
        if f["tipo"] == "receber":
            ent += x
        else:
            sai += x
    abertos = session.scalars(select(Lancamento).where(Lancamento.empresa_id == empresa_id,
                                                       Lancamento.situacao.in_(("aberto", "parcial")))).all()
    def soma(tipo, cond):
        return sum((restante(l) for l in abertos if l.tipo == tipo and cond(l)), ZERO)
    s = saldos(session, empresa_id)
    pend = session.scalar(select(func.count(Movimento.id)).where(Movimento.empresa_id == empresa_id,
                                                                 Movimento.situacao == "pendente")) or 0
    return {
        "periodo": [inicio, fim], "entradas": ent, "saidas": sai, "resultado": ent - sai,
        "saldo_disponivel": s["total_disponivel"],
        "a_receber": soma("receber", lambda l: True), "a_pagar": soma("pagar", lambda l: True),
        "receber_vencido": soma("receber", lambda l: l.vencimento < hoje),
        "pagar_vencido": soma("pagar", lambda l: l.vencimento < hoje),
        "receber_7d": soma("receber", lambda l: hoje <= l.vencimento <= hoje + timedelta(days=7)),
        "pagar_7d": soma("pagar", lambda l: hoje <= l.vencimento <= hoje + timedelta(days=7)),
        "pendentes_conciliar": pend,
    }


def serie_mensal(session: Session, empresa_id: int, inicio: date, fim: date, regime: str = "caixa") -> list[dict[str, Any]]:
    meses = meses_entre(inicio, fim)
    v = {m: {"mes": m, "entradas": ZERO, "saidas": ZERO} for m in meses}
    for f in fatos(session, empresa_id, inicio, fim, regime):
        m = f["data"].strftime("%Y-%m")
        x = f["valor"]
        if f["extra"] in ("desconto_concedido", "desconto_obtido"):
            x = -x
        v[m]["entradas" if f["tipo"] == "receber" else "saidas"] += x
    for m in meses:
        v[m]["resultado"] = v[m]["entradas"] - v[m]["saidas"]
    return [v[m] for m in meses]


def comparativo(session: Session, empresa_id: int, meses: list[str], dimensao: str = "categoria", tipo: str = "pagar",
                regime: str = "caixa") -> dict[str, Any]:
    """Valores por categoria / centro de custo / cliente-fornecedor / grupo do DRE em cada mês escolhido,
    com a variação de cada mês para o anterior."""
    if not meses:
        return {"meses": [], "linhas": [], "totais": {}}
    meses = sorted(set(meses))
    ini = date.fromisoformat(meses[0] + "-01")
    ult = date.fromisoformat(meses[-1] + "-01")
    fim = (ult.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    cats = _categorias(session, empresa_id)
    ccs = {c.id: c for c in session.scalars(select(CentroCusto).where(CentroCusto.empresa_id == empresa_id))}
    nomes_contato: dict[int, str] = {}
    vals: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(lambda: ZERO))
    rotulos: dict[str, str] = {}
    for f in fatos(session, empresa_id, ini, fim, regime):
        m = f["data"].strftime("%Y-%m")
        if m not in meses or (tipo != "ambos" and f["tipo"] != tipo):
            continue
        if dimensao == "categoria":
            c = cats.get(f["categoria_id"])
            chave, nome = (f"c:{c.id}", f"{c.codigo} {c.nome}") if c else ((f"x:{f['extra']}", EXTRAS[f["extra"]][1]) if f["extra"] else ("-", SEM["categoria"]))
        elif dimensao == "grupo":
            g, _, _ = _grupo_do_fato(f, cats)
            chave, nome = g, NOMES_DRE[g]
        elif dimensao == "centro_custo":
            c = ccs.get(f["centro_custo_id"])
            chave, nome = (f"cc:{c.id}", f"{c.codigo} {c.nome}") if c else ("-", SEM["centro_custo"])
        else:
            cid = f["contato_id"]
            if cid and cid not in nomes_contato:
                ct = session.get(Contato, cid)
                nomes_contato[cid] = ct.nome if ct else "?"
            chave, nome = (f"ct:{cid}", nomes_contato[cid]) if cid else ("-", SEM["contato"])
        x = f["valor"]
        if tipo == "ambos":
            x = x if f["tipo"] == "receber" else -x
        if f["extra"] in ("desconto_concedido", "desconto_obtido"):
            x = -x
        vals[chave][m] += x
        rotulos[chave] = nome
    linhas = []
    for chave, por_mes in vals.items():
        serie = [por_mes[m] for m in meses]
        var = []
        for i, v in enumerate(serie):
            if i == 0:
                var.append(None)
                continue
            ant = serie[i - 1]
            var.append({"abs": v - ant, "pct": ((v - ant) / abs(ant) * 100).quantize(Decimal("0.1")) if ant else None})
        linhas.append({"chave": chave, "nome": rotulos[chave], "valores": dict(zip(meses, serie)), "variacao": dict(zip(meses, var)),
                       "total": sum(serie, ZERO)})
    linhas.sort(key=lambda x: -abs(x["total"]))
    totais = {m: sum((l["valores"][m] for l in linhas), ZERO) for m in meses}
    return {"meses": meses, "dimensao": dimensao, "tipo": tipo, "regime": regime, "linhas": linhas, "totais": totais}


def detalhe(session: Session, empresa_id: int, inicio: date, fim: date, regime: str = "caixa", tipo: str | None = None,
            categoria_id: int | None = None, centro_custo_id: int | None = None, contato_id: int | None = None,
            chave: str | None = None, dimensao: str | None = None, limite: int = 500) -> list[dict[str, Any]]:
    """Lançamentos que formam um número do relatório (clique no gráfico ou na tabela)."""
    cats = _categorias(session, empresa_id)
    out = []
    for f in fatos(session, empresa_id, inicio, fim, regime):
        if tipo and f["tipo"] != tipo:
            continue
        if categoria_id and f["categoria_id"] != categoria_id:
            continue
        if centro_custo_id and f["centro_custo_id"] != centro_custo_id:
            continue
        if contato_id and f["contato_id"] != contato_id:
            continue
        if chave and not _casa_chave(chave, f, cats, dimensao):
            continue
        c = cats.get(f["categoria_id"])
        out.append({"data": f["data"], "tipo": f["tipo"], "descricao": f["descricao"] + (f" — {EXTRAS[f['extra']][1]}" if f["extra"] else ""),
                    "valor": f["valor"], "categoria": f"{c.codigo} {c.nome}" if c else None, "lancamento_id": f["lancamento_id"]})
    out.sort(key=lambda x: (x["data"], x["lancamento_id"]))
    return out[:limite]


def _casa_chave(ch: str, f: dict[str, Any], cats: dict[int, Categoria], dimensao: str | None = None) -> bool:
    """A chave de uma linha de relatório (categoria, centro de custo, contato, grupo do DRE) inclui este fato?"""
    if ch.startswith("cc:"):
        return f"cc:{f['centro_custo_id']}" == ch
    if ch.startswith("ct:"):
        return f"ct:{f['contato_id']}" == ch
    if ch.startswith(("c:", "x:", "sem:")):
        return _grupo_do_fato(f, cats)[1] == ch
    if ch in NOMES_DRE:
        return _grupo_do_fato(f, cats)[0] == ch
    if ch == "-":                       # linha "sem ..." do comparativo
        campo = {"categoria": "categoria_id", "centro_custo": "centro_custo_id", "contato": "contato_id"}.get(dimensao or "")
        return campo is None or (f[campo] is None and not f["extra"])
    return True
