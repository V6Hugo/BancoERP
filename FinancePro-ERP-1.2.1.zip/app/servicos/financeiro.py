"""Saldos das contas, fluxo de caixa (realizado e previsto) e transferências entre contas."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Baixa, ContaBancaria, Lancamento, Movimento, Transferencia
from app.servicos import ZERO, NegocioErro, auditar, dinheiro

CONTAS_DE_CAIXA = ("corrente", "poupanca", "investimento", "caixa")      # cartão fica fora do saldo disponível


def _depois_do_inicial(col, conta: ContaBancaria):
    return col > conta.data_saldo_inicial if conta.data_saldo_inicial else True


def saldo_conta(session: Session, conta: ContaBancaria, ate: date | None = None) -> dict[str, Decimal]:
    """Saldo pelo sistema (baixas e transferências) e pelo extrato (movimentos importados)."""
    def soma(q):
        return session.scalar(q) or ZERO
    lim = (lambda col: col <= ate) if ate else (lambda col: True)
    rec = soma(select(func.sum(Baixa.valor + Baixa.juros - Baixa.desconto)).join(Lancamento).where(
        Baixa.conta_bancaria_id == conta.id, Lancamento.tipo == "receber",
        _depois_do_inicial(Baixa.data, conta), lim(Baixa.data)))
    pag = soma(select(func.sum(Baixa.valor + Baixa.juros - Baixa.desconto)).join(Lancamento).where(
        Baixa.conta_bancaria_id == conta.id, Lancamento.tipo == "pagar",
        _depois_do_inicial(Baixa.data, conta), lim(Baixa.data)))
    t_in = soma(select(func.sum(Transferencia.valor)).where(
        Transferencia.conta_destino_id == conta.id, _depois_do_inicial(Transferencia.data, conta), lim(Transferencia.data)))
    t_out = soma(select(func.sum(Transferencia.valor)).where(
        Transferencia.conta_origem_id == conta.id, _depois_do_inicial(Transferencia.data, conta), lim(Transferencia.data)))
    m_c = soma(select(func.sum(Movimento.valor)).where(
        Movimento.conta_bancaria_id == conta.id, Movimento.natureza == "C", _depois_do_inicial(Movimento.data, conta), lim(Movimento.data)))
    m_d = soma(select(func.sum(Movimento.valor)).where(
        Movimento.conta_bancaria_id == conta.id, Movimento.natureza == "D", _depois_do_inicial(Movimento.data, conta), lim(Movimento.data)))
    tem_extrato = session.scalar(select(func.count(Movimento.id)).where(Movimento.conta_bancaria_id == conta.id)) or 0
    sistema = conta.saldo_inicial + rec - pag + t_in - t_out
    extrato = conta.saldo_inicial + m_c - m_d
    return {"saldo": sistema, "entradas": rec + t_in, "saidas": pag + t_out,
            "saldo_extrato": extrato if tem_extrato else None,
            "diferenca": (extrato - sistema) if tem_extrato else None}


def saldos(session: Session, empresa_id: int, ate: date | None = None) -> dict[str, Any]:
    contas = session.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == empresa_id)
                             .order_by(ContaBancaria.nome)).all()
    linhas, total = [], ZERO
    pend = dict(session.execute(select(Movimento.conta_bancaria_id, func.count()).where(
        Movimento.empresa_id == empresa_id, Movimento.situacao == "pendente").group_by(Movimento.conta_bancaria_id)).all())
    from app.models import ImportacaoExtrato
    ult: dict[int, Any] = {}
    for i in session.scalars(select(ImportacaoExtrato).where(ImportacaoExtrato.empresa_id == empresa_id,
                                                             ImportacaoExtrato.saldo_banco.is_not(None))
                             .order_by(ImportacaoExtrato.data_saldo_banco, ImportacaoExtrato.id)):
        ult[i.conta_bancaria_id] = i
    for c in contas:
        s = saldo_conta(session, c, ate)
        imp = ult.get(c.id)
        s["saldo_banco"] = imp.saldo_banco if imp else None
        s["data_saldo_banco"] = imp.data_saldo_banco if imp else None
        # o saldo do sistema no mesmo dia do saldo informado pelo banco, para comparar maçã com maçã
        s["saldo_sistema_na_data"] = (saldo_conta(session, c, imp.data_saldo_banco)["saldo"]
                                      if imp and imp.data_saldo_banco else None)
        if c.ativo and c.tipo in CONTAS_DE_CAIXA:
            total += s["saldo"]
        linhas.append({"conta_id": c.id, "nome": c.nome, "tipo": c.tipo, "banco_codigo": c.banco_codigo,
                       "ativo": c.ativo, "integracao": c.integracao, "ultima_sincronizacao": c.ultima_sincronizacao,
                       "banco_conectado": (c.integracao_config or {}).get("banco") if c.integracao == "openfinance" else None,
                       "agencia": c.agencia, "numero": c.numero,
                       "pendentes_conciliar": pend.get(c.id, 0), **s})
    return {"contas": linhas, "total_disponivel": total}


def _saldo_disponivel(session: Session, empresa_id: int, ate: date) -> Decimal:
    contas = session.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == empresa_id,
                                                         ContaBancaria.tipo.in_(CONTAS_DE_CAIXA))).all()
    return sum((saldo_conta(session, c, ate)["saldo"] for c in contas), ZERO)


def _periodo(d: date, agrupamento: str) -> date:
    if agrupamento == "mes":
        return d.replace(day=1)
    if agrupamento == "semana":
        return d - timedelta(days=d.weekday())
    return d


def _periodos(inicio: date, fim: date, agrupamento: str) -> list[date]:
    out, d = [], _periodo(inicio, agrupamento)
    while d <= fim:
        out.append(d)
        d = (d.replace(day=28) + timedelta(days=4)).replace(day=1) if agrupamento == "mes" else \
            d + timedelta(days=7 if agrupamento == "semana" else 1)
    return out


def fluxo_caixa(session: Session, empresa_id: int, inicio: date, fim: date, agrupamento: str = "mes",
                hoje: date | None = None) -> dict[str, Any]:
    """Por período: entradas e saídas realizadas (baixas), previstas (em aberto, pelo vencimento),
    saldo realizado e saldo projetado. Em aberto já vencido entra como previsto para hoje."""
    hoje = hoje or date.today()
    caixa_ids = select(ContaBancaria.id).where(ContaBancaria.empresa_id == empresa_id,
                                               ContaBancaria.tipo.in_(CONTAS_DE_CAIXA))
    per = _periodos(inicio, fim, agrupamento)
    real = defaultdict(lambda: {"entradas": ZERO, "saidas": ZERO})
    for data, tipo, v in session.execute(
            select(Baixa.data, Lancamento.tipo, Baixa.valor + Baixa.juros - Baixa.desconto).join(Lancamento).where(
                Baixa.empresa_id == empresa_id, Baixa.data.between(inicio, fim), Baixa.conta_bancaria_id.in_(caixa_ids))):
        real[_periodo(data, agrupamento)]["entradas" if tipo == "receber" else "saidas"] += v
    # transferência de conta de caixa para cartão (pagar a fatura) é saída do disponível; o inverso, entrada
    ids = set(session.scalars(caixa_ids))
    for data, origem, destino, v in session.execute(select(Transferencia.data, Transferencia.conta_origem_id,
                                                           Transferencia.conta_destino_id, Transferencia.valor).where(
            Transferencia.empresa_id == empresa_id, Transferencia.data.between(inicio, fim))):
        if (origem in ids) != (destino in ids):
            real[_periodo(data, agrupamento)]["entradas" if destino in ids else "saidas"] += v

    prev = defaultdict(lambda: {"entradas": ZERO, "saidas": ZERO})
    vencidos = {"receber": ZERO, "pagar": ZERO}
    abertos = session.scalars(select(Lancamento).where(
        Lancamento.empresa_id == empresa_id, Lancamento.situacao.in_(("aberto", "parcial")),
        Lancamento.vencimento <= fim)).all()
    from app.servicos.lancamentos import restante
    for l in abertos:
        r = restante(l)
        if r <= 0:
            continue
        quando = l.vencimento
        if quando < hoje:
            vencidos[l.tipo] += r
            quando = hoje
        if inicio <= quando <= fim:
            prev[_periodo(quando, agrupamento)]["entradas" if l.tipo == "receber" else "saidas"] += r

    saldo = _saldo_disponivel(session, empresa_id, inicio - timedelta(days=1))
    projetado = saldo
    linhas = []
    for p in per:
        e, s = real[p]["entradas"], real[p]["saidas"]
        pe, ps = prev[p]["entradas"], prev[p]["saidas"]
        saldo += e - s
        projetado += e - s + pe - ps
        linhas.append({"periodo": p, "entradas": e, "saidas": s, "resultado": e - s,
                       "entradas_previstas": pe, "saidas_previstas": ps,
                       "saldo": saldo if p <= hoje else None, "saldo_projetado": projetado})
    return {"agrupamento": agrupamento, "inicio": inicio, "fim": fim,
            "saldo_inicial": _saldo_disponivel(session, empresa_id, inicio - timedelta(days=1)),
            "vencidos": vencidos, "periodos": linhas}


def transferir(session: Session, empresa_id: int, usuario_id: int | None, origem_id: int, destino_id: int,
               data: date, valor: Any, descricao: str | None = None) -> Transferencia:
    valor = dinheiro(valor)
    if valor <= 0:
        raise NegocioErro("O valor precisa ser maior que zero.")
    if origem_id == destino_id:
        raise NegocioErro("A conta de origem e a de destino precisam ser diferentes.")
    for cid in (origem_id, destino_id):
        c = session.get(ContaBancaria, cid)
        if not c or c.empresa_id != empresa_id:
            raise NegocioErro("Conta bancária não encontrada nesta empresa.")
    t = Transferencia(empresa_id=empresa_id, conta_origem_id=origem_id, conta_destino_id=destino_id, data=data,
                      valor=valor, descricao=(descricao or "").strip() or None, criado_por=usuario_id)
    session.add(t)
    session.flush()
    # movimentos do extrato que são esta transferência (saída na origem, entrada no destino) ficam conciliados
    for conta_id, nat in ((origem_id, "D"), (destino_id, "C")):
        cands = session.scalars(select(Movimento).where(
            Movimento.conta_bancaria_id == conta_id, Movimento.natureza == nat, Movimento.valor == valor,
            Movimento.situacao == "pendente", Movimento.data.between(data - timedelta(days=3), data + timedelta(days=3)))).all()
        m = min(cands, key=lambda x: (abs((x.data - data).days), x.id), default=None)
        if m is not None:
            m.situacao, m.transferencia_id = "conciliado", t.id
    auditar(session, empresa_id, usuario_id, "transferencia", t.id, "criar",
            {"origem": origem_id, "destino": destino_id, "valor": valor, "data": data})
    session.flush()
    return t


def excluir_transferencia(session: Session, t: Transferencia, usuario_id: int | None) -> None:
    for m in session.scalars(select(Movimento).where(Movimento.transferencia_id == t.id)):
        m.situacao, m.transferencia_id = "pendente", None
    auditar(session, t.empresa_id, usuario_id, "transferencia", t.id, "excluir", {"valor": t.valor, "data": t.data})
    session.delete(t)
    session.flush()

