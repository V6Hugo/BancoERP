"""Open Finance (Pluggy): credenciais da empresa, conexão com os bancos e sincronização das contas."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.bancos.pluggy import (PRECISA_RECONECTAR, SITUACAO_ITEM, WIDGET_JS, ClientePluggy, PluggyErro,
                               resumo_conta)
from app.models import ContaBancaria, Empresa
from app.servicos import NegocioErro, auditar

DIAS_PRIMEIRA_CARGA = 90
# nome do banco na Pluggy -> código COMPE (para o ícone e os relatórios)
CODIGOS = [("itau", "341"), ("bradesco", "237"), ("banco do brasil", "001"), ("santander", "033"), ("caixa", "104"),
           ("inter", "077"), ("nubank", "260"), ("sicoob", "756"), ("sicredi", "748"), ("c6", "336"), ("btg", "208"),
           ("safra", "422"), ("original", "212"), ("pagbank", "290"), ("pagseguro", "290"), ("mercado pago", "323"),
           ("stone", "197"), ("banrisul", "041"), ("xp invest", "102"), ("cora", "403"), ("sofisa", "637")]


def codigo_banco(nome: str | None) -> str | None:
    from app.servicos import normalizar
    n = normalizar(nome or "").lower()
    return next((cod for chave, cod in CODIGOS if chave in n), None)


class ReconectarErro(NegocioErro):
    """O banco pediu nova autorização: a tela abre o widget da Pluggy para atualizar a conexão."""
    def __init__(self, msg: str, item_id: str):
        super().__init__(msg)
        self.item_id = item_id


def _cfg(emp: Empresa) -> dict[str, Any]:
    return dict((emp.integracoes or {}).get("pluggy") or {})


def cliente(emp: Empresa, transport=None) -> ClientePluggy:
    from app.seguranca import decifrar
    cfg = _cfg(emp)
    if not cfg.get("client_id") or not cfg.get("client_secret"):
        raise NegocioErro("O Open Finance ainda não foi configurado nesta empresa (Bancos › Open Finance).")
    return ClientePluggy(cfg["client_id"], decifrar(cfg["client_secret"]), transport=transport,
                         **({"base": cfg["base"]} if cfg.get("base") else {}))


def situacao(session: Session, emp: Empresa) -> dict[str, Any]:
    cfg = _cfg(emp)
    contas = session.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == emp.id,
                                                         ContaBancaria.integracao == "openfinance")).all()
    cid = cfg.get("client_id") or ""
    return {"configurado": bool(cid and cfg.get("client_secret")),
            "client_id": (cid[:8] + "…" + cid[-4:]) if len(cid) > 14 else cid,
            "sandbox": bool(cfg.get("sandbox")), "widget": WIDGET_JS,
            "contas": [{"id": c.id, "nome": c.nome, "banco": (c.integracao_config or {}).get("banco"),
                        "item_id": (c.integracao_config or {}).get("item_id")} for c in contas]}


def configurar(session: Session, emp: Empresa, usuario_id: int | None, client_id: str, client_secret: str | None,
               sandbox: bool = False, transport=None) -> None:
    from app.seguranca import cifrar, decifrar
    cfg = _cfg(emp)
    client_id = (client_id or "").strip()
    if not client_id:
        raise NegocioErro("Informe o Client ID da Pluggy.")
    segredo = (client_secret or "").strip() or (decifrar(cfg["client_secret"]) if cfg.get("client_secret") else "")
    if not segredo:
        raise NegocioErro("Informe o Client Secret da Pluggy.")
    cli = ClientePluggy(client_id, segredo, transport=transport, **({"base": cfg["base"]} if cfg.get("base") else {}))
    try:
        cli.autenticar()                     # testa as credenciais antes de salvar
    except PluggyErro as exc:
        raise NegocioErro(str(exc)) from exc
    finally:
        cli.fechar()
    cfg.update(client_id=client_id, client_secret=cifrar(segredo), sandbox=bool(sandbox))
    emp.integracoes = {**(emp.integracoes or {}), "pluggy": cfg}
    auditar(session, emp.id, usuario_id, "empresa", emp.id, "configurar_open_finance", {"client_id": client_id})
    session.flush()


def remover(session: Session, emp: Empresa, usuario_id: int | None) -> None:
    for c in session.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == emp.id, ContaBancaria.integracao == "openfinance")):
        c.integracao, c.integracao_config = "nenhuma", {}
    emp.integracoes = {k: v for k, v in (emp.integracoes or {}).items() if k != "pluggy"}
    auditar(session, emp.id, usuario_id, "empresa", emp.id, "remover_open_finance", {})
    session.flush()


def _executar(emp: Empresa, f, transport=None):
    cli = cliente(emp, transport)
    try:
        return f(cli)
    except PluggyErro as exc:
        if exc.codigo == "RECONECTAR":
            raise ReconectarErro(exc.args[0], exc.args[1] if len(exc.args) > 1 else "") from exc
        raise NegocioErro(str(exc)) from exc
    finally:
        cli.fechar()


def token(emp: Empresa, usuario_id: int | None, item_id: str | None = None, transport=None) -> dict[str, Any]:
    tok = _executar(emp, lambda c: c.connect_token(item_id, f"empresa-{emp.id}"), transport)
    return {"token": tok, "sandbox": bool(_cfg(emp).get("sandbox")), "widget": WIDGET_JS}


def contas_do_item(session: Session, emp: Empresa, item_id: str, transport=None) -> dict[str, Any]:
    def f(c: ClientePluggy):
        return c.item(item_id), c.contas(item_id)
    it, contas = _executar(emp, f, transport)
    ligadas = {(x.integracao_config or {}).get("account_id"): x for x in session.scalars(select(ContaBancaria).where(
        ContaBancaria.empresa_id == emp.id, ContaBancaria.integracao == "openfinance"))}
    con = it.get("connector") or {}
    out = []
    for c in contas:
        r = resumo_conta(c)
        if r["id"] in ligadas:
            r["conta_id"] = ligadas[r["id"]].id
        out.append(r)
    return {"item_id": item_id, "banco": con.get("name"), "banco_imagem": con.get("imageUrl"),
            "situacao": it.get("status"), "situacao_texto": SITUACAO_ITEM.get(it.get("status") or "", it.get("status")),
            "contas": out}


def ligar(session: Session, emp: Empresa, usuario_id: int | None, item_id: str, vinculos: list[dict[str, Any]],
          inicio: date | None = None, transport=None) -> dict[str, Any]:
    """vinculos: [{account_id, conta_id}] ou [{account_id, criar: {nome, banco_codigo, agencia, numero, tipo}}].
    Liga cada conta da Pluggy a uma conta do FinancePro e já traz o extrato."""
    info = contas_do_item(session, emp, item_id, transport)
    por_id = {c["id"]: c for c in info["contas"]}
    feitas: list[ContaBancaria] = []
    for v in vinculos:
        pc = por_id.get(v.get("account_id"))
        if not pc:
            raise NegocioErro("Conta do banco não encontrada nesta conexão.")
        if v.get("conta_id"):
            conta = session.get(ContaBancaria, int(v["conta_id"]))
            if not conta or conta.empresa_id != emp.id:
                raise NegocioErro("Conta do FinancePro não encontrada.")
            if conta.integracao == "inter":
                raise NegocioErro(f"A conta {conta.nome} já usa a API do Inter. Desligue a API do Inter antes.")
        else:
            d = v.get("criar") or {}
            conta = ContaBancaria(empresa_id=emp.id, nome=(d.get("nome") or pc["nome"] or "Conta")[:80],
                                  banco_codigo=(d.get("banco_codigo") or codigo_banco(info.get("banco"))),
                                  agencia=(d.get("agencia") or None),
                                  numero=(d.get("numero") or pc.get("numero") or None) and str(d.get("numero") or pc.get("numero"))[:20],
                                  tipo=d.get("tipo") or pc["tipo"], saldo_inicial=Decimal("0"))
            session.add(conta)
            session.flush()
        conta.integracao = "openfinance"
        conta.integracao_config = {"item_id": item_id, "account_id": pc["id"], "banco": info.get("banco"),
                                   "nome_no_banco": pc["nome"], "numero_no_banco": pc.get("numero")}
        conta.ultima_sincronizacao = None
        feitas.append(conta)
        auditar(session, emp.id, usuario_id, "conta", conta.id, "ligar_open_finance",
                {"banco": info.get("banco"), "conta_no_banco": pc.get("numero")})
    session.flush()
    resultados = []
    for conta in feitas:
        try:
            r = sincronizar(session, conta, usuario_id, inicio=inicio or date.today() - timedelta(days=DIAS_PRIMEIRA_CARGA),
                            atualizar=False, transport=transport)
            resultados.append({"conta_id": conta.id, "conta": conta.nome, **r})
        except NegocioErro as exc:
            resultados.append({"conta_id": conta.id, "conta": conta.nome, "erro": str(exc)})
    return {"contas": resultados}


def sincronizar(session: Session, conta: ContaBancaria, usuario_id: int | None, inicio: date | None = None,
                fim: date | None = None, atualizar: bool = True, transport=None) -> dict[str, Any]:
    from app.servicos.conciliacao import importar
    cfg = conta.integracao_config or {}
    if conta.integracao != "openfinance" or not cfg.get("account_id"):
        raise NegocioErro("Esta conta não está ligada pelo Open Finance.")
    emp = session.get(Empresa, conta.empresa_id)
    fim = fim or date.today()
    if inicio is None:
        inicio = (conta.ultima_sincronizacao.date() - timedelta(days=5)) if conta.ultima_sincronizacao else fim - timedelta(days=DIAS_PRIMEIRA_CARGA)

    def f(c: ClientePluggy):
        it = c.item(cfg["item_id"])
        if it.get("status") in PRECISA_RECONECTAR:
            e = PluggyErro(f"{cfg.get('banco') or 'Banco'}: {SITUACAO_ITEM.get(it['status'], 'conecte de novo')}.", codigo="RECONECTAR")
            e.args = (e.args[0], cfg["item_id"])
            raise e
        if atualizar and it.get("status") == "UPDATED":
            ult = it.get("lastUpdatedAt") or it.get("updatedAt")
            try:
                velho = not ult or datetime.fromisoformat(ult.replace("Z", "+00:00")) < datetime.now(timezone.utc) - timedelta(hours=1)
            except ValueError:
                velho = True
            if velho:
                try:
                    c.atualizar_item(cfg["item_id"])
                    it = c.esperar_item(cfg["item_id"])
                except PluggyErro:
                    pass                      # sem atualização nova, usa o que a Pluggy já tem
        trans = c.transacoes(cfg["account_id"], inicio, fim)
        try:
            saldo = c.conta(cfg["account_id"]).get("balance")
        except PluggyErro:
            saldo = None
        return it, trans, saldo

    it, trans, saldo = _executar(emp, f, transport)
    saldo_dec = Decimal(str(saldo)).quantize(Decimal("0.01")) if saldo is not None else None
    if saldo_dec is not None and conta.tipo == "cartao":
        saldo_dec = -saldo_dec                  # no cartão a Pluggy informa o valor devido
    r = importar(session, conta, trans, "openfinance", usuario_id,
                 arquivo=f"Open Finance {cfg.get('banco') or ''} {inicio:%d/%m/%Y} a {fim:%d/%m/%Y}".replace("  ", " "),
                 saldo=saldo_dec, data_saldo=date.today() if saldo_dec is not None else None)
    conta.ultima_sincronizacao = datetime.now(timezone.utc)
    session.flush()
    return {**r, "situacao_banco": SITUACAO_ITEM.get(it.get("status") or "", it.get("status"))}


def desligar(session: Session, conta: ContaBancaria, usuario_id: int | None, revogar: bool = True, transport=None) -> None:
    """Solta a conta do Open Finance. Se nenhuma outra conta usa a mesma conexão, revoga o acesso na Pluggy."""
    cfg = conta.integracao_config or {}
    item_id = cfg.get("item_id")
    conta.integracao, conta.integracao_config = "nenhuma", {}
    session.flush()
    if revogar and item_id:
        outras = session.scalar(select(ContaBancaria.id).where(
            ContaBancaria.empresa_id == conta.empresa_id, ContaBancaria.integracao == "openfinance",
            ContaBancaria.integracao_config["item_id"].as_string() == item_id))
        if not outras:
            try:
                _executar(session.get(Empresa, conta.empresa_id), lambda c: c.excluir_item(item_id), transport)
            except NegocioErro:
                pass                            # a conexão já pode ter expirado do lado da Pluggy
    auditar(session, conta.empresa_id, usuario_id, "conta", conta.id, "desligar_open_finance", {"item_id": item_id})
    session.flush()
