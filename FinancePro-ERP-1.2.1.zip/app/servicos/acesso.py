"""Acesso: login com limite de tentativas, sessões no servidor, verificação em duas etapas e
confirmação de senha para ações sensíveis. Todos os eventos ficam na auditoria."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Auditoria, SessaoUsuario, Usuario
from app.seguranca import (HASH_FALSO, confere_senha, conferir_totp, decifrar, hash_token, novo_token,
                           usar_codigo_recuperacao)
from app.servicos import NegocioErro, auditar

JANELA_MIN = 15
MAX_POR_EMAIL = 5          # erros por e-mail em 15 min antes de bloquear
MAX_POR_IP = 30            # erros por endereço em 15 min
CONFIRMACAO_VALE_MIN = 10  # depois de confirmar a senha, ações sensíveis ficam liberadas por 10 min


class BloqueioErro(NegocioErro):
    pass


class CredencialErro(NegocioErro):
    """E-mail ou senha errados no login (HTTP 401). Mesma mensagem para e-mail inexistente e senha errada."""


def agora() -> datetime:
    return datetime.now(timezone.utc)


def evento(session: Session, usuario_id: int | None, acao: str, dados: dict[str, Any] | None = None,
           empresa_id: int | None = None) -> None:
    auditar(session, empresa_id, usuario_id, "acesso", usuario_id, acao, dados or {})


# ---------------------------------------------------------------- limite de tentativas

def _falhas(session: Session, campo: str, valor: str) -> int:
    desde = agora() - timedelta(minutes=JANELA_MIN)
    return session.scalar(select(func.count(Auditoria.id)).where(
        Auditoria.entidade == "acesso", Auditoria.acao.in_(("login_falhou", "2fa_falhou")),
        Auditoria.criado_em >= desde, Auditoria.dados[campo].as_string() == valor)) or 0


def checar_bloqueio(session: Session, email: str, ip: str | None) -> None:
    if _falhas(session, "email", email) >= MAX_POR_EMAIL or (ip and _falhas(session, "ip", ip) >= MAX_POR_IP):
        evento(session, None, "login_bloqueado", {"email": email, "ip": ip})
        session.commit()                   # o evento fica registrado mesmo com o erro
        raise BloqueioErro(f"Muitas tentativas erradas. Por segurança, espere {JANELA_MIN} minutos e tente de novo.")


def conferir_login(session: Session, email: str, senha: str, ip: str | None) -> Usuario:
    email = email.strip().lower()
    checar_bloqueio(session, email, ip)
    u = session.scalar(select(Usuario).where(Usuario.email == email))
    ok = confere_senha(senha, u.senha_hash if u else HASH_FALSO)
    if not u or not ok or not u.ativo:
        evento(session, u.id if u else None, "login_falhou",
               {"email": email, "ip": ip, "motivo": "inativo" if (u and ok) else "senha"})
        session.commit()
        raise CredencialErro("E-mail ou senha incorretos.")
    return u


def conferir_segundo_fator(session: Session, u: Usuario, codigo: str, ip: str | None) -> str:
    """Aceita o código do aplicativo ou um código de recuperação. Devolve qual foi usado."""
    checar_bloqueio(session, u.email, ip)
    codigo = (codigo or "").strip()
    passo = conferir_totp(decifrar(u.totp_segredo), codigo, u.totp_ultimo_passo) if u.totp_segredo else None
    if passo is not None:
        u.totp_ultimo_passo = passo
        return "aplicativo"
    resto = usar_codigo_recuperacao(codigo, u.codigos_recuperacao)
    if resto is not None:
        u.codigos_recuperacao = resto
        evento(session, u.id, "2fa_codigo_recuperacao", {"ip": ip, "restam": len(resto)})
        return "recuperacao"
    evento(session, u.id, "2fa_falhou", {"email": u.email, "ip": ip})
    session.commit()
    raise NegocioErro("Código incorreto ou vencido. Confira o horário do celular e tente o próximo código.")


# ---------------------------------------------------------------- sessões

def abrir_sessao(session: Session, u: Usuario, ip: str | None, navegador: str | None) -> str:
    st = get_settings()
    token, h = novo_token()
    agora_ = agora()
    session.add(SessaoUsuario(token_hash=h, usuario_id=u.id, criada_em=agora_, ultimo_uso=agora_,
                              expira_em=agora_ + timedelta(hours=st.sessao_horas), confirmada_em=agora_,
                              ip=ip, navegador=(navegador or "")[:200] or None))
    u.ultimo_acesso = agora_
    evento(session, u.id, "login", {"email": u.email, "ip": ip, "navegador": (navegador or "")[:120]})
    session.flush()
    return token


def sessao_valida(session: Session, token: str | None) -> SessaoUsuario | None:
    if not token or len(token) > 100:
        return None
    s = session.scalar(select(SessaoUsuario).where(SessaoUsuario.token_hash == hash_token(token)))
    if not s or s.encerrada_em:
        return None
    agora_ = agora()
    limite_inativo = s.ultimo_uso + timedelta(minutes=get_settings().sessao_inatividade_min)
    if agora_ > s.expira_em or agora_ > limite_inativo:
        s.encerrada_em, s.motivo = agora_, ("expirou" if agora_ > s.expira_em else "inatividade")
        session.flush()
        return None
    if not s.usuario.ativo:
        return None
    if (agora_ - s.ultimo_uso).total_seconds() > 60:          # não grava a cada clique
        s.ultimo_uso = agora_
    return s


def encerrar(session: Session, s: SessaoUsuario, motivo: str) -> None:
    if not s.encerrada_em:
        s.encerrada_em, s.motivo = agora(), motivo


def encerrar_todas(session: Session, usuario_id: int, motivo: str, exceto_id: int | None = None) -> int:
    q = update(SessaoUsuario).where(SessaoUsuario.usuario_id == usuario_id, SessaoUsuario.encerrada_em.is_(None))
    if exceto_id:
        q = q.where(SessaoUsuario.id != exceto_id)
    r = session.execute(q.values(encerrada_em=agora(), motivo=motivo))
    return r.rowcount or 0


def sessoes_ativas(session: Session, usuario_id: int) -> list[SessaoUsuario]:
    agora_ = agora()
    inativo = agora_ - timedelta(minutes=get_settings().sessao_inatividade_min)
    return list(session.scalars(select(SessaoUsuario).where(
        SessaoUsuario.usuario_id == usuario_id, SessaoUsuario.encerrada_em.is_(None),
        SessaoUsuario.expira_em > agora_, SessaoUsuario.ultimo_uso > inativo).order_by(SessaoUsuario.ultimo_uso.desc())))


# ---------------------------------------------------------------- confirmação de senha (ações sensíveis)

def confirmar(session: Session, s: SessaoUsuario, senha: str, codigo: str | None, ip: str | None) -> None:
    u = s.usuario
    checar_bloqueio(session, u.email, ip)
    if not confere_senha(senha or "", u.senha_hash):
        evento(session, u.id, "login_falhou", {"email": u.email, "ip": ip, "motivo": "confirmacao"})
        session.commit()
        raise NegocioErro("Senha incorreta.")
    if u.totp_ativo:
        if not codigo:
            raise NegocioErro("Informe também o código da verificação em duas etapas.")
        conferir_segundo_fator(session, u, codigo, ip)
    s.confirmada_em = agora()
    evento(session, u.id, "senha_confirmada", {"ip": ip})


def confirmada_recentemente(s: SessaoUsuario) -> bool:
    return bool(s.confirmada_em and agora() - s.confirmada_em < timedelta(minutes=CONFIRMACAO_VALE_MIN))
