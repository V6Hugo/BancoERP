"""Modelo de dados do FinancePro ERP.

Princípios:
- toda tabela de negócio tem `empresa_id` (várias empresas no mesmo banco, isoladas pela aplicação);
- dinheiro em NUMERIC(14,2), nunca float; valores sempre positivos, o sentido vem do tipo/natureza;
- restrições no próprio banco (chaves estrangeiras, CHECK, UNIQUE) para que dado inválido não entre
  nem por fora da aplicação;
- o que foi realizado (baixas e transferências) é separado do previsto (lançamentos em aberto) e do
  extrato do banco (movimentos), que é a referência para conciliar.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import (JSON, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Numeric,
                        String, Text, UniqueConstraint)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base

JSONVar = JSON().with_variant(JSONB(), "postgresql")
Dinheiro = Numeric(14, 2)


def agora() -> datetime:
    return datetime.now(timezone.utc)


class Carimbo:
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora)
    atualizado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora, onupdate=agora)


# ============================================================================ empresas e usuários

class Empresa(Carimbo, Base):
    __tablename__ = "empresas"
    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(160))                     # nome fantasia
    razao_social: Mapped[str | None] = mapped_column(String(200))
    cnpj: Mapped[str | None] = mapped_column(String(14), unique=True)
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    # credenciais de integrações da empresa (ex.: Open Finance pela Pluggy); segredos sempre cifrados
    integracoes: Mapped[dict[str, Any]] = mapped_column(JSONVar, default=dict)


class Usuario(Carimbo, Base):
    __tablename__ = "usuarios"
    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(160), unique=True)       # sempre em minúsculas
    senha_hash: Mapped[str] = mapped_column(String(200))
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    admin_sistema: Mapped[bool] = mapped_column(Boolean, default=False)  # cria empresas e usuários
    ultimo_acesso: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    senha_alterada_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # verificação em duas etapas (TOTP: Google Authenticator, Microsoft Authenticator, Authy...)
    totp_segredo: Mapped[str | None] = mapped_column(String(300))          # cifrado
    totp_ativo: Mapped[bool] = mapped_column(Boolean, default=False)
    totp_ultimo_passo: Mapped[int | None] = mapped_column(Integer)          # impede reusar o mesmo código
    codigos_recuperacao: Mapped[list[str]] = mapped_column(JSONVar, default=list)   # hashes SHA-256
    vinculos: Mapped[list["Vinculo"]] = relationship(back_populates="usuario", cascade="all, delete-orphan")


class SessaoUsuario(Base):
    """Sessão aberta no navegador. O cookie guarda um token aleatório; aqui fica só o hash dele.
    Sair, trocar a senha ou ficar sem usar encerra a sessão de verdade."""
    __tablename__ = "sessoes"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    usuario_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id", ondelete="CASCADE"), index=True)
    criada_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora)
    ultimo_uso: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora)
    expira_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    confirmada_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))   # senha confirmada (ações sensíveis)
    ip: Mapped[str | None] = mapped_column(String(45))
    navegador: Mapped[str | None] = mapped_column(String(200))
    encerrada_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    motivo: Mapped[str | None] = mapped_column(String(30))
    usuario: Mapped["Usuario"] = relationship()


class Vinculo(Base):
    """Acesso de um usuário a uma empresa. Papel: admin (tudo), financeiro (lança e concilia), leitura."""
    __tablename__ = "vinculos"
    __table_args__ = (CheckConstraint("papel in ('admin','financeiro','leitura')", name="papel"),)
    usuario_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id", ondelete="CASCADE"), primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), primary_key=True)
    papel: Mapped[str] = mapped_column(String(12), default="financeiro")
    usuario: Mapped[Usuario] = relationship(back_populates="vinculos")
    empresa: Mapped[Empresa] = relationship()


# ============================================================================ cadastros

class Categoria(Carimbo, Base):
    """Plano de contas gerencial em dois níveis: grupo (pai) e categoria (onde se lança).
    `grupo_dre` diz em que linha do DRE a categoria entra; `natureza` diz se é entrada ou saída."""
    __tablename__ = "categorias"
    __table_args__ = (
        UniqueConstraint("empresa_id", "codigo"),
        CheckConstraint("natureza in ('receita','despesa','neutra')", name="natureza"),
        CheckConstraint("grupo_dre in ('receita_bruta','deducoes','custos','despesas_operacionais',"
                        "'receitas_financeiras','despesas_financeiras','impostos_lucro','investimentos',"
                        "'nao_operacional')", name="grupo_dre"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    pai_id: Mapped[int | None] = mapped_column(ForeignKey("categorias.id", ondelete="RESTRICT"), index=True)
    codigo: Mapped[str] = mapped_column(String(20))
    nome: Mapped[str] = mapped_column(String(120))
    natureza: Mapped[str] = mapped_column(String(10))
    grupo_dre: Mapped[str] = mapped_column(String(30))
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    pai: Mapped["Categoria | None"] = relationship(remote_side="Categoria.id")


class CentroCusto(Carimbo, Base):
    __tablename__ = "centros_custo"
    __table_args__ = (UniqueConstraint("empresa_id", "codigo"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    pai_id: Mapped[int | None] = mapped_column(ForeignKey("centros_custo.id", ondelete="RESTRICT"))
    codigo: Mapped[str] = mapped_column(String(20))
    nome: Mapped[str] = mapped_column(String(120))
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)


class Contato(Carimbo, Base):
    """Cliente e/ou fornecedor."""
    __tablename__ = "contatos"
    __table_args__ = (
        UniqueConstraint("empresa_id", "documento"),     # NULL não conflita: sem documento pode repetir
        CheckConstraint("tipo in ('cliente','fornecedor','ambos')", name="tipo"),
        Index("ix_contatos_empresa_nome", "empresa_id", "nome"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    tipo: Mapped[str] = mapped_column(String(12), default="fornecedor")
    nome: Mapped[str] = mapped_column(String(200))
    documento: Mapped[str | None] = mapped_column(String(14))           # CPF/CNPJ só dígitos
    email: Mapped[str | None] = mapped_column(String(160))
    telefone: Mapped[str | None] = mapped_column(String(40))
    chave_pix: Mapped[str | None] = mapped_column(String(120))
    banco: Mapped[str | None] = mapped_column(String(120))              # dados bancários para pagamento
    categoria_padrao_id: Mapped[int | None] = mapped_column(ForeignKey("categorias.id", ondelete="SET NULL"))
    centro_custo_padrao_id: Mapped[int | None] = mapped_column(ForeignKey("centros_custo.id", ondelete="SET NULL"))
    observacao: Mapped[str | None] = mapped_column(Text)
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)


class ContaBancaria(Carimbo, Base):
    __tablename__ = "contas_bancarias"
    __table_args__ = (
        CheckConstraint("tipo in ('corrente','poupanca','investimento','caixa','cartao')", name="tipo"),
        CheckConstraint("integracao in ('nenhuma','inter','openfinance')", name="integracao"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    nome: Mapped[str] = mapped_column(String(80))                        # como aparece nas telas
    banco_codigo: Mapped[str | None] = mapped_column(String(3))          # COMPE: 077 Inter, 341 Itaú...
    agencia: Mapped[str | None] = mapped_column(String(10))
    numero: Mapped[str | None] = mapped_column(String(20))
    tipo: Mapped[str] = mapped_column(String(12), default="corrente")
    saldo_inicial: Mapped[Decimal] = mapped_column(Dinheiro, default=Decimal("0"))
    data_saldo_inicial: Mapped[date | None] = mapped_column(Date)
    integracao: Mapped[str] = mapped_column(String(12), default="nenhuma")
    integracao_config: Mapped[dict[str, Any]] = mapped_column(JSONVar, default=dict)   # segredos cifrados
    ultima_sincronizacao: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)


# ============================================================================ financeiro

class Lancamento(Carimbo, Base):
    """Conta a receber ou a pagar. O que já foi pago/recebido fica nas baixas (uma ou várias, se parcial)."""
    __tablename__ = "lancamentos"
    __table_args__ = (
        CheckConstraint("tipo in ('receber','pagar')", name="tipo"),
        CheckConstraint("valor > 0", name="valor_positivo"),
        CheckConstraint("situacao in ('aberto','parcial','pago','cancelado')", name="situacao"),
        CheckConstraint("total_parcelas >= 1 and parcela >= 1 and parcela <= total_parcelas", name="parcelas"),
        Index("ix_lancamentos_empresa_tipo_venc", "empresa_id", "tipo", "vencimento"),
        Index("ix_lancamentos_empresa_situacao", "empresa_id", "situacao"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    tipo: Mapped[str] = mapped_column(String(8))
    descricao: Mapped[str] = mapped_column(String(300))
    contato_id: Mapped[int | None] = mapped_column(ForeignKey("contatos.id", ondelete="RESTRICT"), index=True)
    categoria_id: Mapped[int | None] = mapped_column(ForeignKey("categorias.id", ondelete="RESTRICT"), index=True)
    centro_custo_id: Mapped[int | None] = mapped_column(ForeignKey("centros_custo.id", ondelete="RESTRICT"), index=True)
    conta_bancaria_id: Mapped[int | None] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="RESTRICT"))
    valor: Mapped[Decimal] = mapped_column(Dinheiro)
    competencia: Mapped[date] = mapped_column(Date)                       # mês a que o valor se refere
    vencimento: Mapped[date] = mapped_column(Date)
    situacao: Mapped[str] = mapped_column(String(10), default="aberto")
    documento: Mapped[str | None] = mapped_column(String(60))             # NF, boleto, contrato
    forma_pagamento: Mapped[str | None] = mapped_column(String(30))       # pix, boleto, cartão...
    parcela: Mapped[int] = mapped_column(Integer, default=1)
    total_parcelas: Mapped[int] = mapped_column(Integer, default=1)
    grupo_parcelas: Mapped[str | None] = mapped_column(String(36), index=True)
    recorrente: Mapped[bool] = mapped_column(Boolean, default=False)
    observacao: Mapped[str | None] = mapped_column(Text)
    criado_por: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))

    contato: Mapped[Contato | None] = relationship()
    categoria: Mapped[Categoria | None] = relationship()
    centro_custo: Mapped[CentroCusto | None] = relationship()
    conta_bancaria: Mapped[ContaBancaria | None] = relationship()
    baixas: Mapped[list["Baixa"]] = relationship(back_populates="lancamento", cascade="all, delete-orphan",
                                                 order_by="Baixa.data")


class Baixa(Carimbo, Base):
    """Pagamento ou recebimento (total ou parcial) de um lançamento, numa conta e numa data."""
    __tablename__ = "baixas"
    __table_args__ = (
        CheckConstraint("valor > 0", name="valor_positivo"),
        CheckConstraint("juros >= 0 and desconto >= 0", name="acrescimos"),
        Index("ix_baixas_empresa_data", "empresa_id", "data"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    lancamento_id: Mapped[int] = mapped_column(ForeignKey("lancamentos.id", ondelete="CASCADE"), index=True)
    conta_bancaria_id: Mapped[int] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="RESTRICT"), index=True)
    data: Mapped[date] = mapped_column(Date)
    valor: Mapped[Decimal] = mapped_column(Dinheiro)                      # quanto abateu do lançamento
    juros: Mapped[Decimal] = mapped_column(Dinheiro, default=Decimal("0"))  # juros/multa pagos a mais
    desconto: Mapped[Decimal] = mapped_column(Dinheiro, default=Decimal("0"))
    movimento_id: Mapped[int | None] = mapped_column(ForeignKey("movimentos.id", ondelete="SET NULL"), index=True)
    criado_por: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    lancamento: Mapped[Lancamento] = relationship(back_populates="baixas")
    conta_bancaria: Mapped[ContaBancaria] = relationship()

    @property
    def valor_caixa(self) -> Decimal:
        """O que de fato entrou ou saiu da conta."""
        return self.valor + self.juros - self.desconto


class Transferencia(Carimbo, Base):
    """Dinheiro entre contas da própria empresa: não é receita nem despesa."""
    __tablename__ = "transferencias"
    __table_args__ = (
        CheckConstraint("valor > 0", name="valor_positivo"),
        CheckConstraint("conta_origem_id <> conta_destino_id", name="contas_diferentes"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    conta_origem_id: Mapped[int] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="RESTRICT"))
    conta_destino_id: Mapped[int] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="RESTRICT"))
    data: Mapped[date] = mapped_column(Date)
    valor: Mapped[Decimal] = mapped_column(Dinheiro)
    descricao: Mapped[str | None] = mapped_column(String(200))
    criado_por: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))


# ============================================================================ bancos

class ImportacaoExtrato(Base):
    __tablename__ = "importacoes"
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    conta_bancaria_id: Mapped[int] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="CASCADE"))
    origem: Mapped[str] = mapped_column(String(20))                        # ofx | planilha | api_inter | openfinance
    arquivo: Mapped[str | None] = mapped_column(String(255))
    inicio: Mapped[date | None] = mapped_column(Date)
    fim: Mapped[date | None] = mapped_column(Date)
    recebidos: Mapped[int] = mapped_column(Integer, default=0)
    novos: Mapped[int] = mapped_column(Integer, default=0)
    duplicados: Mapped[int] = mapped_column(Integer, default=0)
    saldo_banco: Mapped[Decimal | None] = mapped_column(Dinheiro)
    data_saldo_banco: Mapped[date | None] = mapped_column(Date)
    criado_por: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora)


class Movimento(Carimbo, Base):
    """Linha do extrato bancário. Fica pendente até ser conciliada com uma baixa ou transferência,
    ou marcada como ignorada (ex.: estorno que se anula)."""
    __tablename__ = "movimentos"
    __table_args__ = (
        UniqueConstraint("conta_bancaria_id", "id_externo"),             # reimportar não duplica
        CheckConstraint("valor > 0", name="valor_positivo"),
        CheckConstraint("natureza in ('C','D')", name="natureza"),
        CheckConstraint("situacao in ('pendente','conciliado','ignorado')", name="situacao"),
        Index("ix_movimentos_conta_data", "conta_bancaria_id", "data"),
        Index("ix_movimentos_empresa_situacao", "empresa_id", "situacao"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    conta_bancaria_id: Mapped[int] = mapped_column(ForeignKey("contas_bancarias.id", ondelete="CASCADE"))
    importacao_id: Mapped[int | None] = mapped_column(ForeignKey("importacoes.id", ondelete="SET NULL"))
    data: Mapped[date] = mapped_column(Date)
    valor: Mapped[Decimal] = mapped_column(Dinheiro)
    natureza: Mapped[str] = mapped_column(String(1))                       # C entrada, D saída
    descricao: Mapped[str] = mapped_column(String(300))
    documento: Mapped[str | None] = mapped_column(String(60))
    id_externo: Mapped[str] = mapped_column(String(120))                   # FITID / idTransacao / hash
    origem: Mapped[str] = mapped_column(String(20), default="ofx")
    situacao: Mapped[str] = mapped_column(String(10), default="pendente")
    transferencia_id: Mapped[int | None] = mapped_column(ForeignKey("transferencias.id", ondelete="SET NULL"))
    dados_brutos: Mapped[dict[str, Any]] = mapped_column(JSONVar, default=dict)
    conta_bancaria: Mapped[ContaBancaria] = relationship()


class RegraClassificacao(Carimbo, Base):
    """Se a descrição do extrato contém `texto`, sugere categoria, centro de custo e contato."""
    __tablename__ = "regras"
    __table_args__ = (CheckConstraint("natureza in ('C','D','*')", name="natureza"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    texto: Mapped[str] = mapped_column(String(120))
    natureza: Mapped[str] = mapped_column(String(1), default="*")
    categoria_id: Mapped[int | None] = mapped_column(ForeignKey("categorias.id", ondelete="CASCADE"))
    centro_custo_id: Mapped[int | None] = mapped_column(ForeignKey("centros_custo.id", ondelete="SET NULL"))
    contato_id: Mapped[int | None] = mapped_column(ForeignKey("contatos.id", ondelete="SET NULL"))
    prioridade: Mapped[int] = mapped_column(Integer, default=100)          # menor roda antes
    vezes_usada: Mapped[int] = mapped_column(Integer, default=0)
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)


class Auditoria(Base):
    """Quem fez o quê: criação, alteração, baixa, exclusão, importação, entradas e saídas do sistema."""
    __tablename__ = "auditoria"
    __table_args__ = (Index("ix_auditoria_entidade_acao_criado", "entidade", "acao", "criado_em"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    empresa_id: Mapped[int | None] = mapped_column(ForeignKey("empresas.id", ondelete="CASCADE"), index=True)
    usuario_id: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    entidade: Mapped[str] = mapped_column(String(40))
    entidade_id: Mapped[int | None] = mapped_column(Integer)
    acao: Mapped[str] = mapped_column(String(30))
    dados: Mapped[dict[str, Any]] = mapped_column(JSONVar, default=dict)
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=agora, index=True)
