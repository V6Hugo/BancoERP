"""Conexão com o banco de dados (PostgreSQL; SQLite só para testes rápidos)."""
from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import MetaData, create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

# nomes estáveis para índices e restrições: as migrações ficam previsíveis
CONVENCAO = {
    "ix": "ix_%(table_name)s_%(column_0_N_name)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=CONVENCAO)


_engine = None
SessionLocal = sessionmaker(autoflush=False, expire_on_commit=False)


def configurar(url: str):
    """Cria o engine e liga a fábrica de sessões a ele."""
    global _engine
    if _engine is not None:
        _engine.dispose()
    if url.startswith("sqlite"):
        _engine = create_engine(url, connect_args={"check_same_thread": False})

        @event.listens_for(_engine, "connect")
        def _fk(conn, _):  # SQLite só respeita chave estrangeira com este pragma
            conn.execute("PRAGMA foreign_keys=ON")
    else:
        _engine = create_engine(url, pool_pre_ping=True, pool_size=10, max_overflow=20)
    SessionLocal.configure(bind=_engine)
    return _engine


def engine():
    return _engine


def get_session() -> Iterator[Session]:
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()
