"""Extrato em planilha: Excel (.xlsx e .xls), CSV/TXT e o ".xls" que é uma página HTML (BB, Itaú e outros).

Cada banco exporta de um jeito, então a leitura tem três passos:
1. `ler_linhas`: transforma o arquivo numa lista de linhas (células como texto, número ou data);
2. `detectar`: acha a linha de cabeçalho e qual coluna é a data, a descrição, o valor (ou crédito e débito)...;
3. `interpretar`: converte as linhas em `TransacaoBanco`, pulando saldos, totais e linhas vazias.

O mapeamento detectado pode ser corrigido pela pessoa na tela de prévia (campo -> índice da coluna).
"""
from __future__ import annotations

import csv
import io
import re
import unicodedata
import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser
from typing import Any

from . import TransacaoBanco


class PlanilhaErro(ValueError):
    pass


CAMPOS = {
    "data": "Data",
    "descricao": "Descrição",
    "complemento": "Complemento / favorecido",
    "cpf_cnpj": "CPF/CNPJ do favorecido",
    "valor": "Valor (com sinal)",
    "credito": "Crédito / entrada",
    "debito": "Débito / saída",
    "tipo": "Tipo (C/D)",
    "documento": "Documento",
    "saldo": "Saldo",
}

# nomes de coluna usados pelos bancos (sem acento, minúsculas). O primeiro que casar exatamente ganha;
# depois, por "começa com".
SINONIMOS = {
    "data": ["data", "data lancamento", "data do lancamento", "data de lancamento", "dt lancamento", "dt", "data mov",
             "data movimento", "data do movimento", "data movimentacao", "data transacao", "data da transacao",
             "data contabil", "data operacao", "data efetiva", "dia", "date"],
    "descricao": ["descricao", "historico", "lancamento", "lancamentos", "descricao do lancamento", "historico do lancamento",
                  "detalhe", "detalhes", "memo", "transacao", "titulo", "estabelecimento", "description"],
    "complemento": ["complemento", "informacoes complementares", "detalhamento", "observacao", "favorecido", "origem destino",
                    "nome", "contraparte", "razao social", "nome razao social", "pagador", "recebedor", "pagador recebedor",
                    "beneficiario", "remetente", "destinatario", "nome do favorecido", "nome favorecido"],
    "cpf_cnpj": ["cpf cnpj", "cpf", "cnpj", "cnpj cpf", "cpf cnpj do favorecido", "documento do favorecido", "cpf ou cnpj",
                 "cpf cnpj favorecido", "cpf cnpj pagador"],
    "valor": ["valor", "valor r", "valor rs", "valor do lancamento", "valor lancamento", "montante", "quantia", "amount",
              "valor movimento", "movimentacao"],
    "credito": ["credito", "creditos", "entrada", "entradas", "valor credito", "credito r", "recebimentos"],
    "debito": ["debito", "debitos", "saida", "saidas", "valor debito", "debito r", "pagamentos"],
    "tipo": ["tipo", "natureza", "c d", "d c", "cd", "dc", "tipo lancamento", "tipo de lancamento", "tipo transacao",
             "credito debito", "debito credito"],
    "documento": ["documento", "doc", "n documento", "no documento", "numero documento", "numero do documento", "nr doc",
                  "num doc", "identificador", "id", "id transacao", "codigo", "autenticacao"],
    "saldo": ["saldo", "saldos", "saldo r", "saldos r", "saldo rs", "saldo do dia", "saldo final", "saldo apos lancamento", "saldo disponivel", "balance"],
}

PULAR = re.compile(r"^(s ?a ?l ?d ?o|total|subtotal|sdo|lancamentos futuros|saldo anterior|resumo)\b")


def _norm(texto: Any) -> str:
    s = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


# ============================================================================ 1) ler o arquivo

def tipo_arquivo(conteudo: bytes, nome: str = "") -> str:
    """ofx | xlsx | xls | html | csv"""
    cab = conteudo[:2048].lstrip(b"\xef\xbb\xbf").lstrip()
    if conteudo[:2] == b"PK":
        return "xlsx"
    if conteudo[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        return "xls"
    alto = cab.upper()
    if alto.startswith(b"OFXHEADER") or b"<OFX>" in alto or alto.startswith(b"<?OFX") or (alto.startswith(b"<?XML") and b"<OFX" in conteudo[:4096].upper()):
        return "ofx"
    if b"<TABLE" in conteudo[:200000].upper() or alto.startswith(b"<HTML") or alto.startswith(b"<!DOCTYPE"):
        return "html"
    if nome.lower().endswith(".ofx"):
        return "ofx"
    return "csv"


def _decodificar(conteudo: bytes) -> str:
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return conteudo.decode(enc)
        except UnicodeDecodeError:
            continue
    return conteudo.decode("latin-1", errors="replace")


def _ler_xlsx(conteudo: bytes) -> list[list[Any]]:
    from openpyxl import load_workbook
    try:
        wb = load_workbook(io.BytesIO(conteudo), read_only=True, data_only=True)
    except (zipfile.BadZipFile, KeyError, ValueError, OSError) as exc:
        raise PlanilhaErro("Não consegui abrir a planilha. Confira se o arquivo é um Excel (.xlsx) válido.") from exc
    abas = []
    for ws in wb.worksheets:
        # alguns bancos (ex.: Itaú) gravam no arquivo um tamanho de planilha menor que o real; no modo de
        # leitura rápida o openpyxl confiaria nele e pararia no meio. reset_dimensions() faz ler até o fim.
        if hasattr(ws, "reset_dimensions"):
            ws.reset_dimensions()
        linhas = [list(r) for r in ws.iter_rows(values_only=True)]
        abas.append([r for r in linhas if any(c not in (None, "") for c in r)])
    wb.close()
    return _melhor_aba(abas)


def _ler_xls(conteudo: bytes) -> list[list[Any]]:
    try:
        import xlrd
    except ImportError as exc:  # pragma: no cover
        raise PlanilhaErro("Leitura de .xls indisponível. Salve a planilha como .xlsx ou CSV.") from exc
    try:
        wb = xlrd.open_workbook(file_contents=conteudo)
    except Exception as exc:  # noqa: BLE001 - xlrd lança vários tipos
        raise PlanilhaErro("Não consegui abrir o arquivo .xls. Salve como .xlsx ou CSV e tente de novo.") from exc
    abas = []
    for sh in wb.sheets():
        linhas = []
        for i in range(sh.nrows):
            linha = []
            for j in range(sh.ncols):
                c = sh.cell(i, j)
                if c.ctype == xlrd.XL_CELL_DATE:
                    try:
                        linha.append(xlrd.xldate.xldate_as_datetime(c.value, wb.datemode))
                    except Exception:  # noqa: BLE001
                        linha.append(c.value)
                elif c.ctype == xlrd.XL_CELL_EMPTY:
                    linha.append(None)
                else:
                    linha.append(c.value)
            if any(x not in (None, "") for x in linha):
                linhas.append(linha)
        abas.append(linhas)
    return _melhor_aba(abas)


def _melhor_aba(abas: list[list[list[Any]]]) -> list[list[Any]]:
    """A aba (ou tabela) com mais linhas que têm data é o extrato."""
    def pontos(t):
        return sum(1 for l in t if any(para_data(c) for c in l[:6])) * 1000 + len(t)
    return max(abas, key=pontos, default=[])


class _Tabelas(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tabelas: list[list[list[str]]] = []
        self._linha: list[str] | None = None
        self._celula: list[str] | None = None
        self._colspan = 1

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.tabelas.append([])
        elif tag == "tr" and self.tabelas:
            self._linha = []
        elif tag in ("td", "th") and self._linha is not None:
            self._celula = []
            try:
                self._colspan = max(1, min(20, int(dict(attrs).get("colspan") or 1)))
            except ValueError:
                self._colspan = 1
        elif tag == "br" and self._celula is not None:
            self._celula.append(" ")

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._celula is not None and self._linha is not None:
            texto = re.sub(r"\s+", " ", "".join(self._celula)).strip()
            self._linha.extend([texto] + [""] * (self._colspan - 1))
            self._celula = None
        elif tag == "tr" and self._linha is not None and self.tabelas:
            if any(self._linha):
                self.tabelas[-1].append(self._linha)
            self._linha = None

    def handle_data(self, data):
        if self._celula is not None:
            self._celula.append(data)


def _ler_html(conteudo: bytes) -> list[list[Any]]:
    p = _Tabelas()
    p.feed(_decodificar(conteudo))
    if not p.tabelas:
        raise PlanilhaErro("O arquivo não tem nenhuma tabela.")
    return _melhor_aba(p.tabelas)


def _ler_csv(conteudo: bytes) -> list[list[Any]]:
    texto = _decodificar(conteudo)
    amostra = "\n".join(texto.splitlines()[:40])
    try:
        sep = csv.Sniffer().sniff(amostra, delimiters=";,\t|").delimiter
    except csv.Error:
        sep = max(";,\t|", key=amostra.count)
    linhas = [l for l in csv.reader(io.StringIO(texto), delimiter=sep) if any(c.strip() for c in l)]
    if not linhas:
        raise PlanilhaErro("O arquivo está vazio.")
    return linhas


def ler_linhas(conteudo: bytes, nome: str = "") -> list[list[Any]]:
    tipo = tipo_arquivo(conteudo, nome)
    if tipo == "ofx":
        raise PlanilhaErro("Este arquivo é OFX.")
    linhas = {"xlsx": _ler_xlsx, "xls": _ler_xls, "html": _ler_html, "csv": _ler_csv}[tipo](conteudo)
    if not linhas:
        raise PlanilhaErro("A planilha não tem linhas preenchidas.")
    largura = max(len(l) for l in linhas)
    return [list(l) + [None] * (largura - len(l)) for l in linhas]


# ============================================================================ conversões

def para_data(v: Any) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 <= v <= 80000:                      # número de série do Excel
            return date(1899, 12, 30) + timedelta(days=int(v))
        return None
    s = str(v).strip()
    m = re.match(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})\b", s)
    if m:
        d, mes, a = (int(x) for x in m.groups())
        if a < 100:
            a += 2000 if a < 70 else 1900
        try:
            return date(a, mes, d)
        except ValueError:
            return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            return date(*(int(x) for x in m.groups()))
        except ValueError:
            return None
    return None


def para_valor(v: Any) -> tuple[Decimal | None, str | None]:
    """Converte o texto do banco em número com sinal. Devolve também C/D quando o banco escreve o sentido
    junto do valor ("1.234,56 D", "-R$ 10,00", "(10,00)")."""
    if v is None or v == "":
        return None, None
    if isinstance(v, bool):
        return None, None
    if isinstance(v, (int, float)):
        return Decimal(repr(float(v))).quantize(Decimal("0.01")), None
    if isinstance(v, Decimal):
        return v.quantize(Decimal("0.01")), None
    s = str(v).strip().replace("\xa0", " ")
    if not s:
        return None, None
    sentido = None
    m = re.search(r"\s*\b([CD])\s*\*?$", s, re.I)
    if m and re.search(r"\d", s[:m.start()]):
        sentido = m.group(1).upper()
        s = s[:m.start()]
    negativo = False
    if s.startswith("(") and s.endswith(")"):
        negativo, s = True, s[1:-1]
    s = re.sub(r"(?i)r\$|brl|\s", "", s)
    if s.endswith("-"):
        negativo, s = True, s[:-1]
    if s.startswith("-"):
        negativo, s = not negativo, s[1:]
    elif s.startswith("+"):
        s = s[1:]
    if not re.fullmatch(r"[\d.,]+", s) or not re.search(r"\d", s):
        return None, None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        partes = s.split(",")
        s = s.replace(",", ".") if len(partes) == 2 else s.replace(",", "")
    elif s.count(".") > 1 or re.fullmatch(r"\d{1,3}\.\d{3}", s):
        s = s.replace(".", "")                      # 1.234 e 1.234.567 são milhares
    try:
        n = Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None, None
    return (-n if negativo else n), sentido


def _sentido_texto(v: Any) -> str | None:
    t = _norm(v)
    if not t:
        return None
    if t in ("c", "cr", "cred", "credito", "entrada", "e", "receita", "deposito", "+"):
        return "C"
    if t in ("d", "db", "deb", "debito", "saida", "s", "despesa", "pagamento", "-"):
        return "D"
    if t.startswith("credit") or t.startswith("entrad"):
        return "C"
    if t.startswith("debit") or t.startswith("said"):
        return "D"
    return None


def _texto(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%d/%m/%Y")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return re.sub(r"\s+", " ", str(v)).strip()


# ============================================================================ 2) detectar colunas

def _casar_cabecalho(celula: Any) -> str | None:
    n = _norm(celula)
    if not n or len(n) > 45:
        return None
    for campo, nomes in SINONIMOS.items():
        if n in nomes:
            return campo
    for campo, nomes in SINONIMOS.items():
        if any(n.startswith(x + " ") for x in nomes if len(x) >= 4):
            return campo
    return None


@dataclass
class Deteccao:
    linha_cabecalho: int | None                  # índice da linha do cabeçalho (None = sem cabeçalho)
    colunas: list[str]                           # nome de cada coluna (do cabeçalho ou "Coluna A")
    mapa: dict[str, int] = field(default_factory=dict)


def _letra(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def detectar(linhas: list[list[Any]]) -> Deteccao:
    melhor: tuple[int, int, dict[str, int]] | None = None
    for i, l in enumerate(linhas[:60]):
        mapa: dict[str, int] = {}
        for j, c in enumerate(l):
            campo = _casar_cabecalho(c)
            if campo and campo not in mapa:
                mapa[campo] = j
        tem_valor = "valor" in mapa or "credito" in mapa or "debito" in mapa
        pontos = len(mapa) + (3 if "data" in mapa else 0) + (3 if tem_valor else 0)
        if "data" in mapa and tem_valor and (melhor is None or pontos > melhor[1]):
            melhor = (i, pontos, mapa)
    if melhor:
        i, _, mapa = melhor
        # "Tipo" com valores que não são C/D (ex.: "PIX", "TED") vira complemento
        if "tipo" in mapa:
            amostra = [l[mapa["tipo"]] for l in linhas[i + 1:i + 40] if l[mapa["tipo"]] not in (None, "")]
            if amostra and sum(1 for x in amostra if _sentido_texto(x)) < len(amostra) * 0.8:
                col = mapa.pop("tipo")
                mapa.setdefault("complemento", col)
        cab = [_texto(c) or f"Coluna {_letra(j)}" for j, c in enumerate(linhas[i])]
        return Deteccao(i, cab, _completar_por_conteudo(linhas[i + 1:], mapa))
    # sem cabeçalho reconhecível: decide pelo conteúdo
    cab = [f"Coluna {_letra(j)}" for j in range(len(linhas[0]) if linhas else 0)]
    return Deteccao(None, cab, _completar_por_conteudo(linhas, {}))


def conta_no_cabecalho(linhas: list[list[Any]], ate: int | None) -> str | None:
    """Número da conta escrito acima da tabela (ex.: Itaú: "Conta:" | "0098747-4")."""
    for l in linhas[: (ate if ate is not None else 15)]:
        for j, c in enumerate(l):
            n = _norm(c)
            if n in ("conta", "conta corrente", "numero da conta", "n da conta", "c c", "cc") or n.startswith("conta corrente "):
                prox = next((x for x in l[j + 1:] if x not in (None, "")), None)
                txt = _texto(prox) if prox is not None else _texto(c).split(":", 1)[-1]
                digitos = re.sub(r"\D", "", txt)
                if 4 <= len(digitos) <= 20:
                    return txt.strip()
    return None


def detectar_na_linha(linhas: list[list[Any]], i: int | None) -> Deteccao:
    """Reconhece as colunas usando a linha `i` como cabeçalho (None = sem cabeçalho)."""
    if i is None:
        return Deteccao(None, [f"Coluna {_letra(j)}" for j in range(len(linhas[0]) if linhas else 0)],
                        _completar_por_conteudo(linhas, {}))
    mapa: dict[str, int] = {}
    for j, c in enumerate(linhas[i]):
        campo = _casar_cabecalho(c)
        if campo and campo not in mapa:
            mapa[campo] = j
    cab = [_texto(c) or f"Coluna {_letra(j)}" for j, c in enumerate(linhas[i])]
    return Deteccao(i, cab, _completar_por_conteudo(linhas[i + 1:], mapa))


def _completar_por_conteudo(corpo: list[list[Any]], mapa: dict[str, int]) -> dict[str, int]:
    """Preenche data, descrição e valor pelo conteúdo das colunas quando o cabeçalho não disse."""
    amostra = corpo[:200]
    if not amostra:
        return mapa
    ncol = len(amostra[0])
    usados = set(mapa.values())

    def taxa(j, f):
        vals = [l[j] for l in amostra if l[j] not in (None, "")]
        return (sum(1 for v in vals if f(v)) / len(vals)) if vals else 0.0

    if "data" not in mapa:
        cands = [(taxa(j, para_data), j) for j in range(ncol) if j not in usados]
        t, j = max(cands, default=(0, None))
        if j is not None and t >= 0.6:
            mapa["data"] = j
            usados.add(j)
    if not ({"valor", "credito", "debito"} & mapa.keys()):
        nums = [(taxa(j, lambda v: para_valor(v)[0] is not None and para_data(v) is None), j) for j in range(ncol) if j not in usados]
        nums = [j for t, j in nums if t >= 0.6]
        if nums:
            # com várias colunas numéricas, o saldo costuma ser a última; o valor, a anterior
            if len(nums) >= 2 and "saldo" not in mapa:
                mapa["saldo"] = nums[-1]
                mapa["valor"] = nums[-2]
            else:
                mapa["valor"] = nums[0]
            usados.update(mapa[k] for k in ("valor", "saldo") if k in mapa)
    if "descricao" not in mapa:
        def media_texto(j):
            vals = [_texto(l[j]) for l in amostra if l[j] not in (None, "")]
            textos = [v for v in vals if para_valor(v)[0] is None and para_data(v) is None]
            return (sum(len(v) for v in textos) / max(1, len(vals))) if textos else 0
        cands = [(media_texto(j), j) for j in range(ncol) if j not in usados]
        t, j = max(cands, default=(0, None))
        if j is not None and t >= 2:
            mapa["descricao"] = j
    return mapa


# ============================================================================ 3) interpretar

@dataclass
class Linha:
    numero: int                                  # linha na planilha (1 = primeira)
    data: date | None
    descricao: str
    valor: Decimal | None
    natureza: str | None
    documento: str | None
    saldo: Decimal | None
    motivo: str | None = None                    # por que a linha foi pulada


@dataclass
class Resultado:
    linhas: list[Linha]
    transacoes: list[TransacaoBanco]
    saldo: Decimal | None
    data_saldo: date | None
    avisos: list[str]


def validar_mapa(mapa: dict[str, Any], ncol: int) -> dict[str, int]:
    out: dict[str, int] = {}
    for k, v in (mapa or {}).items():
        if k not in CAMPOS or v in (None, "", -1):
            continue
        try:
            j = int(v)
        except (TypeError, ValueError):
            continue
        if 0 <= j < ncol:
            out[k] = j
    return out


def interpretar(linhas: list[list[Any]], linha_cabecalho: int | None, mapa: dict[str, int],
                inverter: bool = False) -> Resultado:
    if "data" not in mapa:
        raise PlanilhaErro("Indique qual coluna tem a data.")
    if not ({"valor", "credito", "debito"} & mapa.keys()):
        raise PlanilhaErro("Indique a coluna do valor (ou as colunas de crédito e débito).")
    inicio = 0 if linha_cabecalho is None else linha_cabecalho + 1
    out: list[Linha] = []
    trans: list[TransacaoBanco] = []
    avisos: list[str] = []

    def cel(l, campo):
        j = mapa.get(campo)
        return l[j] if j is not None and j < len(l) else None

    for idx in range(inicio, len(linhas)):
        l = linhas[idx]
        d = para_data(cel(l, "data"))
        desc = _texto(cel(l, "descricao"))
        comp = _texto(cel(l, "complemento"))
        if comp and _norm(comp) not in _norm(desc):
            desc = f"{desc} - {comp}" if desc else comp
        doc = _texto(cel(l, "documento"))[:60] or None
        cpf_cnpj = re.sub(r"\D", "", _texto(cel(l, "cpf_cnpj"))) if "cpf_cnpj" in mapa else ""
        saldo = para_valor(cel(l, "saldo"))[0] if "saldo" in mapa else None
        valor, nat = None, None
        if "credito" in mapa or "debito" in mapa:
            c = para_valor(cel(l, "credito"))[0] if "credito" in mapa else None
            dd = para_valor(cel(l, "debito"))[0] if "debito" in mapa else None
            if c:
                valor, nat = abs(c), "C"
            elif dd:
                valor, nat = abs(dd), "D"
            elif "valor" in mapa:
                v, sentido = para_valor(cel(l, "valor"))
                if v:
                    valor, nat = abs(v), sentido or ("D" if v < 0 else "C")
        else:
            v, sentido = para_valor(cel(l, "valor"))
            if v:
                tipo = _sentido_texto(cel(l, "tipo")) if "tipo" in mapa else None
                valor, nat = abs(v), tipo or sentido or ("D" if v < 0 else "C")
                if inverter and not tipo and not sentido:
                    nat = "C" if nat == "D" else "D"
        item = Linha(idx + 1, d, desc, valor, nat, doc, saldo)
        nd = _norm(desc)
        if d is None:
            item.motivo = "sem data"
        elif PULAR.match(nd) or (not nd and valor is None):
            item.motivo = "saldo ou total"
        elif valor is None or valor == 0:
            item.motivo = "sem valor"
        out.append(item)
        if item.motivo:
            continue
        trans.append(TransacaoBanco(data=d, valor=valor, natureza=nat, descricao=(desc or "Sem descrição")[:300],
                                    documento=doc,
                                    dados_brutos={"linha": idx + 1, **({"cpf_cnpj": cpf_cnpj} if len(cpf_cnpj) in (11, 14) else {}),
                                                  **({"favorecido": comp[:120]} if comp else {})}))
    if not trans:
        raise PlanilhaErro("Nenhum movimento encontrado com essas colunas. Confira a coluna da data e a do valor.")
    # saldo informado: o da linha mais recente que tem saldo (a planilha pode vir em ordem crescente ou decrescente)
    saldo, data_saldo = None, None
    com_saldo = [x for x in out if x.saldo is not None and x.data is not None]
    if com_saldo:
        crescente = (com_saldo[0].data <= com_saldo[-1].data)
        ult_data = max(x.data for x in com_saldo)
        do_dia = [x for x in com_saldo if x.data == ult_data]
        alvo = do_dia[-1] if crescente else do_dia[0]
        saldo, data_saldo = alvo.saldo, alvo.data
    if not ({"credito", "debito", "tipo"} & mapa.keys()) and all(t.natureza == "C" for t in trans) and len(trans) >= 5:
        avisos.append("Todos os valores ficaram como entrada. Se as saídas não têm sinal de menos, marque “inverter sinais” "
                      "ou indique a coluna de tipo (C/D).")
    return Resultado(out, trans, saldo, data_saldo, avisos)


def modelo_xlsx() -> bytes:
    """Planilha-modelo para quem vai montar o extrato à mão."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Extrato"
    ws.append(["Data", "Descrição", "Valor", "Documento", "Saldo"])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0F5132")
    hoje = date.today()
    ws.append([hoje - timedelta(days=3), "PIX RECEBIDO - CLIENTE EXEMPLO LTDA", 1500.00, "E123", 11500.00])
    ws.append([hoje - timedelta(days=2), "PAGAMENTO BOLETO - ENERGIA", -389.90, "", 11110.10])
    ws.append([hoje - timedelta(days=1), "TARIFA BANCARIA", -12.50, "", 11097.60])
    for r in ws.iter_rows(min_row=2):
        r[0].number_format = "DD/MM/YYYY"
        r[2].number_format = r[4].number_format = "#,##0.00"
    for col, w in zip("ABCDE", (12, 46, 14, 14, 14)):
        ws.column_dimensions[col].width = w
    ws2 = wb.create_sheet("Como preencher")
    for t in ["Uma linha por movimento do extrato.",
              "Data: dia do movimento (dd/mm/aaaa).",
              "Valor: entradas positivas e saídas com sinal de menos.",
              "   Se preferir, use duas colunas, “Crédito” e “Débito”, no lugar de “Valor”.",
              "Documento e Saldo são opcionais. O saldo da última linha é comparado com o do sistema.",
              "Linhas de saldo anterior e totais são ignoradas na importação."]:
        ws2.append([t])
    ws2.column_dimensions["A"].width = 100
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
