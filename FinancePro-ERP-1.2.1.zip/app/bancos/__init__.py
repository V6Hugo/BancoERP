"""Integração bancária: leitura de extratos (OFX de qualquer banco) e APIs dos bancos (Inter).

Cada fonte devolve uma lista de `TransacaoBanco`; daí em diante o tratamento é o mesmo
(gravar como Movimento, sem duplicar, e conciliar)."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any


@dataclass
class TransacaoBanco:
    data: date
    valor: Decimal                 # positivo
    natureza: str                  # C entrada | D saída
    descricao: str
    id_externo: str | None = None
    documento: str | None = None
    dados_brutos: dict[str, Any] = field(default_factory=dict)

    def chave(self) -> str:
        """Identificador estável: o do banco quando existe; senão, um hash do conteúdo."""
        if self.id_externo:
            return self.id_externo[:120]
        base = f"{self.data.isoformat()}|{self.natureza}|{self.valor:.2f}|{self.descricao}|{self.documento or ''}"
        return "h:" + hashlib.sha1(base.encode()).hexdigest()


@dataclass
class ExtratoBanco:
    banco_codigo: str | None
    agencia: str | None
    conta: str | None
    inicio: date | None
    fim: date | None
    saldo: Decimal | None
    data_saldo: date | None
    transacoes: list[TransacaoBanco] = field(default_factory=list)
