"""API Banking do Banco Inter (conta PJ).

Como o Inter libera: no Internet Banking PJ, em "Soluções para sua empresa > Nova integração",
cria-se uma aplicação com a permissão "Consultar extrato e saldo". O Inter entrega o Client ID,
o Client Secret e um certificado (.zip com o .crt e o .key). Toda chamada usa o certificado (mTLS)
e um token OAuth2 (client_credentials) com o escopo `extrato.read`.
"""
from __future__ import annotations

import io
import time
import zipfile
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any

import httpx

from . import TransacaoBanco

BASE_PRODUCAO = "https://cdpj.partners.bancointer.com.br"
ESCOPO = "extrato.read"
JANELA_DIAS = 89              # o Inter limita cada consulta de extrato a 90 dias


class InterErro(RuntimeError):
    pass


def extrair_certificado(conteudo: bytes, nome: str, destino: Path) -> tuple[Path, Path]:
    """Recebe o .zip que o Inter entrega (ou um .pem com certificado e chave juntos) e grava
    certificado.crt e chave.key em `destino`."""
    destino.mkdir(parents=True, exist_ok=True)
    crt = key = None
    if nome.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
                itens = z.infolist()
                if len(itens) > 30 or any(i.file_size > 2 * 1024 * 1024 for i in itens):
                    raise InterErro("O .zip tem arquivos demais ou grandes demais para ser o certificado do Inter.")
                for i in itens:
                    n = i.filename
                    dado = z.read(i)
                    if n.lower().endswith((".crt", ".cer", ".pem")) and b"CERTIFICATE" in dado:
                        crt = dado
                    elif n.lower().endswith(".key") or b"PRIVATE KEY" in dado:
                        key = dado
        except zipfile.BadZipFile as exc:
            raise InterErro("O arquivo .zip do certificado está corrompido.") from exc
    else:
        if b"CERTIFICATE" in conteudo:
            crt = conteudo
        if b"PRIVATE KEY" in conteudo:
            key = conteudo
    if not crt or not key:
        raise InterErro("Não achei o certificado (.crt) e a chave (.key) no arquivo. Envie o .zip que o Inter "
                        "gerou ao criar a integração, sem descompactar.")
    # a chave privada fica cifrada em disco (com a SECRET_KEY); só é aberta num arquivo temporário na hora de usar
    from app.seguranca import cifrar_bytes
    p_crt, p_key = destino / "certificado.crt", destino / "chave.key.cifrada"
    p_crt.write_bytes(crt)
    p_key.write_bytes(cifrar_bytes(key))
    velha = destino / "chave.key"
    if velha.exists():
        velha.unlink()
    for arq in (p_crt, p_key):
        try:
            arq.chmod(0o600)
        except OSError:
            pass
    return p_crt, p_key


class ClienteInter:
    def __init__(self, client_id: str, client_secret: str, certificado: str | Path, chave: str | Path,
                 conta_corrente: str | None = None, base: str = BASE_PRODUCAO,
                 transport: httpx.BaseTransport | None = None, timeout: float = 30):
        self.client_id, self.client_secret = client_id, client_secret
        self.conta_corrente = conta_corrente
        self.base = base.rstrip("/")
        kw: dict[str, Any] = {"timeout": timeout}
        if transport is not None:
            kw["transport"] = transport                  # testes
        else:
            kw["cert"] = (str(certificado), str(chave))  # mTLS
        self.http = httpx.Client(**kw)
        self._token: str | None = None
        self._expira = 0.0

    # ---------------------------------------------------------------- autenticação
    def token(self) -> str:
        if self._token and time.time() < self._expira - 60:
            return self._token
        try:
            r = self.http.post(f"{self.base}/oauth/v2/token", data={
                "client_id": self.client_id, "client_secret": self.client_secret,
                "grant_type": "client_credentials", "scope": ESCOPO})
        except httpx.HTTPError as exc:
            raise InterErro(f"Não foi possível falar com o Inter: {exc}. Confira o certificado e a internet.") from exc
        if r.status_code in (400, 401, 403):
            raise InterErro("O Inter recusou as credenciais. Confira o Client ID, o Client Secret, o certificado "
                            "e se a integração tem a permissão de consultar extrato.")
        self._ok(r)
        d = r.json()
        self._token, self._expira = d["access_token"], time.time() + int(d.get("expires_in", 3600))
        return self._token

    def _get(self, caminho: str, params: dict[str, Any]) -> dict[str, Any]:
        h = {"Authorization": f"Bearer {self.token()}"}
        if self.conta_corrente:
            h["x-conta-corrente"] = self.conta_corrente
        try:
            r = self.http.get(f"{self.base}{caminho}", params=params, headers=h)
        except httpx.HTTPError as exc:
            raise InterErro(f"Falha de comunicação com o Inter: {exc}") from exc
        self._ok(r)
        return r.json()

    @staticmethod
    def _ok(r: httpx.Response) -> None:
        if r.status_code >= 400:
            try:
                msg = r.json().get("detail") or r.json().get("title") or r.text
            except ValueError:
                msg = r.text
            raise InterErro(f"Inter respondeu {r.status_code}: {str(msg)[:300]}")

    # ---------------------------------------------------------------- consultas
    def saldo(self, em: date | None = None) -> Decimal:
        d = self._get("/banking/v2/saldo", {"dataSaldo": em.isoformat()} if em else {})
        return Decimal(str(d.get("disponivel", 0)))

    def extrato(self, inicio: date, fim: date) -> list[TransacaoBanco]:
        """Extrato completo (com o identificador de cada transação), em janelas de até 90 dias."""
        out: list[TransacaoBanco] = []
        ini = inicio
        while ini <= fim:
            f = min(fim, ini + timedelta(days=JANELA_DIAS))
            pagina, total = 0, 1
            while pagina < total:
                d = self._get("/banking/v2/extrato/completo", {
                    "dataInicio": ini.isoformat(), "dataFim": f.isoformat(),
                    "pagina": pagina, "tamanhoPagina": 1000})
                total = int(d.get("totalPaginas", 1) or 1)
                out += [self._transacao(t) for t in d.get("transacoes", [])]
                pagina += 1
            ini = f + timedelta(days=1)
        return out

    @staticmethod
    def _transacao(t: dict[str, Any]) -> TransacaoBanco:
        dia = t.get("dataTransacao") or t.get("dataEntrada") or t.get("dataInclusao")
        titulo, desc = (t.get("titulo") or "").strip(), (t.get("descricao") or "").strip()
        descricao = f"{titulo}: {desc}" if titulo and desc and desc.upper() not in titulo.upper() else (titulo or desc)
        return TransacaoBanco(
            data=date.fromisoformat(str(dia)[:10]),
            valor=abs(Decimal(str(t.get("valor", "0")))),
            natureza="C" if str(t.get("tipoOperacao", "")).upper() == "C" else "D",
            descricao=(descricao or t.get("tipoTransacao") or "Transação Inter")[:300],
            id_externo=str(t["idTransacao"]) if t.get("idTransacao") else None,
            dados_brutos=t,
        )

    def fechar(self) -> None:
        self.http.close()
