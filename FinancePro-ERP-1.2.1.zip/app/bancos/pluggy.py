"""Open Finance pela Pluggy (agregador autorizado): uma integração só para Itaú, Bradesco, Banco do Brasil,
Santander, Caixa, Inter, Nubank, Sicoob, Sicredi e outros.

Como funciona:
1. A empresa cria uma aplicação no painel da Pluggy (dashboard.pluggy.ai) e informa o Client ID e o Client Secret.
2. O servidor pede um "connect token" (vale 30 min) e a tela abre o widget da Pluggy. A pessoa escolhe o banco
   e autoriza o compartilhamento no próprio app do banco (consentimento do Open Finance).
3. O widget devolve o `item` (a conexão com aquele banco). O servidor lista as contas do item e cada uma é
   ligada a uma conta bancária do FinancePro.
4. Sincronizar lê as transações da conta (GET /v2/transactions, paginado por cursor) e o saldo.

Docs: https://docs.pluggy.ai (autenticação: POST /auth -> apiKey de 2 h, enviada no cabeçalho X-API-KEY).
"""
from __future__ import annotations

import time
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from urllib.parse import parse_qs, urlsplit

import httpx

from . import TransacaoBanco

BASE = "https://api.pluggy.ai"
WIDGET_JS = "https://cdn.pluggy.ai/pluggy-connect/v2.7.0/pluggy-connect.js"
BRT = timezone(timedelta(hours=-3))

ERROS = {
    "CLIENT_KEYS_UNAUTHORIZED": "Client ID ou Client Secret da Pluggy incorretos.",
    "CLIENT_DISABLED": "A aplicação está desativada no painel da Pluggy.",
}
SITUACAO_ITEM = {
    "UPDATED": "Atualizado",
    "UPDATING": "Atualizando no banco",
    "LOGIN_ERROR": "O banco recusou o acesso: conecte de novo",
    "OUTDATED": "Desatualizado: conecte de novo",
    "WAITING_USER_INPUT": "O banco pediu uma confirmação: conecte de novo",
    "WAITING_USER_ACTION": "O banco pediu uma ação: conecte de novo",
}
PRECISA_RECONECTAR = {"LOGIN_ERROR", "OUTDATED", "WAITING_USER_INPUT", "WAITING_USER_ACTION"}


class PluggyErro(RuntimeError):
    def __init__(self, msg: str, status: int | None = None, codigo: str | None = None):
        super().__init__(msg)
        self.status, self.codigo = status, codigo


def _data(texto: str | None) -> date | None:
    """A Pluggy manda a data em ISO UTC. Meia-noite UTC é só a data (não converte, senão vira o dia anterior);
    com horário, converte para o horário de Brasília."""
    if not texto:
        return None
    try:
        dt = datetime.fromisoformat(texto.replace("Z", "+00:00"))
    except ValueError:
        try:
            return date.fromisoformat(texto[:10])
        except ValueError:
            return None
    if dt.tzinfo is None or (dt.hour, dt.minute, dt.second) == (0, 0, 0):
        return dt.date()
    return dt.astimezone(BRT).date()


def transacao(t: dict[str, Any]) -> TransacaoBanco | None:
    """Converte uma transação da Pluggy. Pendentes (ainda não liquidadas) ficam de fora."""
    if (t.get("status") or "POSTED").upper() == "PENDING":
        return None
    d = _data(t.get("date"))
    try:
        bruto = Decimal(str(t.get("amount")))
    except Exception:  # noqa: BLE001
        return None
    if d is None or bruto == 0:
        return None
    tipo = (t.get("type") or "").upper()
    natureza = "C" if tipo == "CREDIT" else "D" if tipo == "DEBIT" else ("D" if bruto < 0 else "C")
    pag = t.get("paymentData") or {}
    contraparte, doc_contraparte = None, None
    for lado in ("payer", "receiver"):
        p = pag.get(lado) or {}
        if p.get("name") and ((lado == "payer") == (natureza == "C")):
            contraparte = p["name"]
            doc_contraparte = "".join(ch for ch in str((p.get("documentNumber") or {}).get("value", "")) if ch.isdigit()) or None
    desc = (t.get("description") or t.get("descriptionRaw") or "").strip() or "Sem descrição"
    if contraparte and contraparte.lower() not in desc.lower():
        desc = f"{desc} - {contraparte}"
    return TransacaoBanco(data=d, valor=abs(bruto).quantize(Decimal("0.01")), natureza=natureza, descricao=desc[:300],
                          id_externo=f"pg:{t['id']}" if t.get("id") else None,
                          documento=(pag.get("referenceNumber") or None) and str(pag["referenceNumber"])[:60],
                          dados_brutos={"categoria": t.get("category"), "metodo": pag.get("paymentMethod"),
                                        "saldo": t.get("balance"),
                                        **({"favorecido": contraparte[:120]} if contraparte else {}),
                                        **({"cpf_cnpj": doc_contraparte} if doc_contraparte and len(doc_contraparte) in (11, 14) else {})})


class ClientePluggy:
    def __init__(self, client_id: str, client_secret: str, base: str = BASE, transport: httpx.BaseTransport | None = None,
                 timeout: float = 40.0):
        self.client_id, self.client_secret = client_id.strip(), client_secret.strip()
        self.http = httpx.Client(base_url=base, timeout=timeout, transport=transport,
                                 headers={"Accept": "application/json", "User-Agent": "FinancePro-ERP"})
        self._chave: str | None = None
        self._chave_em = 0.0

    def fechar(self) -> None:
        self.http.close()

    # -------------------------------------------------------------- base
    def autenticar(self) -> str:
        if self._chave and time.monotonic() - self._chave_em < 100 * 60:
            return self._chave
        r = self._enviar("POST", "/auth", json={"clientId": self.client_id, "clientSecret": self.client_secret}, auth=False)
        self._chave, self._chave_em = r["apiKey"], time.monotonic()
        return self._chave

    def _enviar(self, metodo: str, caminho: str, auth: bool = True, **kw) -> Any:
        cab = {"X-API-KEY": self.autenticar()} if auth else {}
        try:
            r = self.http.request(metodo, caminho, headers=cab, **kw)
        except httpx.HTTPError as exc:
            raise PluggyErro(f"Não consegui falar com a Pluggy ({exc.__class__.__name__}). Confira a internet.") from exc
        if r.status_code >= 400:
            try:
                corpo = r.json()
            except ValueError:
                corpo = {}
            cod = corpo.get("codeDescription") or corpo.get("code")
            msg = ERROS.get(str(cod)) or corpo.get("message") or r.text[:200]
            if r.status_code == 404:
                msg = "A conexão não existe mais na Pluggy. Conecte o banco de novo."
            raise PluggyErro(f"Pluggy: {msg}", r.status_code, str(cod) if cod else None)
        return r.json() if r.content else {}

    # -------------------------------------------------------------- conexão
    def connect_token(self, item_id: str | None = None, usuario: str | None = None) -> str:
        corpo: dict[str, Any] = {"options": {"avoidDuplicates": True}}
        if usuario:
            corpo["options"]["clientUserId"] = usuario
        if item_id:
            corpo["itemId"] = item_id
        return self._enviar("POST", "/connect_token", json=corpo)["accessToken"]

    def item(self, item_id: str) -> dict[str, Any]:
        return self._enviar("GET", f"/items/{item_id}")

    def atualizar_item(self, item_id: str) -> dict[str, Any]:
        """Pede à Pluggy para buscar dados novos no banco (a atualização roda em segundo plano)."""
        return self._enviar("PATCH", f"/items/{item_id}", json={})

    def esperar_item(self, item_id: str, limite_s: float = 45, intervalo: float = 3) -> dict[str, Any]:
        fim = time.monotonic() + limite_s
        it = self.item(item_id)
        while it.get("status") == "UPDATING" and time.monotonic() < fim:
            time.sleep(intervalo)
            it = self.item(item_id)
        return it

    def excluir_item(self, item_id: str) -> None:
        self._enviar("DELETE", f"/items/{item_id}")

    # -------------------------------------------------------------- dados
    def contas(self, item_id: str) -> list[dict[str, Any]]:
        r = self._enviar("GET", "/accounts", params={"itemId": item_id})
        return r.get("results", r if isinstance(r, list) else [])

    def conta(self, account_id: str) -> dict[str, Any]:
        return self._enviar("GET", f"/accounts/{account_id}")

    def transacoes(self, account_id: str, inicio: date, fim: date, limite_paginas: int = 200) -> list[TransacaoBanco]:
        params: dict[str, Any] = {"accountId": account_id, "dateFrom": inicio.isoformat(), "dateTo": fim.isoformat()}
        out: list[TransacaoBanco] = []
        for _ in range(limite_paginas):
            r = self._enviar("GET", "/v2/transactions", params=params)
            for t in r.get("results", []):
                tb = transacao(t)
                if tb:
                    out.append(tb)
            prox = r.get("next")
            if not prox:
                break
            after = None
            if "=" in prox:
                q = parse_qs(urlsplit(prox).query or prox.lstrip("?"))
                after = (q.get("after") or [None])[0]
            after = after or prox
            params = {**params, "after": after}
        return out


def resumo_conta(c: dict[str, Any]) -> dict[str, Any]:
    """O que a tela precisa de uma conta da Pluggy para ligar a uma conta do FinancePro."""
    banco = c.get("bankData") or {}
    tipo = (c.get("type") or "").upper()
    sub = (c.get("subtype") or "").upper()
    return {"id": c.get("id"), "nome": c.get("marketingName") or c.get("name") or "Conta",
            "numero": c.get("number") or banco.get("transferNumber"), "tipo": "cartao" if tipo == "CREDIT" else
            ("poupanca" if sub == "SAVINGS_ACCOUNT" else "corrente"), "tipo_pluggy": sub or tipo,
            "saldo": c.get("balance"), "moeda": c.get("currencyCode") or "BRL"}
