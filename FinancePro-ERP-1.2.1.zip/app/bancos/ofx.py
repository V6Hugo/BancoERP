"""Leitor de arquivos OFX (1.x SGML e 2.x XML), com as particularidades dos bancos brasileiros.

Serve para qualquer banco que exporte OFX (Itaú, Bradesco, Banco do Brasil, Santander, Caixa,
Inter, Nubank, Sicoob, Sicredi...): conta corrente (STMTRS) e cartão (CCSTMTRS), arquivos em
Windows-1252/Latin-1, valores com vírgula decimal, datas com fuso ("20261015120000[-3:BRT]").
"""
from __future__ import annotations

import re
from datetime import date
from decimal import Decimal, InvalidOperation

from . import ExtratoBanco, TransacaoBanco


class OFXErro(ValueError):
    pass


def decodificar(conteudo: bytes) -> str:
    # Bancos (ex.: Inter) declaram CHARSET 1252 e mandam UTF-8: se os bytes são UTF-8 válido e têm
    # acentos, é UTF-8 (texto em 1252 com acento quase nunca é UTF-8 válido). Evita "cartÃ£o".
    if any(b > 127 for b in conteudo):
        try:
            return conteudo.decode("utf-8")
        except UnicodeDecodeError:
            pass
    cabecalho = conteudo[:600].decode("ascii", errors="ignore").upper()
    candidatos: list[str] = []
    m = re.search(r'ENCODING="([^"]+)"', cabecalho)
    if m:
        candidatos.append(m.group(1).lower())
    m = re.search(r"CHARSET:\s*([\w-]+)", cabecalho)
    if m and m.group(1) in ("1252", "WINDOWS-1252"):
        candidatos.append("cp1252")
    if "ENCODING:UTF-8" in cabecalho.replace(" ", ""):
        candidatos.append("utf-8")
    candidatos += ["utf-8", "cp1252", "latin-1"]
    for enc in candidatos:
        try:
            return conteudo.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return conteudo.decode("latin-1", errors="replace")


def _tag(bloco: str, nome: str) -> str | None:
    m = re.search(rf"<{nome}>\s*([^<\r\n]*)", bloco, re.IGNORECASE)
    if not m:
        return None
    valor = m.group(1).strip()
    return valor or None


def _blocos(texto: str, nome: str) -> list[str]:
    # Em SGML os agregados (STMTTRN, BANKACCTFROM...) sempre têm tag de fechamento.
    return re.findall(rf"<{nome}>(.*?)</{nome}>", texto, re.IGNORECASE | re.DOTALL)


def _data(valor: str | None) -> date | None:
    if not valor:
        return None
    digitos = re.match(r"(\d{8})", valor.strip())
    if not digitos:
        raise OFXErro(f"Data OFX inválida: {valor!r}")
    s = digitos.group(1)
    return date(int(s[:4]), int(s[4:6]), int(s[6:8]))


def _valor(valor: str | None) -> Decimal | None:
    if valor is None:
        return None
    s = valor.strip().replace(" ", "")
    if "," in s and "." in s:          # 1.234,56
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:                     # 1234,56
        s = s.replace(",", ".")
    try:
        return Decimal(s)
    except InvalidOperation as exc:
        raise OFXErro(f"Valor OFX inválido: {valor!r}") from exc




def ler_ofx(conteudo: bytes | str) -> list[ExtratoBanco]:
    texto = decodificar(conteudo) if isinstance(conteudo, bytes) else conteudo
    if "<OFX>" not in texto.upper():
        raise OFXErro("O arquivo não é um OFX (não tem a tag <OFX>). Exporte o extrato do banco em formato OFX.")
    extratos: list[ExtratoBanco] = []
    for nome_bloco, cartao in (("STMTRS", False), ("CCSTMTRS", True)):
        for bloco in _blocos(texto, nome_bloco):
            extratos.append(_ler_extrato(bloco, cartao))
    if not extratos:
        raise OFXErro("Nenhum extrato encontrado no arquivo OFX.")
    return extratos


def _ler_extrato(bloco: str, cartao: bool) -> ExtratoBanco:
    conta_bloco = (_blocos(bloco, "CCACCTFROM" if cartao else "BANKACCTFROM") or [""])[0]
    banco = _tag(conta_bloco, "BANKID")
    lista = (_blocos(bloco, "BANKTRANLIST") or [""])[0]
    saldo_bloco = (_blocos(bloco, "LEDGERBAL") or [""])[0]
    extrato = ExtratoBanco(
        banco_codigo=banco.lstrip("0").zfill(3) if banco and banco.isdigit() else banco,
        agencia=_tag(conta_bloco, "BRANCHID"),
        conta=_tag(conta_bloco, "ACCTID"),
        inicio=_data(_tag(lista, "DTSTART")),
        fim=_data(_tag(lista, "DTEND")),
        saldo=_valor(_tag(saldo_bloco, "BALAMT")),
        data_saldo=_data(_tag(saldo_bloco, "DTASOF")),
    )
    for trn in _blocos(lista, "STMTTRN"):
        valor = _valor(_tag(trn, "TRNAMT"))
        data = _data(_tag(trn, "DTPOSTED"))
        if valor is None or data is None:
            raise OFXErro("Transação OFX sem valor (TRNAMT) ou data (DTPOSTED).")
        if valor == 0:
            continue
        nome, memo = _tag(trn, "NAME"), _tag(trn, "MEMO")
        descricao = memo or nome or "SEM DESCRIÇÃO"
        if nome and memo and nome.upper() not in memo.upper():
            descricao = f"{memo} - {nome}"
        extrato.transacoes.append(TransacaoBanco(
            data=data,
            valor=abs(valor),
            natureza="C" if valor > 0 else "D",
            descricao=(corrigir_mojibake(descricao) or "")[:300],
            id_externo=_tag(trn, "FITID"),
            documento=_tag(trn, "CHECKNUM") or _tag(trn, "REFNUM"),
            dados_brutos={k: _tag(trn, k) for k in
                          ("TRNTYPE", "DTPOSTED", "TRNAMT", "FITID", "CHECKNUM", "REFNUM", "NAME", "MEMO")
                          if _tag(trn, k) is not None},
        ))
    return extrato


def corrigir_mojibake(texto: str | None) -> str | None:
    """Conserta texto UTF-8 que foi lido como Windows-1252 ("cartÃ£o" -> "cartão")."""
    if not texto or not any(s in texto for s in ("Ã", "Â")):
        return texto
    try:
        return texto.encode("cp1252").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return texto
