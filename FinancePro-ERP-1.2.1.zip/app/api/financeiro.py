"""Recebimentos, pagamentos, transferências e extrato bancário (conciliação)."""
from __future__ import annotations

import json
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import Acesso, admin, admin_confirmado, financeiro, leitura, obter, sessao
from app.config import get_settings
from app.models import (Baixa, Categoria, CentroCusto, ContaBancaria, Contato, Lancamento, Movimento,
                        RegraClassificacao, Transferencia)
from app.servicos import conciliacao as conc
from app.servicos import financeiro as fin
from app.servicos import lancamentos as svc

rotas = APIRouter(prefix="/api/e/{empresa_id}", tags=["Financeiro"])


# ============================================================================ lançamentos

class LancamentoIn(BaseModel):
    tipo: str = Field(pattern="^(receber|pagar)$")
    descricao: str = Field(min_length=1, max_length=300)
    valor: Decimal = Field(gt=0)
    vencimento: date
    competencia: date | None = None
    contato_id: int | None = None
    categoria_id: int | None = None
    centro_custo_id: int | None = None
    conta_bancaria_id: int | None = None
    documento: str | None = Field(None, max_length=60)
    forma_pagamento: str | None = Field(None, max_length=30)
    observacao: str | None = None
    parcelas: int = Field(1, ge=1, le=120)
    repetir_meses: int = Field(1, ge=1, le=120)
    pago_em: date | None = None


class LancamentoEdit(BaseModel):
    descricao: str | None = Field(None, min_length=1, max_length=300)
    valor: Decimal | None = Field(None, gt=0)
    vencimento: date | None = None
    competencia: date | None = None
    contato_id: int | None = None
    categoria_id: int | None = None
    centro_custo_id: int | None = None
    conta_bancaria_id: int | None = None
    documento: str | None = None
    forma_pagamento: str | None = None
    observacao: str | None = None


class BaixaIn(BaseModel):
    data: date
    valor: Decimal = Field(gt=0)
    conta_bancaria_id: int
    juros: Decimal = Field(Decimal("0"), ge=0)
    desconto: Decimal = Field(Decimal("0"), ge=0)


class BaixaLoteIn(BaseModel):
    ids: list[int] = Field(min_length=1, max_length=500)
    data: date
    conta_bancaria_id: int


def _l_out(l: Lancamento, hoje: date | None = None) -> dict:
    hoje = hoje or date.today()
    r = svc.restante(l)
    atrasado = l.situacao in ("aberto", "parcial") and l.vencimento < hoje
    return {"id": l.id, "tipo": l.tipo, "descricao": l.descricao, "valor": l.valor, "restante": r,
            "pago": l.valor - r, "vencimento": l.vencimento, "competencia": l.competencia,
            "situacao": "vencido" if atrasado else l.situacao,
            "contato_id": l.contato_id, "contato": l.contato.nome if l.contato else None,
            "categoria_id": l.categoria_id, "categoria": f"{l.categoria.codigo} {l.categoria.nome}" if l.categoria else None,
            "centro_custo_id": l.centro_custo_id, "centro_custo": l.centro_custo.nome if l.centro_custo else None,
            "conta_bancaria_id": l.conta_bancaria_id, "conta_bancaria": l.conta_bancaria.nome if l.conta_bancaria else None,
            "documento": l.documento, "forma_pagamento": l.forma_pagamento, "observacao": l.observacao,
            "parcela": l.parcela, "total_parcelas": l.total_parcelas, "recorrente": l.recorrente,
            "data_pagamento": l.baixas[-1].data if l.baixas else None,
            "baixas": [{"id": b.id, "data": b.data, "valor": b.valor, "juros": b.juros, "desconto": b.desconto,
                        "conta_bancaria": b.conta_bancaria.nome, "conciliada": b.movimento_id is not None} for b in l.baixas]}


def _filtro(a: Acesso, tipo, situacao, inicio, fim, data_base, busca, categoria_id, centro_custo_id, contato_id, conta_id):
    hoje = date.today()
    q = select(Lancamento).where(Lancamento.empresa_id == a.empresa_id)
    if tipo:
        q = q.where(Lancamento.tipo == tipo)
    if situacao == "abertos":
        q = q.where(Lancamento.situacao.in_(("aberto", "parcial")))
    elif situacao == "vencidos":
        q = q.where(Lancamento.situacao.in_(("aberto", "parcial")), Lancamento.vencimento < hoje)
    elif situacao == "a_vencer":
        q = q.where(Lancamento.situacao.in_(("aberto", "parcial")), Lancamento.vencimento >= hoje)
    elif situacao in ("pago", "cancelado", "parcial"):
        q = q.where(Lancamento.situacao == situacao)
    elif situacao != "cancelados_tambem":
        q = q.where(Lancamento.situacao != "cancelado")
    col = Lancamento.competencia if data_base == "competencia" else Lancamento.vencimento
    if data_base == "pagamento":
        sub = select(Baixa.lancamento_id).where(Baixa.empresa_id == a.empresa_id)
        if inicio:
            sub = sub.where(Baixa.data >= inicio)
        if fim:
            sub = sub.where(Baixa.data <= fim)
        q = q.where(Lancamento.id.in_(sub))
    else:
        if inicio:
            q = q.where(col >= inicio)
        if fim:
            q = q.where(col <= fim)
    if busca:
        t = f"%{busca.strip()}%"
        q = q.outerjoin(Contato, Contato.id == Lancamento.contato_id).where(or_(
            Lancamento.descricao.ilike(t), Lancamento.documento.ilike(t), Contato.nome.ilike(t)))
    if categoria_id:
        q = q.where(or_(Lancamento.categoria_id == categoria_id,
                        Lancamento.categoria_id.in_(select(Categoria.id).where(Categoria.pai_id == categoria_id))))
    if centro_custo_id:
        q = q.where(Lancamento.centro_custo_id == centro_custo_id)
    if contato_id:
        q = q.where(Lancamento.contato_id == contato_id)
    if conta_id:
        q = q.where(Lancamento.conta_bancaria_id == conta_id)
    return q


@rotas.get("/lancamentos")
def listar(tipo: str | None = Query(None, pattern="^(receber|pagar)$"),
           situacao: str | None = Query(None, pattern="^(abertos|vencidos|a_vencer|parcial|pago|cancelado|todos|cancelados_tambem)$"),
           inicio: date | None = None, fim: date | None = None,
           data_base: str = Query("vencimento", pattern="^(vencimento|competencia|pagamento)$"),
           busca: str | None = None, categoria_id: int | None = None, centro_custo_id: int | None = None,
           contato_id: int | None = None, conta_id: int | None = None,
           ordem: str = Query("vencimento", pattern="^-?(vencimento|valor|descricao|competencia)$"),
           pagina: int = Query(0, ge=0), por_pagina: int = Query(100, ge=1, le=1000),
           a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    q = _filtro(a, tipo, situacao, inicio, fim, data_base, busca, categoria_id, centro_custo_id, contato_id, conta_id)
    todos = s.scalars(q.options(selectinload(Lancamento.baixas))).unique().all()
    total = sum((l.valor for l in todos), Decimal("0"))
    falta = sum((svc.restante(l) for l in todos if l.situacao != "cancelado"), Decimal("0"))
    campo = ordem.lstrip("-")
    col = getattr(Lancamento, campo)
    q = q.order_by(col.desc() if ordem.startswith("-") else col, Lancamento.id)
    itens = s.scalars(q.options(selectinload(Lancamento.baixas), selectinload(Lancamento.contato),
                                selectinload(Lancamento.categoria), selectinload(Lancamento.centro_custo),
                                selectinload(Lancamento.conta_bancaria))
                      .offset(pagina * por_pagina).limit(por_pagina)).unique().all()
    return {"total": len(todos), "valor_total": total, "valor_restante": falta, "valor_pago": total - falta,
            "itens": [_l_out(l) for l in itens]}


@rotas.post("/lancamentos", status_code=201)
def criar(d: LancamentoIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    ls = svc.criar(s, a.empresa_id, a.uid, d.model_dump())
    return [_l_out(l) for l in ls]


@rotas.get("/lancamentos/{lid}")
def ver(lid: int, a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return _l_out(obter(s, Lancamento, lid, a.empresa_id, "Lançamento"))


@rotas.put("/lancamentos/{lid}")
def editar(lid: int, d: LancamentoEdit, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    l = obter(s, Lancamento, lid, a.empresa_id, "Lançamento")
    return _l_out(svc.atualizar(s, l, a.uid, d.model_dump(exclude_unset=True)))


@rotas.delete("/lancamentos/{lid}")
def excluir(lid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    svc.excluir(s, obter(s, Lancamento, lid, a.empresa_id, "Lançamento"), a.uid)
    return {"ok": True}


@rotas.post("/lancamentos/{lid}/baixar")
def baixar(lid: int, d: BaixaIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    l = obter(s, Lancamento, lid, a.empresa_id, "Lançamento")
    svc.baixar(s, l, a.uid, d.data, d.valor, d.conta_bancaria_id, d.juros, d.desconto)
    return _l_out(l)


@rotas.post("/lancamentos/baixar-lote")
def baixar_lote(d: BaixaLoteIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    feitos = 0
    for lid in d.ids:
        l = obter(s, Lancamento, lid, a.empresa_id, "Lançamento")
        if l.situacao in ("aberto", "parcial"):
            svc.baixar(s, l, a.uid, d.data, svc.restante(l), d.conta_bancaria_id)
            feitos += 1
    return {"baixados": feitos}


@rotas.delete("/baixas/{bid}")
def estornar(bid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    b = obter(s, Baixa, bid, a.empresa_id, "Baixa")
    l = b.lancamento
    svc.estornar_baixa(s, b, a.uid)
    return _l_out(l)


@rotas.post("/lancamentos/{lid}/cancelar")
def cancelar(lid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    l = obter(s, Lancamento, lid, a.empresa_id, "Lançamento")
    svc.cancelar(s, l, a.uid)
    return _l_out(l)


@rotas.post("/lancamentos/{lid}/reativar")
def reativar(lid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    l = obter(s, Lancamento, lid, a.empresa_id, "Lançamento")
    svc.reativar(s, l, a.uid)
    return _l_out(l)


# ============================================================================ transferências

class TransferenciaIn(BaseModel):
    conta_origem_id: int
    conta_destino_id: int
    data: date
    valor: Decimal = Field(gt=0)
    descricao: str | None = Field(None, max_length=200)


@rotas.get("/transferencias")
def transferencias(inicio: date | None = None, fim: date | None = None, a: Acesso = Depends(leitura),
                   s: Session = Depends(sessao)):
    q = select(Transferencia).where(Transferencia.empresa_id == a.empresa_id)
    if inicio:
        q = q.where(Transferencia.data >= inicio)
    if fim:
        q = q.where(Transferencia.data <= fim)
    nomes = dict(s.execute(select(ContaBancaria.id, ContaBancaria.nome).where(ContaBancaria.empresa_id == a.empresa_id)).all())
    return [{"id": t.id, "data": t.data, "valor": t.valor, "descricao": t.descricao, "conta_origem_id": t.conta_origem_id,
             "conta_destino_id": t.conta_destino_id, "origem": nomes.get(t.conta_origem_id), "destino": nomes.get(t.conta_destino_id)}
            for t in s.scalars(q.order_by(Transferencia.data.desc(), Transferencia.id.desc()))]


@rotas.post("/transferencias", status_code=201)
def transferir(d: TransferenciaIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    t = fin.transferir(s, a.empresa_id, a.uid, d.conta_origem_id, d.conta_destino_id, d.data, d.valor, d.descricao)
    return {"id": t.id}


@rotas.delete("/transferencias/{tid}")
def excluir_transferencia(tid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    fin.excluir_transferencia(s, obter(s, Transferencia, tid, a.empresa_id, "Transferência"), a.uid)
    return {"ok": True}


# ============================================================================ extrato e conciliação

@rotas.get("/movimentos")
def movimentos(conta_id: int | None = None, situacao: str | None = Query(None, pattern="^(pendente|conciliado|ignorado)$"),
               inicio: date | None = None, fim: date | None = None, busca: str | None = None,
               pagina: int = Query(0, ge=0), por_pagina: int = Query(200, ge=1, le=2000),
               a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    q = select(Movimento).where(Movimento.empresa_id == a.empresa_id)
    if conta_id:
        q = q.where(Movimento.conta_bancaria_id == conta_id)
    if situacao:
        q = q.where(Movimento.situacao == situacao)
    if inicio:
        q = q.where(Movimento.data >= inicio)
    if fim:
        q = q.where(Movimento.data <= fim)
    if busca:
        q = q.where(Movimento.descricao.ilike(f"%{busca.strip()}%"))
    total = s.scalar(select(func.count()).select_from(q.subquery()))
    contagem = dict(s.execute(select(Movimento.situacao, func.count()).where(Movimento.empresa_id == a.empresa_id,
                    *( [Movimento.conta_bancaria_id == conta_id] if conta_id else [])).group_by(Movimento.situacao)).all())
    ms = s.scalars(q.order_by(Movimento.data.desc(), Movimento.id.desc()).offset(pagina * por_pagina).limit(por_pagina)).all()
    regras = list(s.scalars(select(RegraClassificacao).where(RegraClassificacao.empresa_id == a.empresa_id,
                                                              RegraClassificacao.ativo.is_(True))))
    contatos = s.scalars(select(Contato).where(Contato.empresa_id == a.empresa_id, Contato.ativo.is_(True))).all()
    baixas = {b.movimento_id: b for b in s.scalars(select(Baixa).where(Baixa.movimento_id.in_([m.id for m in ms])))}
    out = []
    for m in ms:
        item = {"id": m.id, "conta_bancaria_id": m.conta_bancaria_id, "conta": m.conta_bancaria.nome, "data": m.data,
                "valor": m.valor, "natureza": m.natureza, "descricao": m.descricao, "documento": m.documento,
                "situacao": m.situacao, "origem": m.origem, "transferencia_id": m.transferencia_id,
                "favorecido": (m.dados_brutos or {}).get("favorecido"), "cpf_cnpj": (m.dados_brutos or {}).get("cpf_cnpj")}
        if m.situacao == "pendente":
            item["sugestao"] = conc.sugestao(s, m, regras, contatos)
            item["candidatos"] = [{"id": l.id, "descricao": l.descricao, "vencimento": l.vencimento, "valor": svc.restante(l),
                                   "contato": l.contato.nome if l.contato else None} for l in conc.candidatos(s, m, 5)]
        elif m.id in baixas:
            b = baixas[m.id]
            item["lancamento"] = {"id": b.lancamento_id, "descricao": b.lancamento.descricao,
                                  "categoria": f"{b.lancamento.categoria.codigo} {b.lancamento.categoria.nome}" if b.lancamento.categoria else None}
        out.append(item)
    return {"total": total, "por_situacao": contagem, "itens": out}


def _ler_upload(arquivo: UploadFile) -> bytes:
    lim = get_settings().tamanho_max_upload_mb * 1024 * 1024
    conteudo = arquivo.file.read(lim + 1)
    if len(conteudo) > lim:
        raise HTTPException(413, f"Arquivo maior que {get_settings().tamanho_max_upload_mb} MB.")
    if not conteudo.strip():
        raise HTTPException(422, "O arquivo está vazio.")
    return conteudo


def _mapa(texto: str | None) -> dict | None:
    if not texto:
        return None
    try:
        m = json.loads(texto)
    except ValueError as exc:
        raise HTTPException(422, "Mapeamento de colunas inválido.") from exc
    return m if isinstance(m, dict) else None


@rotas.post("/contas/{cid}/extrato/previa")
def previa_extrato(cid: int, arquivo: UploadFile = File(...), mapa: str | None = Form(None), inverter: bool = Form(False),
                   a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    """Lê o extrato (OFX, Excel ou CSV) sem gravar: o que será importado, colunas reconhecidas e totais."""
    conta = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    return conc.previa_extrato(s, conta, _ler_upload(arquivo), arquivo.filename or "extrato", _mapa(mapa), inverter)


@rotas.post("/contas/{cid}/importar")
def importar(cid: int, arquivo: UploadFile = File(...), forcar: bool = Form(False), mapa: str | None = Form(None),
             inverter: bool = Form(False), pular_parecidos: bool = Form(True),
             a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    conta = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    return conc.importar_arquivo(s, conta, _ler_upload(arquivo), arquivo.filename or "extrato", a.uid, forcar,
                                 _mapa(mapa), inverter, pular_parecidos)


@rotas.get("/importacoes")
def importacoes(conta_id: int | None = None, a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return conc.importacoes(s, a.empresa_id, conta_id)


@rotas.delete("/importacoes/{iid}")
def desfazer_importacao(iid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    from app.models import ImportacaoExtrato
    return conc.desfazer_importacao(s, obter(s, ImportacaoExtrato, iid, a.empresa_id, "Importação"), a.uid)


@rotas.get("/modelo-extrato.xlsx")
def modelo_extrato(a: Acesso = Depends(leitura)):
    from app.bancos.planilha import modelo_xlsx
    return Response(modelo_xlsx(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": 'attachment; filename="modelo-extrato-financepro.xlsx"'})


@rotas.post("/contas/{cid}/inter")
def configurar_inter(cid: int, client_id: str = Form(...), client_secret: str | None = Form(None),
                     conta_corrente: str | None = Form(None), certificado: UploadFile | None = File(None),
                     a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    conta = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    conteudo = certificado.file.read(5 * 1024 * 1024) if certificado else None
    conc.configurar_inter(s, conta, a.uid, client_id, client_secret, conteudo or None,
                          certificado.filename if certificado else None, conta_corrente)
    return {"ok": True}


@rotas.delete("/contas/{cid}/inter")
def remover_inter(cid: int, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    from app.servicos import auditar
    conta = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    if conta.integracao == "inter":
        conta.integracao, conta.integracao_config = "nenhuma", {}
        auditar(s, a.empresa_id, a.uid, "conta", conta.id, "remover_inter", {"conta": conta.nome})
    return {"ok": True}


@rotas.post("/contas/{cid}/sincronizar")
def sincronizar(cid: int, inicio: date | None = None, fim: date | None = None,
                a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    conta = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    if conta.integracao == "openfinance":
        from app.servicos import openfinance as of
        return of.sincronizar(s, conta, a.uid, inicio, fim)
    return conc.sincronizar_inter(s, conta, a.uid, inicio, fim)


class ConciliarIn(BaseModel):
    lancamento_id: int


class LancarMovIn(BaseModel):
    categoria_id: int
    centro_custo_id: int | None = None
    contato_id: int | None = None
    descricao: str | None = None
    criar_regra: str | None = None
    regra_id: int | None = None


class TransfMovIn(BaseModel):
    outra_conta_id: int


class IdsIn(BaseModel):
    ids: list[int] | None = None


@rotas.post("/movimentos/{mid}/conciliar")
def conciliar(mid: int, d: ConciliarIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    m = obter(s, Movimento, mid, a.empresa_id, "Movimento")
    conc.conciliar(s, m, obter(s, Lancamento, d.lancamento_id, a.empresa_id, "Lançamento"), a.uid)
    return {"ok": True}


@rotas.post("/movimentos/{mid}/lancar")
def lancar(mid: int, d: LancarMovIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    m = obter(s, Movimento, mid, a.empresa_id, "Movimento")
    if d.centro_custo_id:
        obter(s, CentroCusto, d.centro_custo_id, a.empresa_id, "Centro de custo")
    l = conc.lancar_do_movimento(s, m, a.uid, d.model_dump())
    return {"lancamento_id": l.id}


@rotas.post("/movimentos/{mid}/transferencia")
def mov_transferencia(mid: int, d: TransfMovIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    """O movimento é dinheiro indo para (ou vindo de) outra conta da empresa."""
    m = obter(s, Movimento, mid, a.empresa_id, "Movimento")
    if m.situacao != "pendente":
        raise HTTPException(422, "Este movimento já foi conciliado ou ignorado.")
    origem, destino = (m.conta_bancaria_id, d.outra_conta_id) if m.natureza == "D" else (d.outra_conta_id, m.conta_bancaria_id)
    t = fin.transferir(s, a.empresa_id, a.uid, origem, destino, m.data, m.valor, m.descricao[:200])
    if m.situacao == "pendente":                     # garante este lado (o outro, se houver, já foi ligado)
        m.situacao, m.transferencia_id = "conciliado", t.id
    return {"transferencia_id": t.id}


@rotas.post("/movimentos/{mid}/ignorar")
def ignorar(mid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    conc.ignorar(s, obter(s, Movimento, mid, a.empresa_id, "Movimento"), a.uid)
    return {"ok": True}


@rotas.post("/movimentos/{mid}/desfazer")
def desfazer(mid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    conc.desfazer(s, obter(s, Movimento, mid, a.empresa_id, "Movimento"), a.uid)
    return {"ok": True}


@rotas.post("/movimentos/conciliar-auto")
def conciliar_auto(a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    return conc.conciliar_automatico(s, a.empresa_id)


@rotas.post("/movimentos/lancar-sugeridos")
def lancar_sugeridos(d: IdsIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    return conc.lancar_sugeridos(s, a.empresa_id, a.uid, d.ids)


# ============================================================================ saldos e fluxo

@rotas.get("/saldos")
def saldos(ate: date | None = None, a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return fin.saldos(s, a.empresa_id, ate)


@rotas.get("/fluxo")
def fluxo(inicio: date | None = None, fim: date | None = None,
          agrupamento: str = Query("mes", pattern="^(dia|semana|mes)$"),
          a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    hoje = date.today()
    inicio = inicio or hoje.replace(day=1) - timedelta(days=150)
    inicio = inicio.replace(day=1) if agrupamento == "mes" else inicio
    fim = fim or (hoje.replace(day=28) + timedelta(days=100)).replace(day=1) - timedelta(days=1)
    if (fim - inicio).days > 800 and agrupamento == "dia":
        raise HTTPException(422, "Para mais de 2 anos, agrupe por semana ou mês.")
    return fin.fluxo_caixa(s, a.empresa_id, inicio, fim, agrupamento)
