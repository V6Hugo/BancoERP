"""Primeiro acesso, login, sessão, empresas e usuários."""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import (Acesso, admin, admin_confirmado, confirmado, ip_de, sessao, sessao_atual,
                          usuario_atual)
from app.config import get_settings
from app.documentos import cnpj_valido, somente_digitos
from app.models import Empresa, SessaoUsuario, Usuario, Vinculo
from app.seguranca import (COOKIE, COOKIE_2FA, cifrar, confere_senha, conferir_totp, decifrar, hash_senha,
                           ler_token_2fa, novo_segredo_totp, novos_codigos_recuperacao, qr_svg, senha_fraca,
                           token_2fa, uri_totp)
from app.servicos import acesso as ac
from app.servicos import auditar
from app.servicos.empresas import criar_empresa

rotas = APIRouter(prefix="/api", tags=["Acesso"])


class SetupIn(BaseModel):
    nome: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=160)
    senha: str = Field(max_length=200)
    empresa: str = Field(min_length=2, max_length=160)
    cnpj: str | None = None


class LoginIn(BaseModel):
    email: str = Field(max_length=200)
    senha: str = Field(max_length=200)


class CodigoIn(BaseModel):
    codigo: str = Field(max_length=20)


class SenhaIn(BaseModel):
    atual: str = Field(max_length=200)
    nova: str = Field(max_length=200)


class ConfirmarIn(BaseModel):
    senha: str = Field(max_length=200)
    codigo: str | None = Field(None, max_length=20)


class EmpresaIn(BaseModel):
    nome: str = Field(min_length=2, max_length=160)
    cnpj: str | None = None
    razao_social: str | None = None


class UsuarioIn(BaseModel):
    nome: str | None = None
    email: str = Field(max_length=160)
    senha: str | None = Field(None, max_length=200)
    papel: str = Field("financeiro", pattern="^(admin|financeiro|leitura)$")


def _cookie(resp: Response, nome: str, valor: str, segundos: int) -> None:
    resp.set_cookie(nome, valor, httponly=True, samesite="strict", secure=get_settings().cookie_seguro,
                    max_age=segundos, path="/")


def _entrar(s: Session, resp: Response, u: Usuario, request: Request) -> dict:
    token = ac.abrir_sessao(s, u, ip_de(request), request.headers.get("user-agent"))
    _cookie(resp, COOKIE, token, get_settings().sessao_horas * 3600)
    resp.delete_cookie(COOKIE_2FA, path="/")
    return _eu(s, u)


def _eu(s: Session, u: Usuario) -> dict:
    if u.admin_sistema:
        emps = s.scalars(select(Empresa).order_by(Empresa.nome)).all()
        papeis = {v.empresa_id: v.papel for v in u.vinculos}
        lista = [{"id": e.id, "nome": e.nome, "cnpj": e.cnpj, "papel": papeis.get(e.id, "admin")} for e in emps if e.ativo]
    else:
        lista = sorted(({"id": v.empresa.id, "nome": v.empresa.nome, "cnpj": v.empresa.cnpj, "papel": v.papel}
                        for v in u.vinculos if v.empresa.ativo), key=lambda x: x["nome"])
    return {"id": u.id, "nome": u.nome, "email": u.email, "admin_sistema": u.admin_sistema, "empresas": lista,
            "totp_ativo": u.totp_ativo, "codigos_restantes": len(u.codigos_recuperacao or []) if u.totp_ativo else None,
            "inatividade_min": get_settings().sessao_inatividade_min}


@rotas.get("/estado")
def estado(request: Request, s: Session = Depends(sessao)):
    configurado = bool(s.scalar(select(func.count(Usuario.id))))
    ss = ac.sessao_valida(s, request.cookies.get(COOKIE))
    return {"configurado": configurado, "usuario": _eu(s, ss.usuario) if ss else None,
            "etapa_2fa": bool(ler_token_2fa(request.cookies.get(COOKIE_2FA, ""))) and not ss}


@rotas.post("/setup")
def setup(d: SetupIn, request: Request, resp: Response, s: Session = Depends(sessao)):
    """Primeiro acesso: cria o administrador e a primeira empresa."""
    if s.scalar(select(func.count(Usuario.id))):
        raise HTTPException(409, "O sistema já foi configurado. Entre com seu usuário.")
    if (msg := senha_fraca(d.senha, d.email, d.nome)):
        raise HTTPException(422, msg)
    u = Usuario(nome=d.nome.strip(), email=d.email.strip().lower(), senha_hash=hash_senha(d.senha), admin_sistema=True,
                senha_alterada_em=datetime.now(timezone.utc))
    s.add(u)
    s.flush()
    criar_empresa(s, d.empresa, d.cnpj, dono_id=u.id)
    s.flush()
    s.refresh(u)
    ac.evento(s, u.id, "primeiro_acesso", {"email": u.email, "ip": ip_de(request)})
    return _entrar(s, resp, u, request)


@rotas.post("/login")
def login(d: LoginIn, request: Request, resp: Response, s: Session = Depends(sessao)):
    u = ac.conferir_login(s, d.email, d.senha, ip_de(request))
    if u.totp_ativo:
        _cookie(resp, COOKIE_2FA, token_2fa(u.id), 300)
        return {"etapa": "2fa"}
    return _entrar(s, resp, u, request)


@rotas.post("/login/2fa")
def login_2fa(d: CodigoIn, request: Request, resp: Response, s: Session = Depends(sessao)):
    uid = ler_token_2fa(request.cookies.get(COOKIE_2FA, ""))
    u = s.get(Usuario, uid) if uid else None
    if not u or not u.ativo or not u.totp_ativo:
        raise HTTPException(401, "O tempo para digitar o código acabou. Entre de novo com e-mail e senha.")
    ac.conferir_segundo_fator(s, u, d.codigo, ip_de(request))
    return _entrar(s, resp, u, request)


@rotas.post("/logout")
def logout(request: Request, resp: Response, s: Session = Depends(sessao)):
    ss = ac.sessao_valida(s, request.cookies.get(COOKIE))
    if ss:
        ac.encerrar(s, ss, "saiu")
        ac.evento(s, ss.usuario_id, "logout", {"ip": ip_de(request)})
    resp.delete_cookie(COOKIE, path="/")
    resp.delete_cookie(COOKIE_2FA, path="/")
    return {"ok": True}


@rotas.get("/eu")
def eu(u: Usuario = Depends(usuario_atual), s: Session = Depends(sessao)):
    return _eu(s, u)


@rotas.post("/eu/confirmar")
def confirmar_senha(d: ConfirmarIn, request: Request, ss: SessaoUsuario = Depends(sessao_atual), s: Session = Depends(sessao)):
    """Confirma a senha (e o código, se houver) para liberar ações sensíveis por alguns minutos."""
    ac.confirmar(s, ss, d.senha, d.codigo, ip_de(request))
    return {"ok": True, "vale_min": ac.CONFIRMACAO_VALE_MIN}


@rotas.post("/eu/senha")
def trocar_senha(d: SenhaIn, request: Request, ss: SessaoUsuario = Depends(sessao_atual), s: Session = Depends(sessao)):
    u = ss.usuario
    if not confere_senha(d.atual, u.senha_hash):
        ac.evento(s, u.id, "login_falhou", {"email": u.email, "ip": ip_de(request), "motivo": "troca_senha"})
        raise HTTPException(422, "A senha atual não confere.")
    if (msg := senha_fraca(d.nova, u.email, u.nome)):
        raise HTTPException(422, msg)
    if confere_senha(d.nova, u.senha_hash):
        raise HTTPException(422, "A nova senha precisa ser diferente da atual.")
    u.senha_hash, u.senha_alterada_em = hash_senha(d.nova), datetime.now(timezone.utc)
    outras = ac.encerrar_todas(s, u.id, "senha_trocada", exceto_id=ss.id)
    ac.evento(s, u.id, "senha_trocada", {"ip": ip_de(request), "sessoes_encerradas": outras})
    return {"ok": True, "sessoes_encerradas": outras}


# ---------------------------------------------------------------- sessões do próprio usuário

def _sessao_out(x: SessaoUsuario, atual_id: int | None = None) -> dict:
    return {"id": x.id, "criada_em": x.criada_em, "ultimo_uso": x.ultimo_uso, "ip": x.ip, "navegador": x.navegador,
            "atual": x.id == atual_id}


@rotas.get("/eu/sessoes")
def minhas_sessoes(ss: SessaoUsuario = Depends(sessao_atual), s: Session = Depends(sessao)):
    return [_sessao_out(x, ss.id) for x in ac.sessoes_ativas(s, ss.usuario_id)]


@rotas.post("/eu/sessoes/encerrar-outras")
def encerrar_outras(request: Request, ss: SessaoUsuario = Depends(sessao_atual), s: Session = Depends(sessao)):
    n = ac.encerrar_todas(s, ss.usuario_id, "encerrada_pelo_usuario", exceto_id=ss.id)
    ac.evento(s, ss.usuario_id, "sessoes_encerradas", {"ip": ip_de(request), "quantidade": n})
    return {"encerradas": n}


# ---------------------------------------------------------------- verificação em duas etapas

@rotas.post("/eu/2fa/iniciar")
def iniciar_2fa(ss: SessaoUsuario = Depends(confirmado), s: Session = Depends(sessao)):
    u = ss.usuario
    if u.totp_ativo:
        raise HTTPException(422, "A verificação em duas etapas já está ligada.")
    segredo = novo_segredo_totp()
    u.totp_segredo, u.totp_ultimo_passo = cifrar(segredo), None
    uri = uri_totp(segredo, u.email)
    return {"segredo": " ".join(segredo[i:i + 4] for i in range(0, len(segredo), 4)), "uri": uri, "qr_svg": qr_svg(uri)}


@rotas.post("/eu/2fa/ativar")
def ativar_2fa(d: CodigoIn, request: Request, ss: SessaoUsuario = Depends(sessao_atual), s: Session = Depends(sessao)):
    u = ss.usuario
    if u.totp_ativo or not u.totp_segredo:
        raise HTTPException(422, "Comece pela leitura do QR code.")
    passo = conferir_totp(decifrar(u.totp_segredo), d.codigo)
    if passo is None:
        raise HTTPException(422, "Código incorreto. Confira se o horário do celular está automático e tente o próximo código.")
    codigos, hashes = novos_codigos_recuperacao()
    u.totp_ativo, u.totp_ultimo_passo, u.codigos_recuperacao = True, passo, hashes
    outras = ac.encerrar_todas(s, u.id, "2fa_ligada", exceto_id=ss.id)
    ac.evento(s, u.id, "2fa_ligada", {"ip": ip_de(request), "sessoes_encerradas": outras})
    return {"codigos_recuperacao": codigos}


@rotas.post("/eu/2fa/novos-codigos")
def novos_codigos(request: Request, ss: SessaoUsuario = Depends(confirmado), s: Session = Depends(sessao)):
    u = ss.usuario
    if not u.totp_ativo:
        raise HTTPException(422, "A verificação em duas etapas não está ligada.")
    codigos, hashes = novos_codigos_recuperacao()
    u.codigos_recuperacao = hashes
    ac.evento(s, u.id, "2fa_novos_codigos", {"ip": ip_de(request)})
    return {"codigos_recuperacao": codigos}


@rotas.post("/eu/2fa/desligar")
def desligar_2fa(request: Request, ss: SessaoUsuario = Depends(confirmado), s: Session = Depends(sessao)):
    u = ss.usuario
    u.totp_ativo, u.totp_segredo, u.totp_ultimo_passo, u.codigos_recuperacao = False, None, None, []
    ac.evento(s, u.id, "2fa_desligada", {"ip": ip_de(request)})
    return {"ok": True}


@rotas.post("/empresas")
def nova_empresa(d: EmpresaIn, u: Usuario = Depends(usuario_atual), s: Session = Depends(sessao)):
    if not u.admin_sistema:
        raise HTTPException(403, "Só o administrador do sistema cria empresas.")
    e = criar_empresa(s, d.nome, d.cnpj, d.razao_social, dono_id=u.id)
    return {"id": e.id, "nome": e.nome}


@rotas.put("/e/{empresa_id}")
def editar_empresa(d: EmpresaIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    e = s.get(Empresa, a.empresa_id)
    doc = somente_digitos(d.cnpj) or None
    if doc and not cnpj_valido(doc):
        raise HTTPException(422, "CNPJ inválido.")
    if doc and s.scalar(select(Empresa.id).where(Empresa.cnpj == doc, Empresa.id != e.id)):
        raise HTTPException(422, "Já existe outra empresa com este CNPJ.")
    e.nome, e.cnpj, e.razao_social = d.nome.strip(), doc, (d.razao_social or "").strip() or None
    auditar(s, e.id, a.uid, "empresa", e.id, "alterar", d.model_dump())
    return {"id": e.id, "nome": e.nome, "cnpj": e.cnpj, "razao_social": e.razao_social}


@rotas.get("/e/{empresa_id}")
def ver_empresa(a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    e = s.get(Empresa, a.empresa_id)
    return {"id": e.id, "nome": e.nome, "cnpj": e.cnpj, "razao_social": e.razao_social}


@rotas.get("/e/{empresa_id}/usuarios")
def usuarios(a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    vs = s.scalars(select(Vinculo).where(Vinculo.empresa_id == a.empresa_id)).all()
    return [{"id": v.usuario.id, "nome": v.usuario.nome, "email": v.usuario.email, "papel": v.papel,
             "ativo": v.usuario.ativo, "ultimo_acesso": v.usuario.ultimo_acesso, "totp_ativo": v.usuario.totp_ativo,
             "admin_sistema": v.usuario.admin_sistema, "sessoes": len(ac.sessoes_ativas(s, v.usuario.id)),
             "senha_alterada_em": v.usuario.senha_alterada_em} for v in vs]


@rotas.post("/e/{empresa_id}/usuarios")
def adicionar_usuario(d: UsuarioIn, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    email = d.email.strip().lower()
    if "@" not in email or len(email) < 5:
        raise HTTPException(422, "E-mail inválido.")
    u = s.scalar(select(Usuario).where(Usuario.email == email))
    if u is None:
        if not d.nome or not d.senha:
            raise HTTPException(422, "Usuário novo: informe nome e uma senha inicial.")
        if (msg := senha_fraca(d.senha, email, d.nome)):
            raise HTTPException(422, msg)
        u = Usuario(nome=d.nome.strip(), email=email, senha_hash=hash_senha(d.senha))
        s.add(u)
        s.flush()
    v = s.get(Vinculo, (u.id, a.empresa_id))
    antes = v.papel if v else None
    if v:
        v.papel = d.papel
    else:
        s.add(Vinculo(usuario_id=u.id, empresa_id=a.empresa_id, papel=d.papel))
    auditar(s, a.empresa_id, a.uid, "usuario", u.id, "vincular", {"email": email, "papel": d.papel, "papel_antes": antes})
    return {"id": u.id, "email": email, "papel": d.papel}


def _usuario_da_empresa(s: Session, a: Acesso, usuario_id: int) -> Usuario:
    v = s.get(Vinculo, (usuario_id, a.empresa_id))
    if not v:
        raise HTTPException(404, "Usuário não tem acesso a esta empresa.")
    return v.usuario


@rotas.delete("/e/{empresa_id}/usuarios/{usuario_id}")
def remover_usuario(usuario_id: int, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    if usuario_id == a.uid:
        raise HTTPException(422, "Você não pode tirar o seu próprio acesso.")
    u = _usuario_da_empresa(s, a, usuario_id)
    s.delete(s.get(Vinculo, (usuario_id, a.empresa_id)))
    auditar(s, a.empresa_id, a.uid, "usuario", usuario_id, "desvincular", {"email": u.email})
    return {"ok": True}


@rotas.post("/e/{empresa_id}/usuarios/{usuario_id}/encerrar-sessoes")
def encerrar_sessoes_usuario(usuario_id: int, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    u = _usuario_da_empresa(s, a, usuario_id)
    n = ac.encerrar_todas(s, u.id, "encerrada_pelo_admin", exceto_id=a.sessao.id if a.sessao else None)
    auditar(s, a.empresa_id, a.uid, "usuario", u.id, "encerrar_sessoes", {"email": u.email, "quantidade": n})
    return {"encerradas": n}


@rotas.post("/e/{empresa_id}/usuarios/{usuario_id}/redefinir-2fa")
def redefinir_2fa(usuario_id: int, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    """Para quem perdeu o celular e os códigos de recuperação. Só o administrador do sistema."""
    if not a.usuario.admin_sistema:
        raise HTTPException(403, "Só o administrador do sistema pode redefinir a verificação em duas etapas.")
    if usuario_id == a.uid:
        raise HTTPException(422, "Para a sua própria conta, use Minha conta.")
    u = _usuario_da_empresa(s, a, usuario_id)
    u.totp_ativo, u.totp_segredo, u.totp_ultimo_passo, u.codigos_recuperacao = False, None, None, []
    ac.encerrar_todas(s, u.id, "2fa_redefinida")
    auditar(s, a.empresa_id, a.uid, "usuario", u.id, "redefinir_2fa", {"email": u.email})
    return {"ok": True}


@rotas.post("/e/{empresa_id}/usuarios/{usuario_id}/ativo")
def ativar_usuario(usuario_id: int, ativo: bool, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    """Bloqueia (ex.: funcionário que saiu) ou libera um usuário. Bloquear encerra as sessões dele."""
    if not a.usuario.admin_sistema:
        raise HTTPException(403, "Só o administrador do sistema pode bloquear usuários.")
    if usuario_id == a.uid:
        raise HTTPException(422, "Você não pode bloquear a si mesmo.")
    u = _usuario_da_empresa(s, a, usuario_id)
    u.ativo = ativo
    if not ativo:
        ac.encerrar_todas(s, u.id, "usuario_bloqueado")
    auditar(s, a.empresa_id, a.uid, "usuario", u.id, "desbloquear" if ativo else "bloquear", {"email": u.email})
    return {"ok": True}


SENSIVEIS = {"login", "login_falhou", "login_bloqueado", "logout", "primeiro_acesso", "senha_trocada", "senha_confirmada",
             "2fa_ligada", "2fa_desligada", "2fa_falhou", "2fa_codigo_recuperacao", "2fa_novos_codigos", "sessoes_encerradas",
             "vincular", "desvincular", "encerrar_sessoes", "redefinir_2fa", "bloquear", "desbloquear",
             "configurar_inter", "remover_inter", "configurar_open_finance", "remover_open_finance", "ligar_open_finance",
             "desligar_open_finance", "desfazer", "exportar"}


@rotas.get("/e/{empresa_id}/seguranca")
def painel_seguranca(a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    """Eventos de segurança da empresa e dos seus usuários, e como o sistema está configurado."""
    from datetime import timedelta
    from sqlalchemy import or_
    from app.models import Auditoria
    from app.seguranca import problema_da_chave
    st = get_settings()
    ids = [v.usuario_id for v in s.scalars(select(Vinculo).where(Vinculo.empresa_id == a.empresa_id))]
    emails = [e for (e,) in s.execute(select(Usuario.email).where(Usuario.id.in_(ids)))] if ids else []
    desde = datetime.now(timezone.utc) - timedelta(days=60)
    q = select(Auditoria).where(Auditoria.criado_em >= desde, Auditoria.acao.in_(SENSIVEIS), or_(
        Auditoria.empresa_id == a.empresa_id,
        (Auditoria.empresa_id.is_(None) & (Auditoria.usuario_id.in_(ids) | Auditoria.dados["email"].as_string().in_(emails or [""])))))
    eventos = s.scalars(q.order_by(Auditoria.criado_em.desc()).limit(300)).all()
    nomes = {u.id: u.nome for u in s.scalars(select(Usuario).where(Usuario.id.in_({e.usuario_id for e in eventos if e.usuario_id} or {0})))}
    falhas_24h = sum(1 for e in eventos if e.acao in ("login_falhou", "2fa_falhou", "login_bloqueado")
                     and e.criado_em >= datetime.now(timezone.utc) - timedelta(hours=24))
    hosts = [h.strip() for h in st.hosts_permitidos.split(",") if h.strip()]
    return {
        "eventos": [{"quando": e.criado_em, "acao": e.acao, "usuario": nomes.get(e.usuario_id), "email": (e.dados or {}).get("email"),
                     "ip": (e.dados or {}).get("ip"), "detalhe": {k: v for k, v in (e.dados or {}).items() if k not in ("ip", "email")}}
                    for e in eventos],
        "falhas_24h": falhas_24h,
        "config": {"https": st.cookie_seguro, "somente_este_computador": all(h in ("localhost", "127.0.0.1") for h in hosts),
                   "inatividade_min": st.sessao_inatividade_min, "sessao_horas": st.sessao_horas,
                   "chave_ok": problema_da_chave(st.secret_key) is None, "troca_de_chave_pendente": bool(st.secret_key_anterior),
                   "docs_api": st.docs_api},
    }
