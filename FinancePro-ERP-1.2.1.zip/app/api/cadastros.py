"""Cadastros: plano de contas (categorias), centros de custo, clientes/fornecedores, contas bancárias e regras."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.deps import Acesso, admin, financeiro, leitura, obter, sessao
from app.documentos import documento_valido, somente_digitos
from app.models import (Baixa, Categoria, CentroCusto, ContaBancaria, Contato, Lancamento, Movimento,
                        RegraClassificacao, Transferencia)
from app.plano_padrao import BANCOS, NOMES_DRE
from app.servicos import auditar, normalizar

rotas = APIRouter(prefix="/api/e/{empresa_id}", tags=["Cadastros"])


# ============================================================================ categorias (plano de contas)

class CategoriaIn(BaseModel):
    nome: str = Field(min_length=1, max_length=120)
    codigo: str | None = Field(None, max_length=20)
    pai_id: int | None = None                       # vazio = grupo
    natureza: str | None = Field(None, pattern="^(receita|despesa|neutra)$")
    grupo_dre: str | None = None
    ativo: bool = True


def _cat_out(c: Categoria, usos: int = 0) -> dict:
    return {"id": c.id, "codigo": c.codigo, "nome": c.nome, "pai_id": c.pai_id, "natureza": c.natureza,
            "grupo_dre": c.grupo_dre, "grupo_dre_nome": NOMES_DRE.get(c.grupo_dre), "ativo": c.ativo, "usos": usos}


@rotas.get("/categorias")
def categorias(a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    usos = dict(s.execute(select(Lancamento.categoria_id, func.count()).where(Lancamento.empresa_id == a.empresa_id)
                          .group_by(Lancamento.categoria_id)).all())
    cs = s.scalars(select(Categoria).where(Categoria.empresa_id == a.empresa_id)).all()
    chave = lambda c: [int(p) if p.isdigit() else p for p in c.codigo.split(".")]
    grupos = sorted((c for c in cs if c.pai_id is None), key=chave)
    filhos = {}
    for c in cs:
        if c.pai_id:
            filhos.setdefault(c.pai_id, []).append(c)
    return [{**_cat_out(g, usos.get(g.id, 0)),
             "categorias": [_cat_out(c, usos.get(c.id, 0)) for c in sorted(filhos.get(g.id, []), key=chave)]} for g in grupos]


def _proximo_codigo(s: Session, empresa_id: int, pai: Categoria | None) -> str:
    irmaos = s.scalars(select(Categoria.codigo).where(Categoria.empresa_id == empresa_id,
                                                      Categoria.pai_id == (pai.id if pai else None) if pai else Categoria.pai_id.is_(None))).all()
    if pai is None:
        nums = [int(c) for c in irmaos if c.isdigit()]
        return str(max(nums, default=0) + 1)
    nums = [int(c.rsplit(".", 1)[1]) for c in irmaos if "." in c and c.rsplit(".", 1)[1].isdigit()]
    return f"{pai.codigo}.{max(nums, default=0) + 1:02d}"


@rotas.post("/categorias", status_code=201)
def criar_categoria(d: CategoriaIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    pai = obter(s, Categoria, d.pai_id, a.empresa_id, "Grupo") if d.pai_id else None
    if pai and pai.pai_id:
        raise HTTPException(422, "O plano tem dois níveis: escolha um grupo (não uma categoria) como pai.")
    natureza = pai.natureza if pai else d.natureza
    grupo = pai.grupo_dre if pai and not d.grupo_dre else d.grupo_dre
    if not natureza or grupo not in NOMES_DRE:
        raise HTTPException(422, "Informe a natureza (receita/despesa) e a linha do DRE do grupo.")
    codigo = (d.codigo or "").strip() or _proximo_codigo(s, a.empresa_id, pai)
    if s.scalar(select(Categoria.id).where(Categoria.empresa_id == a.empresa_id, Categoria.codigo == codigo)):
        raise HTTPException(422, f"Já existe uma conta com o código {codigo}.")
    c = Categoria(empresa_id=a.empresa_id, pai_id=pai.id if pai else None, codigo=codigo, nome=d.nome.strip(),
                  natureza=natureza, grupo_dre=grupo, ativo=d.ativo)
    s.add(c)
    s.flush()
    auditar(s, a.empresa_id, a.uid, "categoria", c.id, "criar", {"codigo": codigo, "nome": c.nome})
    return _cat_out(c)


@rotas.put("/categorias/{cid}")
def editar_categoria(cid: int, d: CategoriaIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, Categoria, cid, a.empresa_id, "Categoria")
    codigo = (d.codigo or c.codigo).strip()
    if codigo != c.codigo and s.scalar(select(Categoria.id).where(Categoria.empresa_id == a.empresa_id, Categoria.codigo == codigo)):
        raise HTTPException(422, f"Já existe uma conta com o código {codigo}.")
    if d.pai_id != c.pai_id:
        tem_filhos = s.scalar(select(func.count(Categoria.id)).where(Categoria.pai_id == c.id))
        if tem_filhos and d.pai_id:
            raise HTTPException(422, "Um grupo com categorias não pode virar categoria de outro grupo.")
        if d.pai_id:
            pai = obter(s, Categoria, d.pai_id, a.empresa_id, "Grupo")
            if pai.pai_id or pai.id == c.id:
                raise HTTPException(422, "Escolha um grupo como pai.")
            c.natureza, c.grupo_dre = pai.natureza, pai.grupo_dre
        c.pai_id = d.pai_id
    if c.pai_id is None:                     # grupo: natureza e linha do DRE valem para as categorias dele
        if d.natureza:
            c.natureza = d.natureza
        if d.grupo_dre:
            if d.grupo_dre not in NOMES_DRE:
                raise HTTPException(422, "Linha do DRE inválida.")
            c.grupo_dre = d.grupo_dre
        for f in s.scalars(select(Categoria).where(Categoria.pai_id == c.id)):
            f.natureza, f.grupo_dre = c.natureza, c.grupo_dre
    c.codigo, c.nome, c.ativo = codigo, d.nome.strip(), d.ativo
    auditar(s, a.empresa_id, a.uid, "categoria", c.id, "alterar", d.model_dump())
    return _cat_out(c)


@rotas.delete("/categorias/{cid}")
def excluir_categoria(cid: int, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, Categoria, cid, a.empresa_id, "Categoria")
    usada = s.scalar(select(func.count(Lancamento.id)).where(Lancamento.categoria_id == c.id))
    filhos = s.scalar(select(func.count(Categoria.id)).where(Categoria.pai_id == c.id))
    if usada or filhos:
        raise HTTPException(422, "Esta conta tem lançamentos ou categorias dentro dela. Desative em vez de excluir.")
    s.delete(c)
    auditar(s, a.empresa_id, a.uid, "categoria", cid, "excluir", {"nome": c.nome})
    return {"ok": True}


@rotas.get("/linhas-dre")
def linhas_dre(a: Acesso = Depends(leitura)):
    return [{"id": k, "nome": v} for k, v in NOMES_DRE.items()]


# ============================================================================ centros de custo

class CentroIn(BaseModel):
    nome: str = Field(min_length=1, max_length=120)
    codigo: str | None = Field(None, max_length=20)
    ativo: bool = True


@rotas.get("/centros-custo")
def centros(a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    usos = dict(s.execute(select(Lancamento.centro_custo_id, func.count()).where(Lancamento.empresa_id == a.empresa_id)
                          .group_by(Lancamento.centro_custo_id)).all())
    cs = s.scalars(select(CentroCusto).where(CentroCusto.empresa_id == a.empresa_id).order_by(CentroCusto.codigo)).all()
    return [{"id": c.id, "codigo": c.codigo, "nome": c.nome, "ativo": c.ativo, "usos": usos.get(c.id, 0)} for c in cs]


@rotas.post("/centros-custo", status_code=201)
def criar_centro(d: CentroIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    cods = [c for c in s.scalars(select(CentroCusto.codigo).where(CentroCusto.empresa_id == a.empresa_id))]
    codigo = (d.codigo or "").strip() or f"{max([int(c) for c in cods if c.isdigit()], default=0) + 1:02d}"
    if codigo in cods:
        raise HTTPException(422, f"Já existe um centro de custo com o código {codigo}.")
    c = CentroCusto(empresa_id=a.empresa_id, codigo=codigo, nome=d.nome.strip(), ativo=d.ativo)
    s.add(c)
    s.flush()
    return {"id": c.id, "codigo": c.codigo, "nome": c.nome, "ativo": c.ativo, "usos": 0}


@rotas.put("/centros-custo/{cid}")
def editar_centro(cid: int, d: CentroIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, CentroCusto, cid, a.empresa_id, "Centro de custo")
    codigo = (d.codigo or c.codigo).strip()
    if codigo != c.codigo and s.scalar(select(CentroCusto.id).where(CentroCusto.empresa_id == a.empresa_id, CentroCusto.codigo == codigo)):
        raise HTTPException(422, f"Já existe um centro de custo com o código {codigo}.")
    c.codigo, c.nome, c.ativo = codigo, d.nome.strip(), d.ativo
    return {"id": c.id, "codigo": c.codigo, "nome": c.nome, "ativo": c.ativo}


@rotas.delete("/centros-custo/{cid}")
def excluir_centro(cid: int, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, CentroCusto, cid, a.empresa_id, "Centro de custo")
    if s.scalar(select(func.count(Lancamento.id)).where(Lancamento.centro_custo_id == c.id)):
        raise HTTPException(422, "Este centro de custo tem lançamentos. Desative em vez de excluir.")
    s.delete(c)
    return {"ok": True}


# ============================================================================ clientes e fornecedores

class ContatoIn(BaseModel):
    nome: str = Field(min_length=1, max_length=200)
    tipo: str = Field("fornecedor", pattern="^(cliente|fornecedor|ambos)$")
    documento: str | None = None
    email: str | None = None
    telefone: str | None = None
    chave_pix: str | None = None
    banco: str | None = None
    categoria_padrao_id: int | None = None
    centro_custo_padrao_id: int | None = None
    observacao: str | None = None
    ativo: bool = True


def _contato_out(c: Contato) -> dict:
    return {k: getattr(c, k) for k in ("id", "nome", "tipo", "documento", "email", "telefone", "chave_pix", "banco",
                                       "categoria_padrao_id", "centro_custo_padrao_id", "observacao", "ativo")}


def _validar_contato(s: Session, a: Acesso, d: ContatoIn, atual: Contato | None = None) -> dict:
    v = d.model_dump()
    v["nome"] = d.nome.strip()
    doc = somente_digitos(d.documento) or None
    if doc and not documento_valido(doc):
        raise HTTPException(422, "CPF/CNPJ inválido. Confira os números.")
    if doc:
        q = select(Contato).where(Contato.empresa_id == a.empresa_id, Contato.documento == doc)
        if atual:
            q = q.where(Contato.id != atual.id)
        outro = s.scalar(q)
        if outro:
            raise HTTPException(422, f"Este CPF/CNPJ já está cadastrado para “{outro.nome}”.")
    v["documento"] = doc
    if d.categoria_padrao_id:
        obter(s, Categoria, d.categoria_padrao_id, a.empresa_id, "Categoria")
    if d.centro_custo_padrao_id:
        obter(s, CentroCusto, d.centro_custo_padrao_id, a.empresa_id, "Centro de custo")
    return v


@rotas.get("/contatos")
def contatos(busca: str | None = None, tipo: str | None = Query(None, pattern="^(cliente|fornecedor)$"),
             ativos: bool | None = None, pagina: int = Query(0, ge=0), por_pagina: int = Query(100, ge=1, le=2000),
             a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    q = select(Contato).where(Contato.empresa_id == a.empresa_id)
    if busca:
        dig = somente_digitos(busca)
        termo = f"%{busca.strip()}%"
        q = q.where(or_(Contato.nome.ilike(termo), Contato.email.ilike(termo),
                        *( [Contato.documento.like(f"%{dig}%")] if len(dig) >= 3 else [])))
    if tipo:
        q = q.where(Contato.tipo.in_((tipo, "ambos")))
    if ativos is not None:
        q = q.where(Contato.ativo.is_(ativos))
    total = s.scalar(select(func.count()).select_from(q.subquery()))
    itens = s.scalars(q.order_by(func.lower(Contato.nome)).offset(pagina * por_pagina).limit(por_pagina)).all()
    return {"total": total, "itens": [_contato_out(c) for c in itens]}


@rotas.post("/contatos", status_code=201)
def criar_contato(d: ContatoIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    c = Contato(empresa_id=a.empresa_id, **_validar_contato(s, a, d))
    s.add(c)
    s.flush()
    auditar(s, a.empresa_id, a.uid, "contato", c.id, "criar", {"nome": c.nome})
    return _contato_out(c)


@rotas.put("/contatos/{cid}")
def editar_contato(cid: int, d: ContatoIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    c = obter(s, Contato, cid, a.empresa_id, "Cliente/fornecedor")
    for k, v in _validar_contato(s, a, d, c).items():
        setattr(c, k, v)
    return _contato_out(c)


@rotas.delete("/contatos/{cid}")
def excluir_contato(cid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    c = obter(s, Contato, cid, a.empresa_id, "Cliente/fornecedor")
    if s.scalar(select(func.count(Lancamento.id)).where(Lancamento.contato_id == c.id)):
        raise HTTPException(422, "Este cadastro tem lançamentos. Desative em vez de excluir.")
    s.delete(c)
    auditar(s, a.empresa_id, a.uid, "contato", cid, "excluir", {"nome": c.nome})
    return {"ok": True}


# ============================================================================ contas bancárias

class ContaIn(BaseModel):
    nome: str = Field(min_length=1, max_length=80)
    banco_codigo: str | None = Field(None, max_length=3)
    agencia: str | None = None
    numero: str | None = None
    tipo: str = Field("corrente", pattern="^(corrente|poupanca|investimento|caixa|cartao)$")
    saldo_inicial: Decimal = Decimal("0")
    data_saldo_inicial: date | None = None
    ativo: bool = True


def _conta_out(c: ContaBancaria) -> dict:
    cfg = c.integracao_config or {}
    return {"id": c.id, "nome": c.nome, "banco_codigo": c.banco_codigo, "banco_nome": BANCOS.get(c.banco_codigo or ""),
            "agencia": c.agencia, "numero": c.numero, "tipo": c.tipo, "saldo_inicial": c.saldo_inicial,
            "data_saldo_inicial": c.data_saldo_inicial, "ativo": c.ativo, "integracao": c.integracao,
            "integracao_client_id": cfg.get("client_id"), "integracao_conta_corrente": cfg.get("conta_corrente"),
            "integracao_banco": cfg.get("banco"),
            "ultima_sincronizacao": c.ultima_sincronizacao}


@rotas.get("/contas")
def contas(a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return [_conta_out(c) for c in s.scalars(select(ContaBancaria).where(ContaBancaria.empresa_id == a.empresa_id)
                                              .order_by(ContaBancaria.ativo.desc(), ContaBancaria.nome))]


@rotas.post("/contas", status_code=201)
def criar_conta(d: ContaIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = ContaBancaria(empresa_id=a.empresa_id, **d.model_dump())
    s.add(c)
    s.flush()
    auditar(s, a.empresa_id, a.uid, "conta", c.id, "criar", d.model_dump())
    return _conta_out(c)


@rotas.put("/contas/{cid}")
def editar_conta(cid: int, d: ContaIn, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    antes = _conta_out(c)
    for k, v in d.model_dump().items():
        setattr(c, k, v)
    auditar(s, a.empresa_id, a.uid, "conta", c.id, "alterar", {"antes": antes, "depois": d.model_dump()})
    return _conta_out(c)


@rotas.delete("/contas/{cid}")
def excluir_conta(cid: int, a: Acesso = Depends(admin), s: Session = Depends(sessao)):
    c = obter(s, ContaBancaria, cid, a.empresa_id, "Conta")
    usada = (s.scalar(select(func.count(Baixa.id)).where(Baixa.conta_bancaria_id == c.id)) or 0) + \
            (s.scalar(select(func.count(Movimento.id)).where(Movimento.conta_bancaria_id == c.id)) or 0) + \
            (s.scalar(select(func.count(Transferencia.id)).where(or_(Transferencia.conta_origem_id == c.id,
                                                                     Transferencia.conta_destino_id == c.id))) or 0)
    if usada:
        raise HTTPException(422, "Esta conta tem movimentação. Desative em vez de excluir.")
    s.delete(c)
    return {"ok": True}


@rotas.get("/bancos")
def bancos(a: Acesso = Depends(leitura)):
    return [{"codigo": k, "nome": v, "api": k == "077"} for k, v in sorted(BANCOS.items(), key=lambda x: x[1])]


# ============================================================================ regras de classificação

class RegraIn(BaseModel):
    texto: str = Field(min_length=2, max_length=120)
    natureza: str = Field("*", pattern=r"^(C|D|\*)$")
    categoria_id: int | None = None
    centro_custo_id: int | None = None
    contato_id: int | None = None
    prioridade: int = 100
    ativo: bool = True


@rotas.get("/regras")
def regras(a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    rs = s.scalars(select(RegraClassificacao).where(RegraClassificacao.empresa_id == a.empresa_id)
                   .order_by(RegraClassificacao.prioridade, RegraClassificacao.texto)).all()
    return [{k: getattr(r, k) for k in ("id", "texto", "natureza", "categoria_id", "centro_custo_id", "contato_id",
                                        "prioridade", "vezes_usada", "ativo")} for r in rs]


def _validar_regra(s: Session, a: Acesso, d: RegraIn) -> dict:
    if not normalizar(d.texto):
        raise HTTPException(422, "O texto da regra precisa ter letras ou números.")
    if d.categoria_id:
        c = obter(s, Categoria, d.categoria_id, a.empresa_id, "Categoria")
        if s.scalar(select(Categoria.id).where(Categoria.pai_id == c.id).limit(1)):
            raise HTTPException(422, "Escolha uma categoria, não um grupo.")
    if d.centro_custo_id:
        obter(s, CentroCusto, d.centro_custo_id, a.empresa_id, "Centro de custo")
    if d.contato_id:
        obter(s, Contato, d.contato_id, a.empresa_id, "Cliente/fornecedor")
    return d.model_dump()


@rotas.post("/regras", status_code=201)
def criar_regra(d: RegraIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    r = RegraClassificacao(empresa_id=a.empresa_id, **_validar_regra(s, a, d))
    s.add(r)
    s.flush()
    return {"id": r.id}


@rotas.put("/regras/{rid}")
def editar_regra(rid: int, d: RegraIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    r = obter(s, RegraClassificacao, rid, a.empresa_id, "Regra")
    for k, v in _validar_regra(s, a, d).items():
        setattr(r, k, v)
    return {"id": r.id}


@rotas.delete("/regras/{rid}")
def excluir_regra(rid: int, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    s.delete(obter(s, RegraClassificacao, rid, a.empresa_id, "Regra"))
    return {"ok": True}
