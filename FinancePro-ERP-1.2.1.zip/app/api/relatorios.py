"""Relatórios, dashboards e exportação para Excel."""
from __future__ import annotations

import io
from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.api.deps import Acesso, leitura, periodo, sessao
from app.models import Empresa
from app.servicos import relatorios as rel

rotas = APIRouter(prefix="/api/e/{empresa_id}/relatorios", tags=["Relatórios"])
REGIME = Query("caixa", pattern="^(caixa|competencia)$")


@rotas.get("/resumo")
def resumo(inicio: date | None = None, fim: date | None = None, a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    i, f = periodo(inicio, fim)
    return rel.resumo(s, a.empresa_id, i, f)


@rotas.get("/serie")
def serie(inicio: date | None = None, fim: date | None = None, regime: str = REGIME,
          a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    i, f = periodo(inicio, fim, padrao_meses=11)
    return rel.serie_mensal(s, a.empresa_id, i, f, regime)


@rotas.get("/dre")
def dre(inicio: date | None = None, fim: date | None = None, regime: str = REGIME,
        a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    i, f = periodo(inicio, fim, padrao_meses=5)
    if len(rel.meses_entre(i, f)) > 36:
        raise HTTPException(422, "Escolha no máximo 36 meses.")
    return rel.dre(s, a.empresa_id, i, f, regime)


@rotas.get("/comparativo")
def comparativo(meses: str = Query(..., description="AAAA-MM separados por vírgula"),
                dimensao: str = Query("categoria", pattern="^(categoria|grupo|centro_custo|contato)$"),
                tipo: str = Query("pagar", pattern="^(receber|pagar|ambos)$"), regime: str = REGIME,
                a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    lista = [m.strip() for m in meses.split(",") if m.strip()]
    try:
        for m in lista:
            date.fromisoformat(m + "-01")
    except ValueError as exc:
        raise HTTPException(422, "Meses no formato AAAA-MM.") from exc
    if not 1 <= len(lista) <= 24:
        raise HTTPException(422, "Escolha de 1 a 24 meses.")
    return rel.comparativo(s, a.empresa_id, lista, dimensao, tipo, regime)


@rotas.get("/detalhe")
def detalhe(inicio: date, fim: date, regime: str = REGIME, tipo: str | None = Query(None, pattern="^(receber|pagar)$"),
            chave: str | None = None, dimensao: str | None = None,
            a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return rel.detalhe(s, a.empresa_id, inicio, fim, regime, tipo, chave=chave, dimensao=dimensao)


# ============================================================================ Excel

def _xlsx(titulo: str, empresa: str, cabecalho: list[str], linhas: list[list], subtitulo: str = "",
          negrito: set[int] | None = None) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active
    ws.title = titulo[:31]
    ws.append([f"{empresa} — {titulo}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([subtitulo])
    ws.append([])
    ws.append(cabecalho)
    for c in ws[4]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F7A3A")
        c.alignment = Alignment(horizontal="center")
    for i, l in enumerate(linhas):
        ws.append([float(v) if isinstance(v, Decimal) else v for v in l])
        if negrito and i in negrito:
            for c in ws[ws.max_row]:
                c.font = Font(bold=True)
    for col in range(2, len(cabecalho) + 1):
        for cel in ws.iter_rows(min_row=5, min_col=col, max_col=col):
            for c in cel:
                if isinstance(c.value, (int, float)):
                    c.number_format = '#,##0.00;[Red]-#,##0.00'
    ws.column_dimensions["A"].width = 46
    for col in range(2, len(cabecalho) + 1):
        ws.column_dimensions[get_column_letter(col)].width = 16
    ws.freeze_panes = "B5"
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def _registrar_exportacao(s: Session, a: Acesso) -> None:
    """Exportar para Excel tira os dados do sistema: fica registrado quem exportou o quê."""
    import inspect
    from app.servicos import auditar
    rota = inspect.stack()[1].function
    auditar(s, a.empresa_id, a.uid, "relatorio", None, "exportar", {"relatorio": rota})


def _arquivo(conteudo: bytes, nome: str) -> Response:
    return Response(conteudo, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{nome}"'})


@rotas.get("/dre.xlsx")
def dre_xlsx(inicio: date | None = None, fim: date | None = None, regime: str = REGIME,
             a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    i, f = periodo(inicio, fim, padrao_meses=5)
    d = rel.dre(s, a.empresa_id, i, f, regime)
    linhas, neg = [], set()
    for x in d["linhas"]:
        if x["tipo"] != "subtotal" and not x["itens"] and not x["total"]:
            continue
        neg.add(len(linhas))
        linhas.append([x["nome"], *[x["valores"][m] for m in d["meses"]], x["total"]])
        for it in x.get("itens", []):
            linhas.append(["    " + it["nome"], *[it["valores"][m] for m in d["meses"]], it["total"]])
    emp = s.get(Empresa, a.empresa_id).nome
    _registrar_exportacao(s, a)
    return _arquivo(_xlsx("DRE gerencial", emp, ["Conta", *d["meses"], "Total"], linhas,
                          f"Regime de {regime} · {i:%d/%m/%Y} a {f:%d/%m/%Y}", neg), f"DRE_{i:%Y%m}-{f:%Y%m}.xlsx")


@rotas.get("/comparativo.xlsx")
def comparativo_xlsx(meses: str, dimensao: str = "categoria", tipo: str = "pagar", regime: str = REGIME,
                     a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    c = comparativo(meses, dimensao, tipo, regime, a, s)
    cab = ["Item"]
    for i, m in enumerate(c["meses"]):
        cab += [m] if i == 0 else [m, "Var. R$", "Var. %"]
    linhas = []
    for l in c["linhas"]:
        row = [l["nome"]]
        for i, m in enumerate(c["meses"]):
            row.append(l["valores"][m])
            if i:
                v = l["variacao"][m]
                row += [v["abs"], float(v["pct"]) if v["pct"] is not None else None]
        linhas.append(row)
    tot = ["Total"]
    for i, m in enumerate(c["meses"]):
        tot.append(c["totais"][m])
        if i:
            tot += [c["totais"][m] - c["totais"][c["meses"][i - 1]], None]
    linhas.append(tot)
    emp = s.get(Empresa, a.empresa_id).nome
    _registrar_exportacao(s, a)
    return _arquivo(_xlsx("Comparativo", emp, cab, linhas, f"{dimensao} · {tipo} · regime de {regime}", {len(linhas) - 1}),
                    "Comparativo.xlsx")


@rotas.get("/lancamentos.xlsx")
def lancamentos_xlsx(tipo: str | None = None, situacao: str | None = None, inicio: date | None = None,
                     fim: date | None = None, data_base: str = "vencimento", busca: str | None = None,
                     a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    from app.api.financeiro import listar
    r = listar(tipo, situacao, inicio, fim, data_base, busca, None, None, None, None, "vencimento", 0, 1000, a, s)
    linhas = [[l["descricao"], l["contato"], l["categoria"], l["centro_custo"], l["vencimento"].strftime("%d/%m/%Y"),
               l["valor"], l["pago"], l["restante"], l["situacao"],
               l["data_pagamento"].strftime("%d/%m/%Y") if l["data_pagamento"] else None, l["documento"]] for l in r["itens"]]
    emp = s.get(Empresa, a.empresa_id).nome
    titulo = {"receber": "Recebimentos", "pagar": "Pagamentos"}.get(tipo or "", "Lançamentos")
    _registrar_exportacao(s, a)
    return _arquivo(_xlsx(titulo, emp, ["Descrição", "Cliente/fornecedor", "Categoria", "Centro de custo", "Vencimento",
                                        "Valor", "Pago", "Em aberto", "Situação", "Pago em", "Documento"], linhas,
                          f"{len(linhas)} lançamentos"), f"{titulo}.xlsx")

