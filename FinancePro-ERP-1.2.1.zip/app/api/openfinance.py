"""Open Finance (Pluggy): configurar a empresa, conectar bancos e ligar as contas."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.api.deps import Acesso, admin_confirmado, confirmado, financeiro, leitura, obter, sessao
from app.models import ContaBancaria, Empresa
from app.servicos import openfinance as of

rotas = APIRouter(prefix="/api/e/{empresa_id}/openfinance", tags=["Open Finance"])


class ConfigIn(BaseModel):
    client_id: str = Field(min_length=1, max_length=120)
    client_secret: str | None = Field(None, max_length=200)
    sandbox: bool = False


class TokenIn(BaseModel):
    item_id: str | None = Field(None, max_length=80)


class NovaConta(BaseModel):
    nome: str = Field(min_length=1, max_length=80)
    banco_codigo: str | None = Field(None, max_length=3)
    agencia: str | None = Field(None, max_length=10)
    numero: str | None = Field(None, max_length=20)
    tipo: str | None = Field(None, pattern="^(corrente|poupanca|investimento|cartao)$")


class Vinculo(BaseModel):
    account_id: str
    conta_id: int | None = None
    criar: NovaConta | None = None


class LigarIn(BaseModel):
    vinculos: list[Vinculo] = Field(min_length=1, max_length=30)
    inicio: date | None = None


def _emp(s: Session, a: Acesso) -> Empresa:
    return s.get(Empresa, a.empresa_id)


@rotas.get("")
def situacao(a: Acesso = Depends(leitura), s: Session = Depends(sessao)):
    return of.situacao(s, _emp(s, a))


@rotas.put("")
def configurar(d: ConfigIn, a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    of.configurar(s, _emp(s, a), a.uid, d.client_id, d.client_secret, d.sandbox)
    return of.situacao(s, _emp(s, a))


@rotas.delete("")
def remover(a: Acesso = Depends(admin_confirmado), s: Session = Depends(sessao)):
    of.remover(s, _emp(s, a), a.uid)
    return {"ok": True}


@rotas.post("/token")
def token(d: TokenIn, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    return of.token(_emp(s, a), a.uid, d.item_id)


@rotas.get("/itens/{item_id}/contas")
def contas_do_item(item_id: str, a: Acesso = Depends(financeiro), s: Session = Depends(sessao)):
    return of.contas_do_item(s, _emp(s, a), item_id)


@rotas.post("/itens/{item_id}/ligar")
def ligar(item_id: str, d: LigarIn, a: Acesso = Depends(financeiro), _=Depends(confirmado), s: Session = Depends(sessao)):
    return of.ligar(s, _emp(s, a), a.uid, item_id, [v.model_dump() for v in d.vinculos], d.inicio)


@rotas.delete("/contas/{cid}")
def desligar(cid: int, a: Acesso = Depends(financeiro), _=Depends(confirmado), s: Session = Depends(sessao)):
    of.desligar(s, obter(s, ContaBancaria, cid, a.empresa_id, "Conta"), a.uid)
    return {"ok": True}
