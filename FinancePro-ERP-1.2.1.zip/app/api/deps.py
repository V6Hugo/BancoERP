"""Dependências das rotas: sessão do banco (com commit no fim), usuário logado e acesso à empresa."""
from __future__ import annotations

from collections.abc import Iterator
from datetime import date

from fastapi import Depends, HTTPException, Path, Request
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import SessaoUsuario, Usuario, Vinculo
from app.seguranca import COOKIE
from app.servicos import NegocioErro

PESO = {"leitura": 1, "financeiro": 2, "admin": 3}


def sessao() -> Iterator[Session]:
    s = SessionLocal()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


class ConfirmarErro(NegocioErro):
    """Ação sensível: a tela pede a senha (e o código, se houver verificação em duas etapas) e repete."""
    def __init__(self, pedir_codigo: bool):
        super().__init__("Por segurança, confirme a sua senha para continuar.")
        self.pedir_codigo = pedir_codigo


def ip_de(request: Request) -> str | None:
    return request.client.host if request.client else None


def sessao_atual(request: Request, s: Session = Depends(sessao)) -> SessaoUsuario:
    from app.servicos.acesso import sessao_valida
    ss = sessao_valida(s, request.cookies.get(COOKIE))
    if not ss:
        s.commit()                       # grava o encerramento (inatividade/expiração) antes de recusar
        raise HTTPException(401, "Sessão expirada. Entre de novo.")
    request.state.sessao = ss
    return ss


def usuario_atual(ss: SessaoUsuario = Depends(sessao_atual)) -> Usuario:
    return ss.usuario


def confirmado(ss: SessaoUsuario = Depends(sessao_atual)) -> SessaoUsuario:
    """Exige senha confirmada nos últimos minutos (alterar credenciais de banco, usuários, 2FA...)."""
    from app.servicos.acesso import confirmada_recentemente
    if not confirmada_recentemente(ss):
        raise ConfirmarErro(ss.usuario.totp_ativo)
    return ss


class Acesso:
    def __init__(self, usuario: Usuario, empresa_id: int, papel: str, sessao: SessaoUsuario | None = None):
        self.usuario, self.empresa_id, self.papel, self.sessao = usuario, empresa_id, papel, sessao

    @property
    def uid(self) -> int:
        return self.usuario.id


def _acesso(minimo: str):
    def dep(empresa_id: int = Path(..., ge=1), ss: SessaoUsuario = Depends(sessao_atual),
            s: Session = Depends(sessao)) -> Acesso:
        u = ss.usuario
        v = s.get(Vinculo, (u.id, empresa_id))
        papel = v.papel if v else ("admin" if u.admin_sistema else None)
        if papel is None:
            raise HTTPException(404, "Empresa não encontrada.")
        if PESO[papel] < PESO[minimo]:
            raise HTTPException(403, "Seu acesso a esta empresa não permite esta ação.")
        return Acesso(u, empresa_id, papel, ss)
    return dep


def _acesso_confirmado(minimo: str):
    base = _acesso(minimo)

    def dep(a: Acesso = Depends(base), _: SessaoUsuario = Depends(confirmado)) -> Acesso:
        return a
    return dep


leitura = _acesso("leitura")
financeiro = _acesso("financeiro")
admin = _acesso("admin")
admin_confirmado = _acesso_confirmado("admin")      # admin + senha confirmada há pouco


def obter(s: Session, modelo, id_: int, empresa_id: int, nome: str = "Registro"):
    obj = s.get(modelo, id_)
    if obj is None or getattr(obj, "empresa_id", None) != empresa_id:
        raise HTTPException(404, f"{nome} não encontrado.")
    return obj


def periodo(inicio: date | None, fim: date | None, padrao_meses: int = 0) -> tuple[date, date]:
    """Período padrão: mês atual (ou os últimos N meses)."""
    hoje = date.today()
    if fim is None:
        prox = (hoje.replace(day=28).toordinal() + 4)
        fim = date.fromordinal(prox).replace(day=1)
        fim = date.fromordinal(fim.toordinal() - 1)
    if inicio is None:
        m = hoje.month - padrao_meses
        a = hoje.year + (m - 1) // 12
        inicio = date(a, (m - 1) % 12 + 1, 1)
    if inicio > fim:
        raise HTTPException(422, "A data inicial é depois da final.")
    return inicio, fim
