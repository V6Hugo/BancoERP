"""FinancePro ERP — aplicação web (API + interface)."""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select

from app import __version__, db
from app.api import auth, cadastros, financeiro, openfinance, relatorios
from app.config import get_settings
from app.servicos import NegocioErro

log = logging.getLogger("financepro")
WEB = Path(__file__).parent / "web"
RAIZ = Path(__file__).resolve().parents[1]


def migrar(engine) -> None:
    """Deixa o banco na versão atual (Alembic). Roda a cada início; não faz nada se já estiver em dia."""
    from alembic import command
    from alembic.config import Config
    cfg = Config(str(RAIZ / "alembic.ini"))
    cfg.set_main_option("script_location", str(RAIZ / "migracoes"))
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        command.upgrade(cfg, "head")


async def _sincronizar_periodicamente(minutos: int) -> None:
    from app.models import ContaBancaria
    from app.servicos.conciliacao import sincronizar_inter
    from app.servicos.openfinance import sincronizar as sincronizar_of
    while True:
        await asyncio.sleep(minutos * 60)
        s = db.SessionLocal()
        try:
            contas = list(s.scalars(select(ContaBancaria).where(ContaBancaria.integracao.in_(("inter", "openfinance")),
                                                               ContaBancaria.ativo.is_(True))))
            for c in contas:
                f = sincronizar_inter if c.integracao == "inter" else sincronizar_of
                try:
                    r = await asyncio.to_thread(f, s, c, None)
                    s.commit()
                    log.info("%s %s: %s novos", c.integracao, c.nome, r["novos"])
                except Exception as exc:  # noqa: BLE001 - uma conta com problema não para as outras
                    s.rollback()
                    log.warning("Sincronização %s (%s) falhou: %s", c.integracao, c.nome, exc)
        finally:
            s.close()


def recifrar_segredos(engine) -> int:
    """Depois de trocar a SECRET_KEY (com a antiga em SECRET_KEY_ANTERIOR), reescreve tudo o que é cifrado
    com a chave nova: credenciais de banco, segredos da verificação em duas etapas e chaves dos certificados."""
    from sqlalchemy.orm import Session
    from app.models import ContaBancaria, Empresa, Usuario
    from app.seguranca import cifrar_bytes, decifrar_bytes, recifrar
    n = 0
    with Session(engine) as s:
        for e in s.scalars(select(Empresa)):
            pl = dict((e.integracoes or {}).get("pluggy") or {})
            if pl.get("client_secret"):
                pl["client_secret"] = recifrar(pl["client_secret"])
                e.integracoes = {**e.integracoes, "pluggy": pl}
                n += 1
        base = Path(get_settings().pasta_certificados)
        for c in s.scalars(select(ContaBancaria).where(ContaBancaria.integracao == "inter")):
            cfg = dict(c.integracao_config or {})
            if cfg.get("client_secret"):
                cfg["client_secret"] = recifrar(cfg["client_secret"])
                n += 1
            if str(cfg.get("chave", "")).endswith(".cifrada") and (base / cfg["chave"]).exists():
                arq = base / cfg["chave"]
                arq.write_bytes(cifrar_bytes(decifrar_bytes(arq.read_bytes())))
            c.integracao_config = cfg
        for u in s.scalars(select(Usuario).where(Usuario.totp_segredo.is_not(None))):
            u.totp_segredo = recifrar(u.totp_segredo)
            n += 1
        s.commit()
    return n


def limpar_sessoes(engine) -> None:
    from datetime import datetime, timedelta, timezone
    from sqlalchemy import delete, or_
    from app.models import SessaoUsuario
    limite = datetime.now(timezone.utc) - timedelta(days=30)
    with engine.begin() as c:
        c.execute(delete(SessaoUsuario).where(or_(SessaoUsuario.encerrada_em < limite, SessaoUsuario.expira_em < limite)))


@asynccontextmanager
async def ciclo(app: FastAPI):
    from app.seguranca import problema_da_chave
    st = get_settings()
    logging.basicConfig(level=st.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if (p := problema_da_chave(st.secret_key)):
        raise RuntimeError(f"{p} Gere uma no .env (o Iniciar FinancePro.bat faz isso) antes de iniciar.")
    eng = db.configurar(st.database_url)
    migrar(eng)
    if st.secret_key_anterior:
        n = recifrar_segredos(eng)
        log.warning("SECRET_KEY trocada: %s segredo(s) re-cifrado(s). Já pode apagar SECRET_KEY_ANTERIOR do .env.", n)
    limpar_sessoes(eng)
    Path(st.pasta_certificados).mkdir(parents=True, exist_ok=True)
    tarefa = asyncio.create_task(_sincronizar_periodicamente(st.sincronizar_bancos_min)) if st.sincronizar_bancos_min > 0 else None
    log.info("FinancePro ERP %s pronto", __version__)
    yield
    if tarefa:
        tarefa.cancel()


_st = get_settings()
app = FastAPI(title="FinancePro ERP", version=__version__, lifespan=ciclo,
              description="Gestão financeira: recebimentos, pagamentos, fluxo de caixa, bancos e relatórios.",
              docs_url="/docs" if _st.docs_api else None, redoc_url=None,
              openapi_url="/openapi.json" if _st.docs_api else None)

# Política de conteúdo: só roda script do próprio sistema e da janela de conexão da Pluggy (Open Finance).
CSP = ("default-src 'self'; script-src 'self' https://cdn.pluggy.ai; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://*.pluggy.ai; "
       "frame-src https://*.pluggy.ai; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
METODOS_QUE_ALTERAM = {"POST", "PUT", "PATCH", "DELETE"}


def _host_permitido(host: str) -> bool:
    permitidos = [h.strip().lower() for h in get_settings().hosts_permitidos.split(",") if h.strip()]
    nome = host.rsplit(":", 1)[0].strip("[]").lower() if host else ""
    return "*" in permitidos or nome in permitidos


@app.middleware("http")
async def protecoes(request: Request, chamar):
    host = request.headers.get("host", "")
    # 1) só responde pelos endereços configurados (bloqueia "DNS rebinding" de sites maliciosos)
    if request.url.path != "/saude" and not _host_permitido(host):
        return JSONResponse({"detail": "Endereço não permitido. Ajuste HOSTS_PERMITIDOS no .env."}, status_code=400)
    # 2) CSRF: alterações só vindas da própria tela (cabeçalho próprio + mesma origem)
    if request.method in METODOS_QUE_ALTERAM and request.url.path.startswith("/api/"):
        origem = request.headers.get("origin") or ""
        if request.headers.get("x-fp") != "1" or (origem and origem.split("://", 1)[-1].lower() != host.lower()):
            return JSONResponse({"detail": "Requisição recusada (origem não confirmada)."}, status_code=403)
    resp = await chamar(request)
    # 3) cabeçalhos de segurança
    h = resp.headers
    h["Content-Security-Policy"] = CSP
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"
    h["Cross-Origin-Opener-Policy"] = "same-origin-allow-popups"
    if get_settings().cookie_seguro:
        h["Strict-Transport-Security"] = "max-age=31536000"
    if request.url.path.startswith("/api/"):
        h["Cache-Control"] = "no-store"          # dado financeiro não fica no cache do navegador
    return resp
for r in (auth.rotas, cadastros.rotas, financeiro.rotas, openfinance.rotas, relatorios.rotas):
    app.include_router(r)


@app.exception_handler(NegocioErro)
async def _negocio(_: Request, exc: NegocioErro):
    from app.api.deps import ConfirmarErro
    from app.servicos.acesso import BloqueioErro, CredencialErro
    corpo = {"detail": str(exc)}
    if getattr(exc, "item_id", None):
        corpo["reconectar"] = exc.item_id          # Open Finance: o banco pediu nova autorização
    if isinstance(exc, ConfirmarErro):
        return JSONResponse({**corpo, "confirmar": True, "pedir_codigo": exc.pedir_codigo}, status_code=403)
    if isinstance(exc, BloqueioErro):
        return JSONResponse(corpo, status_code=429)
    if isinstance(exc, CredencialErro):
        return JSONResponse(corpo, status_code=401)
    return JSONResponse(corpo, status_code=422)


@app.get("/saude", include_in_schema=False)
def saude():
    return {"status": "ok", "versao": __version__}


app.mount("/static", StaticFiles(directory=WEB), name="static")


_INDEX: str | None = None


@app.get("/", include_in_schema=False)
def interface():
    # versão no endereço dos arquivos: depois de uma atualização o navegador não usa a tela antiga guardada
    global _INDEX
    if _INDEX is None:
        import re
        _INDEX = re.sub(r'(/static/[\w./-]+\.(?:js|css))"', rf'\1?v={__version__}"', (WEB / "index.html").read_text(encoding="utf-8"))
    return HTMLResponse(_INDEX, headers={"Cache-Control": "no-store"})
